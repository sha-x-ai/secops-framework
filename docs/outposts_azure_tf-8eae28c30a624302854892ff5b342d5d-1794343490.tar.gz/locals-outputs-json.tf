locals {
  # proxy_config for the notification JSON. `enabled` must stay a real JSON bool
  # or the WO rejects the scanner-launch call with HTTP 400.
  #
  # HCL trap: a ternary over two differently-shaped objects unifies to
  # map(string), stringifying `enabled`/`port`. So jsonencode each branch FIRST,
  # ternary on the strings, then jsondecode — preserving the native types.
  byon_proxy_config_enabled_json = jsonencode(merge(
    {
      enabled      = true
      host         = var.proxy_config.host
      port         = var.proxy_config.port
      auth_enabled = var.proxy_config.auth_enabled
      tls_enabled  = var.proxy_config.tls_enabled
    },
    var.proxy_config.tls_enabled ? {
      ca_cert_content = var.proxy_config.ca_cert_content
    } : {},
  ))
  byon_proxy_config_disabled_json = jsonencode({ enabled = false })
  byon_proxy_config = jsondecode(
    var.proxy_config.enabled ? local.byon_proxy_config_enabled_json : local.byon_proxy_config_disabled_json
  )

  location_resources = [
    for loc in local.enabled_locations : {
      name = loc
      # proxy_credentials_secret_id added only in BYON+proxy_auth (not yet in schema).
      regional_resources = merge({
        storage_account_name            = module.location[loc].storage_account_name
        storage_container_name          = module.location[loc].storage_container_name
        artifact_storage_container_name = module.location[loc].artifact_storage_container_name
        storage_queue_name              = module.location[loc].storage_queue_name
        network_security_group_id       = module.location[loc].network_security_group_id
        private_endpoint_asg_id         = module.location[loc].private_endpoint_asg_id
        ads_asg_id                      = module.location[loc].scanner_asg_id
        dspm_asg_id                     = module.location[loc].scanner_asg_id
        registry_asg_id                 = module.location[loc].scanner_asg_id
        proxy_internal_asg_id           = module.location[loc].proxy_asg_id
        proxy_external_asg_id           = module.location[loc].proxy_asg_id
        proxy_asg_id                    = module.location[loc].proxy_asg_id
        serverless_asg_id               = module.location[loc].scanner_asg_id
        # vnet_id / subnet_id resolve to the customer or Cortex IDs per BYON mode.
        virtual_network_id = module.location[loc].vnet_id
        subnet_id          = module.location[loc].subnet_id
        key_vault_id       = module.location[loc].key_vault_id
        },
        var.proxy_config.auth_enabled ? {
          proxy_credentials_secret_id = module.location[loc].proxy_credentials_secret_id
        } : {}
      )
    }
  ]


  output_data = {
    operation           = "create_outpost"
    template_id         = var.template_id
    template_version    = local.template_version
    provisioning_method = "TF"
    features            = local.features
    account_id          = data.azurerm_client_config.current.subscription_id
    account_name        = local.subscription_name
    organization_id     = data.azurerm_client_config.current.tenant_id
    credentials = {
      client_id = local.outpost_app_client_id
    }
    resources_data = {
      # In customer_managed mode, the dspm_o365_app_registration_client_id field is omitted
      # entirely from the payload — there is no O365 AppReg in this mode.
      # In cortex_managed mode the field is included with the Cortex-created O365 AppReg client_id.
      # Per-role UAMI payload fields. The platform schema is strict about field names — each
      # role has its own prefix convention that DOES NOT generalize across roles. All values
      # flow through local.uami.<role>.* so the cortex_managed vs customer_managed source is
      # decided in exactly one place.
      #
      # Field-name conventions (do not "simplify" with a single for-comprehension — they are
      # NOT uniform; the schema in iacoutput.json will reject anything that strays):
      #
      #   - agentless  → BOTH `scanner_*` (legacy: pre-split single "scanner" UAMI) AND
      #                  `ads_scanner_*` (current name)
      #   - dspm       → `dspm_scanner_*`         (with "_scanner_" infix)
      #   - registry   → `registry_scanner_*`     (with "_scanner_" infix)
      #   - serverless → `serverless_*`           (NO "_scanner_" infix — unlike dspm/registry)
      #   - proxy      → `proxy_*`                (NO "_scanner_" infix; also has a typo'd
      #                                            `_id_principal_id` field name in the schema)
      #
      # BYON: schema requires proxy_config whenever `custom_networking` is in
      # features, so it's always sent in BYON mode (never in egress mode). The
      # disabled form must be exactly `{ enabled = false }` (no host/port/ca_*).
      global_resources = merge(
        {
          # SP display name resolution:
          #   cortex_managed   → Cortex-created SP display name
          #   customer_managed → customer's BYO SP display name (looked up via data.azuread_service_principal.customer_sp)
          outpost_service_principal_name = local.outpost_sp_display_name
          resource_group_name            = azurerm_resource_group.azure_outpost_cwp_agentless.name
        },
        # `agentless` is surfaced under BOTH "scanner" (legacy) and "ads_scanner" aliases.
        merge([for prefix in ["scanner", "ads_scanner"] : {
          "${prefix}_user_assigned_identity_id"           = local.uami.agentless.resource_id
          "${prefix}_user_assigned_identity_client_id"    = local.uami.agentless.client_id
          "${prefix}_user_assigned_identity_principal_id" = local.uami.agentless.principal_id
        }]...),
        # dspm/registry use the "<role>_scanner_*" prefix.
        merge([for role in ["dspm", "registry"] : {
          "${role}_scanner_user_assigned_identity_id"           = local.uami[role].resource_id
          "${role}_scanner_user_assigned_identity_client_id"    = local.uami[role].client_id
          "${role}_scanner_user_assigned_identity_principal_id" = local.uami[role].principal_id
        }]...),
        # serverless uses the "<role>_*" prefix (NO "_scanner_" infix).
        {
          serverless_user_assigned_identity_id           = local.uami.serverless.resource_id
          serverless_user_assigned_identity_client_id    = local.uami.serverless.client_id
          serverless_user_assigned_identity_principal_id = local.uami.serverless.principal_id
        },
        # proxy: no "_scanner_" infix, plus a typo'd `_id_principal_id` field name that the
        # platform schema requires (kept as-is for compatibility).
        # Omitted under egress_off — no proxy VM.
        local.egress_mode != "egress_off" ? {
          proxy_user_assigned_identity_id              = local.uami.proxy.resource_id
          proxy_user_assigned_identity_client_id       = local.uami.proxy.client_id
          proxy_user_assigned_identity_id_principal_id = local.uami.proxy.principal_id
        } : {},
        # cortex_managed mode adds the O365 AppReg client_id; customer_managed mode omits it
        # entirely (backend treats "absent" as "O365 scanning disabled").
        local.is_byoa_enabled ? {} : {
          dspm_o365_app_registration_client_id = local.dspm_o365_app_client_id
        },
        # BYOA: customer SP object ID, so the UI can show which SP backs the outpost.
        local.is_byoa_enabled ? {
          customer_sp_object_id = var.customer_sp_object_id
        } : {},
        # proxy_config (BYON only) — see local.byon_proxy_config for the bool-typing trick.
        local.is_byon_enabled ? {
          proxy_config = local.byon_proxy_config
        } : {}
      )
      regions = flatten(local.location_resources)
    }
  }
  json_output = jsonencode(local.output_data)
}
