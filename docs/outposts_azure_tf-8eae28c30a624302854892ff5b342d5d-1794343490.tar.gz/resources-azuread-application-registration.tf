# Cortex-managed App Registrations. In customer_managed mode the customer pre-creates the AppReg externally
# (see the BYO setup script shipped with the Cortex BYOA docs) and passes its IDs via input vars.
# sign_in_audience must be AzureADMultipleOrgs so the AppReg can consent into the monitored tenant.

resource "azuread_application_registration" "outpost_app_registration" {
  count            = local.manage_app_registration ? 1 : 0
  display_name     = local.app_registration_name
  sign_in_audience = "AzureADMultipleOrgs"
}

resource "azuread_application_registration" "outpost_o365_app_registration" {
  count            = local.manage_app_registration ? 1 : 0
  display_name     = local.dspm_o365_app_registration_name
  sign_in_audience = "AzureADMultipleOrgs"
}
