# customer_managed mode: look up the BYO AppReg + SP and fail-fast at plan time on common operator
# mistakes (mismatched SP/AppReg, disabled SP, TF runner not an AppReg owner,
# non-existent client_id, non-existent / stale SP object_id).
# The AppReg's object_id is derived from the supplied client_id — customer never pastes both.
#
# Some operator mistakes (a client_id or SP object_id that resolves to nothing) cause the data-source
# READ itself to fail, which aborts before any lifecycle postcondition can run. To keep those errors
# human-readable we add a parallel, non-fatal lookup (data.azuread_service_principals probe with
# ignore_missing = true) and surface guidance via `check` blocks, which Terraform evaluates
# best-effort and reports alongside (not instead of) the raw error.

# Identity of the TF runner itself — used to assert AppReg ownership in the `check` block below.
# Read with the runner's own credentials, no extra permissions.
data "azuread_client_config" "current" {}

data "azuread_application" "customer_app" {
  count     = local.is_byoa_enabled ? 1 : 0
  client_id = var.customer_app_client_id

  lifecycle {
    # TF runner must be an owner of the customer's AppReg so it can attach FICs.
    postcondition {
      condition     = contains(self.owners, data.azuread_client_config.current.object_id)
      error_message = <<-EOM
        The Terraform runner (object_id ${data.azuread_client_config.current.object_id}) is NOT
        listed as an owner of the BYO App Registration ${var.customer_app_client_id}. Without
        ownership Terraform cannot attach the Federated Identity Credentials, and apply will
        hard-fail midway through with a generic "Insufficient privileges to complete the
        operation" error far from the root cause.

        Fix:
          az ad app owner add --id ${var.customer_app_client_id} \
                              --owner-object-id ${data.azuread_client_config.current.object_id}

        Current owners (object IDs): ${jsonencode(self.owners)}
      EOM
    }
  }
}

# Parallel SP lookup keyed by the already-known AppReg client_id. Uses the
# PLURAL data source with ignore_missing = true so a non-existent client_id resolves to an empty list
# instead of aborting the whole plan with a raw provider read error (the previous
# singular data.azuread_service_principal.customer_sp_by_client_id did a HARD read that aborted before
# the check blocks could run, silently turning byo_sp_object_id_matches_app into a no-op). Two uses:
#   1. Confirms the AppReg's Service Principal exists (byo_app_client_id_exists check).
#   2. Provides the CANONICAL SP object_id for the byo_sp_object_id_matches_app check guidance.
data "azuread_service_principals" "customer_app_probe" {
  count          = local.is_byoa_enabled ? 1 : 0
  client_ids     = [var.customer_app_client_id]
  ignore_missing = true
}

locals {
  # Service principals from the graceful customer_app_probe. The probe is count-gated on
  # is_byoa_enabled, so a raw [0] index fails during graph construction on non-BYOA plans (the empty
  # tuple has no elements). The [*] splat turns the 0-or-1 count into a list without erroring, one()
  # collapses it to the single value or null, and coalesce(..., []) normalises the non-BYOA case to [].
  _byo_probe_service_principals = coalesce(one(data.azuread_service_principals.customer_app_probe[*].service_principals), [])

  # Canonical SP object_id for the supplied AppReg, derived from the graceful probe. Falls back to a
  # human-readable sentinel when the client_id resolves to nothing, so any check that interpolates it
  # stays safe even when the AppReg does not exist.
  _byo_canonical_sp_object_id = length(local._byo_probe_service_principals) > 0 ? local._byo_probe_service_principals[0].object_id : "<unable to resolve — check customer_app_client_id>"
}

data "azuread_service_principal" "customer_sp" {
  count     = local.is_byoa_enabled ? 1 : 0
  object_id = var.customer_sp_object_id

  lifecycle {
    # The SP's client_id must equal the AppReg's client_id — i.e. this is actually the SP of the
    # AppReg the customer specified. Catches the case where someone passes the SP of a *different* app.
    #
    # The error_message is kept STATIC and free of
    # cross-data-source interpolation. Some Terraform versions do not lazily evaluate postcondition
    # error_message expressions, so interpolating another data source's attributes here could itself
    # error during evaluation. The "correct object_id" copy-paste hint now lives solely in the
    # byo_sp_object_id_matches_app check block below.
    postcondition {
      condition     = self.client_id == var.customer_app_client_id
      error_message = <<-EOM
        The Service Principal object_id you supplied (customer_sp_object_id =
        ${var.customer_sp_object_id}) belongs to a different App Registration (its client_id is
        ${self.client_id}, but you specified customer_app_client_id = ${var.customer_app_client_id}).

        Update customer_sp_object_id to the Service Principal of App Registration
        ${var.customer_app_client_id} (the byo_sp_object_id_matches_app check prints the correct
        value), or get it yourself with:
          az ad sp show --id ${var.customer_app_client_id} --query id -o tsv
      EOM
    }

    # SP must be enabled. A disabled SP makes Cortex Platform's consent step succeed but
    # scanner pods later fail with `AADSTS50057: The user account is disabled.` — far away from
    # the root cause.
    postcondition {
      condition     = self.account_enabled
      error_message = "Customer SP ${var.customer_sp_object_id} is disabled in Entra. Enable it in Azure Portal → Enterprise Applications → <SP> → Properties → 'Enabled for users to sign-in' = Yes, or run: az ad sp update --id ${var.customer_sp_object_id} --set accountEnabled=true"
    }
  }
}

# When customer_sp_object_id resolves to nothing (or to the wrong SP) the primary
# data.azuread_service_principal.customer_sp read fails with a raw provider "Service Principal ... was
# not found" before its postconditions can run. A `check` block is evaluated best-effort and still
# runs, so it hands the operator the correct object_id derived from the AppReg client_id — the
# symmetric counterpart to the client_id-mismatch postcondition above.
check "byo_sp_object_id_matches_app" {
  assert {
    # Compare against the canonical object_id derived from the graceful probe. When the probe finds no
    # SP (e.g. customer_app_client_id resolves to nothing) the local is the human-readable sentinel,
    # which never equals a real GUID; that case is already reported by byo_app_client_id_exists, so to
    # avoid double-alarming the operator we only assert when the canonical object_id actually resolved.
    condition = (!local.is_byoa_enabled ||
      length(local._byo_probe_service_principals) == 0 ||
    var.customer_sp_object_id == local._byo_canonical_sp_object_id)
    error_message = <<-EOM
      The Service Principal object_id you supplied (customer_sp_object_id =
      ${var.customer_sp_object_id}) is not the Service Principal of App Registration
      ${var.customer_app_client_id}.

      The correct object_id for that App Registration's Service Principal is:
        ${local._byo_canonical_sp_object_id}

      Update customer_sp_object_id to the value above, or get it yourself with:
        az ad sp show --id ${var.customer_app_client_id} --query id -o tsv
    EOM
  }
}

# A non-existent customer_app_client_id makes the primary data.azuread_application.customer_app read
# fail outright ("no applications found matching filter appId eq '...'"), so it cannot be
# postconditioned. The customer_app_probe above (plural data source with ignore_missing = true) is
# non-fatal, so this check replaces that raw error with actionable guidance.
check "byo_app_client_id_exists" {
  assert {
    condition = (!local.is_byoa_enabled ||
    length(local._byo_probe_service_principals) > 0)
    error_message = <<-EOM
      No App Registration / Service Principal was found for customer_app_client_id =
      ${var.customer_app_client_id} in the tenant the Terraform runner is authenticated against.

      Check that:
        - the value is the App Registration's Application (client) ID, not its object_id
        - the App Registration exists in this tenant
        - a Service Principal (Enterprise Application) has been created for it

      Verify with:
        az ad app show --id ${var.customer_app_client_id} --query appId -o tsv
    EOM
  }
}

# Same-value mis-paste: customer_app_client_id and customer_sp_object_id are two
# DIFFERENT identifiers (the AppReg's Application/client ID vs the Service
# Principal's object ID). Pasting the same GUID into both is a common copy-paste
# slip that otherwise surfaces as the confusing "different App Registration"
# postcondition above. Pure-variable check — runs before any data-source read.
check "byo_app_client_id_and_sp_object_id_differ" {
  assert {
    condition     = !local.is_byoa_enabled || var.customer_app_client_id != var.customer_sp_object_id
    error_message = <<-EOM
      customer_app_client_id and customer_sp_object_id are identical
      (${var.customer_app_client_id}). These are two DIFFERENT identifiers:
        - customer_app_client_id : the App Registration's Application (client) ID
        - customer_sp_object_id  : the Service Principal's object ID

      Re-copy them from the BYO setup script output (shipped with the Cortex BYOA
      docs), or get them with:
        az ad app show --id <appId>          --query appId -o tsv   # customer_app_client_id
        az ad sp  show --id <appId>          --query id    -o tsv   # customer_sp_object_id
    EOM
  }
}
