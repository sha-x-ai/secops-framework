data "azurerm_subscription" "outpost" {
}