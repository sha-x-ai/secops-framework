locals {
  # Semantic version of the outpost template (e.g. 100.3.0).
  # Bump this per deployment/release; it is reported in the outpost registration
  # notification and forwarded to the create_outpost_template_version notification.
  template_version = "102.3.0" # Cortex CLOUD 2.3
}
