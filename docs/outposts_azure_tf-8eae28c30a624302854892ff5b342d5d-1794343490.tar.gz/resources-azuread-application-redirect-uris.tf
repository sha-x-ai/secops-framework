# Redirect URIs back to the Cortex platform after admin consent. Cortex-managed AppRegs only —
# BYO customers configure redirect URIs themselves on their AppReg.

resource "azuread_application_redirect_uris" "outpost_registration_redirect_uri" {
  count          = local.manage_app_registration ? 1 : 0
  application_id = azuread_application_registration.outpost_app_registration[0].id
  type           = "Web"
  redirect_uris  = var.app_registration_redirect_uris
}

resource "azuread_application_redirect_uris" "outpost_registration_redirect_uri_o365_app" {
  count          = local.manage_app_registration ? 1 : 0
  application_id = azuread_application_registration.outpost_o365_app_registration[0].id
  type           = "Web"
  redirect_uris  = var.app_registration_redirect_uris
}
