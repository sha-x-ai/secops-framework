variable "subscription_id" {
  description = "Azure subscription_id, i.e - 00000000-0000-0000-0000-000000000000"
  type        = string
}

# Use your custom Azure provider configuration. This example is valid for using az cli locally.
# The logged-in Azure CLI service principal or user should be assigned with "Cloud Application Administrator" or "Application Administrator" privileged roles, and "Contributor" role on the subscription scope
provider "azurerm" {
  # https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/guides/4.0-upgrade-guide#specifying-subscription-id-is-now-mandatory
  subscription_id = var.subscription_id
  features {
    storage {
      data_plane_available = false
    }
  }
  storage_use_azuread             = true
  resource_provider_registrations = "core"
  resource_providers_to_register = [
    "Microsoft.EventGrid",
    "Microsoft.KeyVault"
  ]

  environment = "usgovernment"
}

provider "azuread" {
  use_cli     = true
  environment = "usgovernment"
}