locals {
  # BYOA: customer pre-creates the AppReg + SP; Cortex only attaches FICs + role assignments.
  is_byoa_enabled = var.app_registration_mode == "customer_managed"

  # Lifecycle flag — use in count expressions for resources Cortex creates only when it owns the AppReg.
  manage_app_registration = !local.is_byoa_enabled # Cortex creates AppReg+SP+API access+redirects+O365 AppReg

  # Outpost SP object_id (for role assignments, incl. Key Vault access via RBAC).
  outpost_principal_id = local.is_byoa_enabled ? var.customer_sp_object_id : azuread_service_principal.outpost_sp[0].object_id

  # Outpost App Reg id (for FICs). Format expected by azuread_application_federated_identity_credential.application_id is "/applications/<object_id>".
  # In BYO mode the object_id is resolved at plan time from data.azuread_application.customer_app (looked up by client_id).
  outpost_app_object_id = local.is_byoa_enabled ? "/applications/${data.azuread_application.customer_app[0].object_id}" : azuread_application_registration.outpost_app_registration[0].id

  # Outpost AppReg client_id (appId) — for the notification payload's `credentials.client_id`.
  outpost_app_client_id = local.is_byoa_enabled ? var.customer_app_client_id : azuread_application_registration.outpost_app_registration[0].client_id

  # Outpost SP display name — for the notification payload's `outpost_service_principal_name`.
  # Cortex-created in cortex_managed mode, looked up via data.azuread_service_principal.customer_sp for BYO.
  outpost_sp_display_name = local.is_byoa_enabled ? data.azuread_service_principal.customer_sp[0].display_name : azuread_service_principal.outpost_sp[0].display_name

  # O365 AppReg client_id — null in BYOA mode (no O365 AppReg created).
  # Backend treats null as "O365 scanning disabled".
  dspm_o365_app_client_id = local.is_byoa_enabled ? null : azuread_application_registration.outpost_o365_app_registration[0].client_id

  # ── BYO UAMIs ──────────────────────────────────────────────────────────
  # When true, Cortex TF creates no UAMIs and no FICs; customer pre-creates
  # 5 UAMIs and adds all FICs externally. Cortex still does role assignments
  # (incl. RBAC-based KV secret access) via local.uami.<role>.principal_id.
  is_customer_managed_uami_mode = var.uami_mode == "customer_managed"

  _customer_managed_uami_ids = {
    agentless  = var.customer_uami_agentless_id
    dspm       = var.customer_uami_dspm_id
    registry   = var.customer_uami_registry_id
    serverless = var.customer_uami_serverless_id
    proxy      = var.customer_uami_proxy_id
  }

  # Per-role UAMI map: {principal_id, client_id, name, resource_id} sourced
  # from either the Cortex-created UAMI or the customer-supplied UAMI.
  # All consumers (FICs, role assignments, locals-outputs-json, modules-location)
  # MUST go through local.uami.<role>.* so the mode switch lives in one place.
  #
  # HCL can't index resource blocks by a dynamic string key, so the cortex side
  # is enumerated via a small per-role lookup table. Customer side iterates over
  # local._customer_managed_uami_ids because both the data-source and the resource_id
  # var are keyed identically.
  # No proxy VM under egress_off, so no proxy UAMI either.
  _create_proxy_uami = !local.is_customer_managed_uami_mode && local.egress_mode != "egress_off"

  _cortex_managed_uami_resources = local.is_customer_managed_uami_mode ? {} : {
    agentless  = azurerm_user_assigned_identity.agentless[0]
    dspm       = azurerm_user_assigned_identity.dspm[0]
    registry   = azurerm_user_assigned_identity.registry[0]
    serverless = azurerm_user_assigned_identity.serverless[0]
    proxy      = local._create_proxy_uami ? azurerm_user_assigned_identity.proxy[0] : null
  }
  uami = local.is_customer_managed_uami_mode ? {
    for role, _ in local._customer_managed_uami_ids : role => {
      principal_id = data.azurerm_user_assigned_identity.customer_managed[role].principal_id
      client_id    = data.azurerm_user_assigned_identity.customer_managed[role].client_id
      name         = data.azurerm_user_assigned_identity.customer_managed[role].name
      resource_id  = data.azurerm_user_assigned_identity.customer_managed[role].id
    }
    } : {
    for role, r in local._cortex_managed_uami_resources : role => {
      principal_id = r != null ? r.principal_id : ""
      client_id    = r != null ? r.client_id : ""
      name         = r != null ? r.name : ""
      resource_id  = r != null ? r.id : ""
    }
  }

  # Notification features array. byo_uamis without byo_app_registration is
  # impossible — gated by precondition on azurerm_resource_group.azure_outpost_cwp_agentless.
  # Exactly one egress token (egress / custom_networking / egress_off) — see
  # locals-egress-mode.tf. Keep the token in its original slot, before secrets,
  # so existing tenants see no features-array churn; the mode only swaps which
  # token occupies that slot.
  is_byon_enabled = length(var.byon_config) > 0
  features_base   = ["ads", "registry", "serverless", "dspm", local.egress_feature, "secrets"]
  dynamic_features = concat(
    local.is_byoa_enabled ? ["byo_app_registration"] : [],
    local.is_customer_managed_uami_mode ? ["byo_uamis"] : [],
  )
  features = concat(local.features_base, local.dynamic_features)

  app_registration_name           = var.app_registration_name == "" ? "cortex-scan-platform-${local.subscription_name}" : var.app_registration_name
  dspm_o365_app_registration_name = var.dspm_o365_app_registration_name == "" ? "Cortex M365 Posture - ${local.subscription_name}" : var.dspm_o365_app_registration_name
  base_tags = {
    "managed_by" = "paloaltonetworks"
  }
  tags_all                       = merge(var.custom_resources_tags, local.base_tags)
  subscription_name              = data.azurerm_subscription.outpost.display_name
  resource_group_name            = var.resource_group_name_prefix != "" ? "${var.resource_group_name_prefix}-${random_string.resource_group_random_name.result}" : "${random_string.resource_group_random_name.result}"
  resource_group_region          = var.azure_us_government ? var.azure_us_government_resource_group_region : var.resource_group_region
  create_public_storage_accounts = var.force_private_storage_accounts ? false : var.input_ip_whitelist == ""
  create_public_key_vaults       = var.force_private_key_vaults ? false : var.input_ip_whitelist == ""
  platform_allowed_ips           = var.input_ip_whitelist == "" ? var.platform_allowed_ips : concat(var.platform_allowed_ips, split(",", replace(var.input_ip_whitelist, "/\\s+/", "")))
  workload_orchestrator_role_id  = var.workload_orchestrator_role_id == "" ? azurerm_role_definition.app_registration_cortex_role[0].role_definition_resource_id : var.workload_orchestrator_role_id
  private_endpoint_role_id       = var.private_endpoints_role_id == "" ? azurerm_role_definition.private_endpoint_role[0].role_definition_resource_id : var.private_endpoints_role_id
  key_vault_secrets_ro_role_id   = var.key_vault_secrets_ro_role_id == "" ? azurerm_role_definition.key_vault_secrets_ro_role[0].role_definition_resource_id : var.key_vault_secrets_ro_role_id
  _all_azure_supported_locations = [
    "australiacentral",
    "australiaeast",
    "australiasoutheast",
    "brazilsouth",
    "canadacentral",
    "canadaeast",
    "centralindia",
    "centralus",
    "eastasia",
    "eastus",
    "eastus2",
    "francecentral",
    "germanywestcentral",
    "israelcentral",
    "italynorth",
    "japaneast",
    "japanwest",
    "koreacentral",
    "koreasouth",
    "mexicocentral",
    "northcentralus",
    "northeurope",
    "norwayeast",
    "polandcentral",
    "qatarcentral",
    "southafricanorth",
    "southcentralus",
    "southeastasia",
    "southindia",
    "spaincentral",
    "swedencentral",
    "switzerlandnorth",
    "uaenorth",
    "uksouth",
    "ukwest",
    "westcentralus",
    "westeurope",
    "westindia",
    "westus",
    "westus2",
    "westus3"
  ]

  # Partition-scoped valid regions (gov vs commercial); also gates location_allowlist + byon_config.
  _all_valid_partition_locations = var.azure_us_government ? var.azure_us_government_locations : local._all_azure_supported_locations

  _allowed_locations = length(var.location_allowlist) > 0 ? var.location_allowlist : local._all_valid_partition_locations
  enabled_locations  = setsubtract(local._allowed_locations, var.location_denylist)

  well_known_ms_graph_ids = {
    client_ids = {
      # Ref: https://learn.microsoft.com/en-us/troubleshoot/entra/entra-id/governance/verify-first-party-apps-sign-in#application-ids-of-commonly-used-microsoft-applications
      "Microsoft.Graph"      = "00000003-0000-0000-c000-000000000000",
      "Microsoft.SharePoint" = "00000003-0000-0ff1-ce00-000000000000",
      # https://learn.microsoft.com/en-us/purview/encryption-azure-ad-configuration
      "Microsoft.RMS" = "00000012-0000-0000-c000-000000000000"
    },

    role_ids = {
      # Ref: https://learn.microsoft.com/en-us/graph/permissions-reference
      "Graph.Application.Read.All"                 = "9a5d68dd-52b0-4cc2-bd40-abcf44ac3a30",
      "Graph.User.Read.All"                        = "df021288-bdef-4463-88db-98f22de89214",
      "Graph.Group.Read.All"                       = "5b567255-7703-4780-807c-7be8301ae99b",
      "Graph.Directory.Read.All"                   = "7ab1d382-f21e-4acd-a863-ba3e13f7da61",
      "Graph.Sites.Read.All"                       = "332a536c-c7ef-4017-ab91-336970924f0d",
      "Graph.Files.Read.All"                       = "01d4889c-1287-42c6-ac1f-5d1e02578ef6",
      "Graph.InformationProtectionPolicy.Read.All" = "19da66cb-0fb0-4390-b071-ebc76a349482",
      "Graph.SharePointTenantSettings.Read.All"    = "83d4163d-a2d8-4d3b-9695-4ae3ca98f888",
      # Sharepoint
      "SharePoint.Sites.Manage.All" = "9bff6588-13f2-4c48-bbf2-ddab62256b36",
      "SharePoint.Sites.Read.All"   = "d13f72ca-a275-4b96-b789-48ebcc4da984",
      # RMS
      "RMS.Content.SuperUser" = "7347eb49-7a1a-43c5-8eac-a5cd1d1c7cf0"
    }
  }
}

# custom_networking is an outpost-level flag, so mixed BYON + Cortex-managed
# regions would misroute scan launches. Require keys(byon_config) to exactly
# equal enabled_locations; no-op when byon_config is empty.
check "byon_locations_match_enabled" {
  assert {
    condition = (
      length(var.byon_config) == 0 ||
      (
        length(setsubtract(keys(var.byon_config), local.enabled_locations)) == 0 &&
        length(setsubtract(local.enabled_locations, keys(var.byon_config))) == 0
      )
    )
    error_message = format(
      "BYON outpost: keys(byon_config) must exactly equal enabled_locations. Got byon_config=%s vs enabled_locations=%s. Either (a) add the missing region(s) to byon_config, or (b) shrink location_allowlist / extend location_denylist so enabled_locations covers exactly the BYON regions.",
      jsonencode(sort(keys(var.byon_config))),
      jsonencode(sort(tolist(local.enabled_locations))),
    )
  }
}

# A region listed in BOTH location_allowlist and location_denylist resolves
# silently (denylist wins via the setsubtract in local.enabled_locations), so
# the customer's "allow X" intent is quietly dropped. Surface the conflict.
check "location_allow_deny_disjoint" {
  assert {
    condition = length(setintersection(var.location_allowlist, var.location_denylist)) == 0
    error_message = format(
      "These locations appear in BOTH location_allowlist and location_denylist: %s. Remove each from one list — denylist currently wins, so these regions are silently NOT deployed, which may not be what you intend.",
      jsonencode(sort(tolist(setintersection(var.location_allowlist, var.location_denylist)))),
    )
  }
}

# Zero enabled regions = a silent no-op outpost. Gov honors allowlist/denylist too, so not exempt.
check "enabled_locations_non_empty" {
  assert {
    condition     = length(local.enabled_locations) > 0
    error_message = "After applying location_allowlist and location_denylist no regions remain enabled — the outpost would deploy nothing. Adjust the lists so at least one supported Azure region is enabled."
  }
}
