<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
| ---- | ------- |
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.9.4, < 2 |
| <a name="requirement_azuread"></a> [azuread](#requirement\_azuread) | 3.7.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 4.79.0 |
| <a name="requirement_jsonschema"></a> [jsonschema](#requirement\_jsonschema) | = 0.2.1 |
| <a name="requirement_local"></a> [local](#requirement\_local) | 2.6.1 |
| <a name="requirement_random"></a> [random](#requirement\_random) | 3.7.2 |
| <a name="requirement_terracurl"></a> [terracurl](#requirement\_terracurl) | = 2.1.0 |

## Providers

| Name | Version |
| ---- | ------- |
| <a name="provider_azuread"></a> [azuread](#provider\_azuread) | 3.7.0 |
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 4.79.0 |
| <a name="provider_jsonschema"></a> [jsonschema](#provider\_jsonschema) | = 0.2.1 |
| <a name="provider_local"></a> [local](#provider\_local) | 2.6.1 |
| <a name="provider_random"></a> [random](#provider\_random) | 3.7.2 |
| <a name="provider_terracurl"></a> [terracurl](#provider\_terracurl) | = 2.1.0 |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
| ---- | ------ | ------- |
| <a name="module_location"></a> [location](#module\_location) | ./azure_outpost_cwp_agentless_single_region | n/a |

## Resources

| Name | Type |
| ---- | ---- |
| [azuread_application_api_access.outpost_msgraph_api](https://registry.terraform.io/providers/hashicorp/azuread/3.7.0/docs/resources/application_api_access) | resource |
| [azuread_application_api_access.outpost_o365_msgraph_api](https://registry.terraform.io/providers/hashicorp/azuread/3.7.0/docs/resources/application_api_access) | resource |
| [azuread_application_api_access.outpost_o365_rms_api](https://registry.terraform.io/providers/hashicorp/azuread/3.7.0/docs/resources/application_api_access) | resource |
| [azuread_application_api_access.outpost_o365_sharepoint_api](https://registry.terraform.io/providers/hashicorp/azuread/3.7.0/docs/resources/application_api_access) | resource |
| [azuread_application_federated_identity_credential.federated_cts_gke_serviceaccount](https://registry.terraform.io/providers/hashicorp/azuread/3.7.0/docs/resources/application_federated_identity_credential) | resource |
| [azuread_application_federated_identity_credential.federated_cts_gke_serviceaccount_o365_app](https://registry.terraform.io/providers/hashicorp/azuread/3.7.0/docs/resources/application_federated_identity_credential) | resource |
| [azuread_application_federated_identity_credential.federated_dspm_managed_identity](https://registry.terraform.io/providers/hashicorp/azuread/3.7.0/docs/resources/application_federated_identity_credential) | resource |
| [azuread_application_federated_identity_credential.federated_dspm_managed_identity_o365_app](https://registry.terraform.io/providers/hashicorp/azuread/3.7.0/docs/resources/application_federated_identity_credential) | resource |
| [azuread_application_federated_identity_credential.federated_registry_managed_identity](https://registry.terraform.io/providers/hashicorp/azuread/3.7.0/docs/resources/application_federated_identity_credential) | resource |
| [azuread_application_federated_identity_credential.federated_serverless_managed_identity](https://registry.terraform.io/providers/hashicorp/azuread/3.7.0/docs/resources/application_federated_identity_credential) | resource |
| [azuread_application_redirect_uris.outpost_registration_redirect_uri](https://registry.terraform.io/providers/hashicorp/azuread/3.7.0/docs/resources/application_redirect_uris) | resource |
| [azuread_application_redirect_uris.outpost_registration_redirect_uri_o365_app](https://registry.terraform.io/providers/hashicorp/azuread/3.7.0/docs/resources/application_redirect_uris) | resource |
| [azuread_application_registration.outpost_app_registration](https://registry.terraform.io/providers/hashicorp/azuread/3.7.0/docs/resources/application_registration) | resource |
| [azuread_application_registration.outpost_o365_app_registration](https://registry.terraform.io/providers/hashicorp/azuread/3.7.0/docs/resources/application_registration) | resource |
| [azuread_service_principal.outpost_o365_sp](https://registry.terraform.io/providers/hashicorp/azuread/3.7.0/docs/resources/service_principal) | resource |
| [azuread_service_principal.outpost_sp](https://registry.terraform.io/providers/hashicorp/azuread/3.7.0/docs/resources/service_principal) | resource |
| [azurerm_federated_identity_credential.uami_self_fic](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/federated_identity_credential) | resource |
| [azurerm_resource_group.azure_outpost_cwp_agentless](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/resource_group) | resource |
| [azurerm_role_assignment.byon_vnet_workload_orchestrator_role_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.cortex_private_endpoint_role_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.cortex_role_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.cortex_storage_queue_role_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.dspm_managed_identity_key_vault_secrets_ro_role_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.dspm_managed_identity_storage_blob_role_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.managed_identity_storage_blob_role_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.proxy_managed_identity_key_vault_secrets_ro_role_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.proxy_managed_identity_storage_blob_proxy_role_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.registry_managed_identity_key_vault_secrets_ro_role_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.registry_managed_identity_storage_blob_role_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.serverless_managed_identity_storage_blob_role_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.storage_blob_role_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.terraform_runner_key_vault_secrets_officer_role_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/role_assignment) | resource |
| [azurerm_role_definition.app_registration_cortex_role](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/role_definition) | resource |
| [azurerm_role_definition.key_vault_secrets_ro_role](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/role_definition) | resource |
| [azurerm_role_definition.private_endpoint_role](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/role_definition) | resource |
| [azurerm_user_assigned_identity.agentless](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/user_assigned_identity) | resource |
| [azurerm_user_assigned_identity.dspm](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/user_assigned_identity) | resource |
| [azurerm_user_assigned_identity.proxy](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/user_assigned_identity) | resource |
| [azurerm_user_assigned_identity.registry](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/user_assigned_identity) | resource |
| [azurerm_user_assigned_identity.serverless](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/resources/user_assigned_identity) | resource |
| [local_file.outpost_registration](https://registry.terraform.io/providers/hashicorp/local/2.6.1/docs/resources/file) | resource |
| [random_string._agentless_identity_random_name](https://registry.terraform.io/providers/hashicorp/random/3.7.2/docs/resources/string) | resource |
| [random_string._dspm_identity_random_name](https://registry.terraform.io/providers/hashicorp/random/3.7.2/docs/resources/string) | resource |
| [random_string._registry_identity_random_name](https://registry.terraform.io/providers/hashicorp/random/3.7.2/docs/resources/string) | resource |
| [random_string._serverless_identity_random_name](https://registry.terraform.io/providers/hashicorp/random/3.7.2/docs/resources/string) | resource |
| [random_string.resource_group_random_name](https://registry.terraform.io/providers/hashicorp/random/3.7.2/docs/resources/string) | resource |
| [terracurl_request.outpost_registration](https://registry.terraform.io/providers/devops-rob/terracurl/2.1.0/docs/resources/request) | resource |
| [terraform_data.all_resources_applied](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/resources/data) | resource |
| [terraform_data.byon_validation](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/resources/data) | resource |
| [terraform_data.tenant_validation](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/resources/data) | resource |
| [azuread_application.customer_app](https://registry.terraform.io/providers/hashicorp/azuread/3.7.0/docs/data-sources/application) | data source |
| [azuread_client_config.current](https://registry.terraform.io/providers/hashicorp/azuread/3.7.0/docs/data-sources/client_config) | data source |
| [azuread_service_principal.customer_sp](https://registry.terraform.io/providers/hashicorp/azuread/3.7.0/docs/data-sources/service_principal) | data source |
| [azuread_service_principals.customer_app_probe](https://registry.terraform.io/providers/hashicorp/azuread/3.7.0/docs/data-sources/service_principals) | data source |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/data-sources/client_config) | data source |
| [azurerm_subscription.outpost](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/data-sources/subscription) | data source |
| [azurerm_user_assigned_identity.customer_managed](https://registry.terraform.io/providers/hashicorp/azurerm/4.79.0/docs/data-sources/user_assigned_identity) | data source |
| [jsonschema_validator.schema_validation](https://registry.terraform.io/providers/bpedman/jsonschema/0.2.1/docs/data-sources/validator) | data source |

## Inputs

| Name | Description | Type | Default | Required |
| ---- | ----------- | ---- | ------- | :------: |
| <a name="input_app_registration_mode"></a> [app\_registration\_mode](#input\_app\_registration\_mode) | Controls App Registration creation:<br/>- "cortex\_managed": Cortex creates App Reg + SP (default, cross-tenant)<br/>- "customer\_managed": Customer pre-creates App Reg + SP; Cortex adds FICs to BYO app (cross-tenant) | `string` | `"cortex_managed"` | no |
| <a name="input_app_registration_name"></a> [app\_registration\_name](#input\_app\_registration\_name) | The desired App Regisrtaion name. Leave empty to set dynamically with the subscription name | `string` | `""` | no |
| <a name="input_app_registration_redirect_uris"></a> [app\_registration\_redirect\_uris](#input\_app\_registration\_redirect\_uris) | app registration redirect uri list, to be provided by PANW | `list(any)` | n/a | yes |
| <a name="input_azure_us_government"></a> [azure\_us\_government](#input\_azure\_us\_government) | Deploy on Azure US Government Cloud | `bool` | `false` | no |
| <a name="input_azure_us_government_locations"></a> [azure\_us\_government\_locations](#input\_azure\_us\_government\_locations) | target locations (regions) for US Government deployment | `list(string)` | <pre>[<br/>  "usgovvirginia",<br/>  "usgovarizona",<br/>  "usgovtexas"<br/>]</pre> | no |
| <a name="input_azure_us_government_resource_group_region"></a> [azure\_us\_government\_resource\_group\_region](#input\_azure\_us\_government\_resource\_group\_region) | target resource group region for US Government deployment | `string` | `"usgovvirginia"` | no |
| <a name="input_byon_config"></a> [byon\_config](#input\_byon\_config) | Per-region BYON configuration. Each map key is an Azure location, and the<br/>value contains the customer's existing VNet + subnet ARM resource IDs for<br/>that region. Locations not listed here will not be deployed in BYON mode<br/>(in BYON mode, only locations in this map are enabled).<br/><br/>Example:<br/>  byon\_config = {<br/>    "eastus" = {<br/>      virtual\_network\_id = "/subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Network/virtualNetworks/<vnet>"<br/>      subnet\_id          = "/subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Network/virtualNetworks/<vnet>/subnets/<subnet>"<br/>    }<br/>  } | <pre>map(object({<br/>    virtual_network_id = string<br/>    subnet_id          = string<br/>  }))</pre> | `{}` | no |
| <a name="input_create_customer_uami_self_fics"></a> [create\_customer\_uami\_self\_fics](#input\_create\_customer\_uami\_self\_fics) | When uami\_mode = 'customer\_managed', whether Cortex should create self-federated-identity-credentials on each customer-supplied UAMI. Set to false if the customer pre-created the self-FICs themselves. | `bool` | `true` | no |
| <a name="input_cts_sa_email"></a> [cts\_sa\_email](#input\_cts\_sa\_email) | The CTS Service Account email address. To be supplied by PANW | `string` | n/a | yes |
| <a name="input_cts_unique_id"></a> [cts\_unique\_id](#input\_cts\_unique\_id) | The CTS Service Account unique ID. To be supplied by PANW | `string` | n/a | yes |
| <a name="input_custom_resources_tags"></a> [custom\_resources\_tags](#input\_custom\_resources\_tags) | extra tags to include on all resources | `map(string)` | `{}` | no |
| <a name="input_customer_app_client_id"></a> [customer\_app\_client\_id](#input\_customer\_app\_client\_id) | Client ID (appId) of customer's pre-created App Registration. Required when app\_registration\_mode = 'customer\_managed'. Generate via the BYO setup script shipped with the Cortex BYOA docs. | `string` | `""` | no |
| <a name="input_customer_sp_object_id"></a> [customer\_sp\_object\_id](#input\_customer\_sp\_object\_id) | Object ID of customer's BYO Service Principal. Required when app\_registration\_mode = 'customer\_managed'. Generate via the BYO setup script shipped with the Cortex BYOA docs, or get via: az ad sp show --id <customer\_app\_client\_id> --query id -o tsv | `string` | `""` | no |
| <a name="input_customer_uami_agentless_id"></a> [customer\_uami\_agentless\_id](#input\_customer\_uami\_agentless\_id) | ARM resource ID of customer-created 'agentless' UAMI. Required when uami\_mode = 'customer\_managed'. | `string` | `""` | no |
| <a name="input_customer_uami_dspm_id"></a> [customer\_uami\_dspm\_id](#input\_customer\_uami\_dspm\_id) | ARM resource ID of customer-created 'dspm' UAMI. Required when uami\_mode = 'customer\_managed'. | `string` | `""` | no |
| <a name="input_customer_uami_proxy_id"></a> [customer\_uami\_proxy\_id](#input\_customer\_uami\_proxy\_id) | ARM resource ID of customer-created 'proxy' UAMI. Required when uami\_mode = 'customer\_managed'. | `string` | `""` | no |
| <a name="input_customer_uami_registry_id"></a> [customer\_uami\_registry\_id](#input\_customer\_uami\_registry\_id) | ARM resource ID of customer-created 'registry' UAMI. Required when uami\_mode = 'customer\_managed'. | `string` | `""` | no |
| <a name="input_customer_uami_serverless_id"></a> [customer\_uami\_serverless\_id](#input\_customer\_uami\_serverless\_id) | ARM resource ID of customer-created 'serverless' UAMI. Required when uami\_mode = 'customer\_managed'. | `string` | `""` | no |
| <a name="input_dspm_o365_app_registration_name"></a> [dspm\_o365\_app\_registration\_name](#input\_dspm\_o365\_app\_registration\_name) | The desired DSPM o365 App Regisrtaion name. Leave empty to set dynamically with the subscription name | `string` | `""` | no |
| <a name="input_dspm_o365_sa_email"></a> [dspm\_o365\_sa\_email](#input\_dspm\_o365\_sa\_email) | The DSPM o365 Service Account email address. To be supplied by PANW | `string` | n/a | yes |
| <a name="input_dspm_o365_sa_unique_id"></a> [dspm\_o365\_sa\_unique\_id](#input\_dspm\_o365\_sa\_unique\_id) | The DSPM o365 Service Account unique ID. To be supplied by PANW | `string` | n/a | yes |
| <a name="input_egress_mode"></a> [egress\_mode](#input\_egress\_mode) | Outbound egress routing mode for the scanner VMs in this outpost. The value<br/>is emitted verbatim as the egress feature token in the outpost registration<br/>notification, so it matches what the Cortex platform receives.<br/><br/>  "egress"            - Cortex-managed egress proxy VM. Current behaviour<br/>                        for non-BYON outposts.<br/>  "custom\_networking" - customer-managed proxy reached over your own<br/>                        network. Requires byon\_config; set proxy\_config to<br/>                        describe the proxy.<br/>  "egress\_off"        - no outbound internet at all: no Cortex proxy VM, no<br/>                        customer proxy, no egress path. Scans reach Azure<br/>                        APIs and managed registries (ACR) over private<br/>                        endpoints only. Capabilities that need the public<br/>                        internet (external container registries such as<br/>                        Docker Hub / Artifactory / quay.io) will NOT work.<br/><br/>Leave unset to keep the mode implied by byon\_config ("custom\_networking"<br/>when byon\_config is non-empty, "egress" otherwise), which is the behaviour<br/>that predates this variable.<br/><br/>Switching an existing outpost to "egress\_off" destroys its egress proxy<br/>infrastructure on the next apply. | `string` | `null` | no |
| <a name="input_enable_azure_high_scale_private_endpoints"></a> [enable\_azure\_high\_scale\_private\_endpoints](#input\_enable\_azure\_high\_scale\_private\_endpoints) | Enable High-Scale Private Endpoints (HSPE) network policies on the outpost VNet and private-endpoint subnet. Requires the Microsoft.Network feature EnableMaxPrivateEndpointsVia64kPath to already be registered on the subscription — this module does not register it. Not supported on Azure US Government. | `bool` | `false` | no |
| <a name="input_force_private_key_vaults"></a> [force\_private\_key\_vaults](#input\_force\_private\_key\_vaults) | whether to force the creation of private key vaults. | `bool` | `false` | no |
| <a name="input_force_private_storage_accounts"></a> [force\_private\_storage\_accounts](#input\_force\_private\_storage\_accounts) | whether to force the creation of private storage accounts. | `bool` | `false` | no |
| <a name="input_input_ip_whitelist"></a> [input\_ip\_whitelist](#input\_input\_ip\_whitelist) | A user-input string that contains comma-separated IP addresses or CIDR ranges to allow on the storage accounts and key vaults firewall. CAUTION! Leaving this empty will configure public storage accounts and key vaults which is highly discouraged. Include your machine's public IP to allow Terraform configuration. Example input: 8.8.8.8, 10.0.0.0/24 | `string` | n/a | yes |
| <a name="input_key_vault_secrets_ro_role_id"></a> [key\_vault\_secrets\_ro\_role\_id](#input\_key\_vault\_secrets\_ro\_role\_id) | The key\_vault\_secrets\_ro\_role endpoint role ID. To be used when the custom roles are configured on the management group level, to prevent the creation of identical custom roles when provisioning multiple outposts in the same directory. Leave empty for custom role creation | `string` | `""` | no |
| <a name="input_location_allowlist"></a> [location\_allowlist](#input\_location\_allowlist) | Which Azure locations to allow. If specified, only the locations in this list will be enabled. If not specified, all supported locations will be enabled by default. NOTE: this variable is Azure-only. AWS uses 'enabled\_regions', GCP uses 'region\_allowlist'; those names are silently ignored here, leaving all locations enabled. | `list(string)` | `[]` | no |
| <a name="input_location_denylist"></a> [location\_denylist](#input\_location\_denylist) | Which Azure locations to forbid. If specified, none of the locations in this list will be enabled. | `list(string)` | `[]` | no |
| <a name="input_notification_output_to_local_file"></a> [notification\_output\_to\_local\_file](#input\_notification\_output\_to\_local\_file) | whether to output the outpost notification data to a local file, (used mostly for debugging.) | `bool` | `false` | no |
| <a name="input_outpost_registration_authorization_header_value"></a> [outpost\_registration\_authorization\_header\_value](#input\_outpost\_registration\_authorization\_header\_value) | The value to be attached to the Authorization header for the outpost registration call, so that it can be authenticated | `string` | `""` | no |
| <a name="input_outpost_registration_url_is_pubsub_topic"></a> [outpost\_registration\_url\_is\_pubsub\_topic](#input\_outpost\_registration\_url\_is\_pubsub\_topic) | If set to true, then the outpost registration notification payload will be wrapped in an envelope to publish to Pub/Sub | `bool` | `false` | no |
| <a name="input_outpost_schema_json"></a> [outpost\_schema\_json](#input\_outpost\_schema\_json) | path to JSON schema, used for outpost registration notification | `string` | `"./iacoutput.json"` | no |
| <a name="input_platform_allowed_ips"></a> [platform\_allowed\_ips](#input\_platform\_allowed\_ips) | The default system allow list of public IPs to configure on Storage Accounts and Key Vault. Should contain the Cortext egress IPs | `list(any)` | n/a | yes |
| <a name="input_private_endpoints_role_id"></a> [private\_endpoints\_role\_id](#input\_private\_endpoints\_role\_id) | The private endpoint role ID. To be used when the custom roles are configured on the management group level, to prevent the creation of identical custom roles when provisioning multiple outposts in the same directory. Leave empty for custom role creation | `string` | `""` | no |
| <a name="input_proxy_config"></a> [proxy\_config](#input\_proxy\_config) | Outbound proxy configuration. Only meaningful when byon\_config is<br/>non-empty (BYON mode); cross-validated below. Schema requires<br/>proxy\_config in global\_resources whenever custom\_networking is in<br/>features, so the module always emits it in BYON mode (as either<br/>{enabled=true,...} or {enabled=false}).<br/><br/>Example (no proxy / direct internet):<br/>  proxy\_config = { enabled = false }<br/><br/>Example (proxy with auth, no TLS inspection):<br/>  proxy\_config = {<br/>    enabled      = true<br/>    host         = "proxy.corp.example.com"<br/>    port         = 3128<br/>    auth\_enabled = true<br/>  }<br/><br/>Example (proxy with TLS inspection):<br/>  proxy\_config = {<br/>    enabled         = true<br/>    host            = "proxy.corp.example.com"<br/>    port            = 3128<br/>    tls\_enabled     = true<br/>    ca\_cert\_content = "LS0tLS1CRUdJTi..."<br/>  } | <pre>object({<br/>    enabled         = bool<br/>    host            = optional(string, "")<br/>    port            = optional(number, 3128)<br/>    auth_enabled    = optional(bool, false)<br/>    tls_enabled     = optional(bool, false)<br/>    ca_cert_content = optional(string, "")<br/>  })</pre> | <pre>{<br/>  "enabled": false<br/>}</pre> | no |
| <a name="input_proxy_password"></a> [proxy\_password](#input\_proxy\_password) | Proxy auth password. Required when proxy\_config.auth\_enabled = true. Provide via: terraform apply -var="proxy\_password=..." | `string` | `""` | no |
| <a name="input_proxy_username"></a> [proxy\_username](#input\_proxy\_username) | Proxy auth username. Required when proxy\_config.auth\_enabled = true. Provide via: terraform apply -var="proxy\_username=..." | `string` | `""` | no |
| <a name="input_register_outpost"></a> [register\_outpost](#input\_register\_outpost) | whether to register the outpost by sending the outpost notification output | `bool` | `true` | no |
| <a name="input_resource_group_name_prefix"></a> [resource\_group\_name\_prefix](#input\_resource\_group\_name\_prefix) | Prefix to add to the resource group name, leave empty to use default name. | `string` | `""` | no |
| <a name="input_resource_group_region"></a> [resource\_group\_region](#input\_resource\_group\_region) | target resource group region | `string` | `"westus"` | no |
| <a name="input_storage_sas_policy_expiration"></a> [storage\_sas\_policy\_expiration](#input\_storage\_sas\_policy\_expiration) | the storage SAS expiration policy | `string` | `"00.01:00:00"` | no |
| <a name="input_template_id"></a> [template\_id](#input\_template\_id) | template id, used for uploaded artifacts | `any` | n/a | yes |
| <a name="input_uami_mode"></a> [uami\_mode](#input\_uami\_mode) | Controls scanner UAMI creation:<br/>- "cortex\_managed":   Cortex TF creates 5 UAMIs + 4 AppReg FICs (default).<br/>- "customer\_managed": Customer pre-creates 5 UAMIs (via the BYO setup script shipped with the Cortex BYOA docs, run with --add-uamis);<br/>                      Cortex TF still creates the 4 AppReg FICs + 5 UAMI self-FICs<br/>                      and handles role assignments (incl. RBAC-based KV secret access).<br/>Requires app\_registration\_mode = "customer\_managed". | `string` | `"cortex_managed"` | no |
| <a name="input_upload_output_url"></a> [upload\_output\_url](#input\_upload\_output\_url) | The URL to which the outpost registration should be sent | `string` | n/a | yes |
| <a name="input_url_is_gcs_signed_url"></a> [url\_is\_gcs\_signed\_url](#input\_url\_is\_gcs\_signed\_url) | Control variable for outpost notification request | `bool` | `true` | no |
| <a name="input_workload_orchestrator_role_id"></a> [workload\_orchestrator\_role\_id](#input\_workload\_orchestrator\_role\_id) | The workload orchestrator role ID. To be used when the custom roles are configured on the management group level, to prevent the creation of identical custom roles when provisioning multiple outposts in the same directory. Leave empty for custom role creation | `string` | `""` | no |

## Outputs

| Name | Description |
| ---- | ----------- |
| <a name="output_json_output"></a> [json\_output](#output\_json\_output) | a schema-validated JSON file which contains details of all resources that were created by this module, to be used by the onboarding process. |
| <a name="output_outpost_sp_object_id"></a> [outpost\_sp\_object\_id](#output\_outpost\_sp\_object\_id) | n/a |
| <a name="output_template_version"></a> [template\_version](#output\_template\_version) | n/a |
<!-- END_TF_DOCS -->