# This resource is registering the created outpost with Cortex by uploading the json file which includes the details of all created resources.
locals {
  _http_status_codes = {
    ok       = 200
    accepted = 202
  }
  _outpost_registration_http_timeout_seconds = 30 # Arbitrary
  _notification_request_raw_payload          = local.output_data
}

data "jsonschema_validator" "schema_validation" {
  document = jsonencode(local._notification_request_raw_payload)
  schema   = var.outpost_schema_json
}

# Single "whole outpost applied" gate for the notification, so Cortex is never
# notified about a half-built outpost: if any dependency below fails to apply,
# this gate is never reached and the notification is skipped.
#
# The notification payload (local.output_data) already creates implicit
# dependencies on every resource whose attribute it embeds (resource group,
# module.location outputs, UAMIs, app registrations). This gate adds the
# side-effect resources whose outputs never appear in the payload — role
# assignments, API-access grants, redirect URIs, and federated credentials — so
# a single depends_on subject covers the entire outpost. count/for_each-gated
# entries are no-ops when their count is zero.
resource "terraform_data" "all_resources_applied" {
  depends_on = [
    module.location,
    azurerm_role_assignment.cortex_role_assignment,
    azurerm_role_assignment.cortex_private_endpoint_role_assignment,
    azurerm_role_assignment.byon_vnet_workload_orchestrator_role_assignment,
    azurerm_role_assignment.cortex_storage_queue_role_assignment,
    azurerm_role_assignment.storage_blob_role_assignment,
    azurerm_role_assignment.managed_identity_storage_blob_role_assignment,
    azurerm_role_assignment.registry_managed_identity_storage_blob_role_assignment,
    azurerm_role_assignment.dspm_managed_identity_storage_blob_role_assignment,
    azurerm_role_assignment.serverless_managed_identity_storage_blob_role_assignment,
    azurerm_role_assignment.proxy_managed_identity_storage_blob_proxy_role_assignment,
    azuread_application_api_access.outpost_msgraph_api,
    azuread_application_api_access.outpost_o365_msgraph_api,
    azuread_application_api_access.outpost_o365_sharepoint_api,
    azuread_application_api_access.outpost_o365_rms_api,
    azuread_application_redirect_uris.outpost_registration_redirect_uri,
    azuread_application_redirect_uris.outpost_registration_redirect_uri_o365_app,
    azuread_application_federated_identity_credential.federated_cts_gke_serviceaccount,
    azuread_application_federated_identity_credential.federated_dspm_managed_identity,
    azuread_application_federated_identity_credential.federated_registry_managed_identity,
    azuread_application_federated_identity_credential.federated_serverless_managed_identity,
    azuread_application_federated_identity_credential.federated_cts_gke_serviceaccount_o365_app,
    azuread_application_federated_identity_credential.federated_dspm_managed_identity_o365_app,
    azurerm_federated_identity_credential.uami_self_fic,
  ]
}

# Register this outpost with Cortex
resource "terracurl_request" "outpost_registration" {
  count          = var.register_outpost ? 1 : 0
  name           = "azure-outpost-registration"
  response_codes = [local._http_status_codes.ok, local._http_status_codes.accepted]
  method         = var.url_is_gcs_signed_url ? "PUT" : "POST"
  url            = var.upload_output_url
  skip_destroy   = true

  headers = {
    Authorization = var.outpost_registration_authorization_header_value
    Content-type  = "application/json"
  }

  timeout   = local._outpost_registration_http_timeout_seconds
  max_retry = 3
  request_body = var.outpost_registration_url_is_pubsub_topic ? jsonencode({
    messages = [
      {
        data = base64encode(jsonencode(local._notification_request_raw_payload))
      }
    ]
  }) : jsonencode(local._notification_request_raw_payload)

  # Fire only after the whole outpost has applied: the schema validation of the
  # payload, plus the all_resources_applied gate above.
  depends_on = [
    data.jsonschema_validator.schema_validation,
    terraform_data.all_resources_applied,
  ]
}


resource "local_file" "outpost_registration" {
  count    = var.notification_output_to_local_file ? 1 : 0
  content  = jsonencode(local._notification_request_raw_payload)
  filename = "${path.module}/azure_outpost_registration.json"

  # Same rationale as terracurl_request.outpost_registration above.
  depends_on = [
    data.jsonschema_validator.schema_validation,
    terraform_data.all_resources_applied,
  ]
}