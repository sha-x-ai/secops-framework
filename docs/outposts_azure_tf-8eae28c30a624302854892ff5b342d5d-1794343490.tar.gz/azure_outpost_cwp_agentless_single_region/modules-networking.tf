# Networking inner module: owns the outpost VNet/subnet/NSG (Cortex-managed) or
# resolves the customer-supplied VNet/subnet (BYON). The ASGs stay in this
# parent module (they're exported to the notification JSON) and their IDs are
# passed in for the NSG rules.

module "networking" {
  source = "./networking"

  location            = var.location
  resource_group_name = var.resource_group_name
  tags_all            = var.tags_all
  azure_us_government = var.azure_us_government

  enable_azure_high_scale_private_endpoints  = var.enable_azure_high_scale_private_endpoints
  high_scale_private_endpoints_subnet_policy = var.high_scale_private_endpoints_subnet_policy

  customer_virtual_network_id = var.customer_virtual_network_id
  customer_subnet_id          = var.customer_subnet_id

  egress_mode             = var.egress_mode
  scanner_asg_id          = azurerm_application_security_group.scanner.id
  proxy_asg_id            = azurerm_application_security_group.proxy.id
  private_endpoint_asg_id = azurerm_application_security_group.private_endpoint.id
}
