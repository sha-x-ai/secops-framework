# The Key Vault uses RBAC authorization (rbac_authorization_enabled = true on
#   azurerm_key_vault.outpost_key_vault), so access is granted through Azure role
#   assignments rather than Key Vault access policies.
#
# All required role assignments are made in the PARENT module at the resource-group
#   scope (which Azure RBAC inherits down to this Key Vault):
#     - The outpost App Registration SP gets secret get/set/delete/purge via the
#       custom workload-orchestrator role (azurerm_role_definition.app_registration_cortex_role).
#     - The registry / dspm / proxy user-assigned identities get secret get/list via
#       the custom read-only role (azurerm_role_definition.key_vault_secrets_ro_role),
#       assigned in resources-azurerm-role-assigment.tf.
#
# Therefore no per-region access policies or role assignments are needed here.
