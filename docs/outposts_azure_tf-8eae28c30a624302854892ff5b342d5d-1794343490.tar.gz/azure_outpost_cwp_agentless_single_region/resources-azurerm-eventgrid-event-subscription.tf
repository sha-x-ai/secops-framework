# We configure EventGrid to send a notification to the bucket-communication storage queue when a new blob is created in the Storage Account.
#   > This allows the cortex platform to be notified when a new blob is added to the storage by scanner VMs.

resource "azurerm_eventgrid_system_topic_event_subscription" "bucket_communication" {
  name                 = "${random_string.eventgrid_topic_random_name.result}-sub"
  included_event_types = ["Microsoft.Storage.BlobCreated"]
  system_topic         = azurerm_eventgrid_system_topic.eventgrid_topic.name
  resource_group_name  = var.resource_group_name

  storage_queue_endpoint {
    storage_account_id = azurerm_storage_account.storage_account.id
    queue_name         = azurerm_storage_queue.bucket_communication.name
  }

  subject_filter {
    ## "default" seems to be hard-coded
    ## ref: https://learn.microsoft.com/en-us/azure/storage/blobs/storage-blob-event-overview#filtering-events
    subject_begins_with = "/blobServices/default/containers/${azurerm_storage_container.bucket_communication.name}/blobs/output/"
  }
}