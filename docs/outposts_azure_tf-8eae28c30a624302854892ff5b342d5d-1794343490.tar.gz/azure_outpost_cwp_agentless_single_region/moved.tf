# ── Parent-level migrations (resources that stayed in this module) ───────────

moved {
  from = azurerm_application_security_group.private_endpoint_asg
  to   = azurerm_application_security_group.private_endpoint
}

moved {
  from = azurerm_role_assignment.wo_private_endpoint_role_assignment
  to   = azurerm_role_assignment.cortex_private_endpoint_role_assignment
}

moved {
  from = azurerm_role_assignment.wo_role_assignment
  to   = azurerm_role_assignment.cortex_role_assignment
}

moved {
  from = azurerm_role_assignment.fetcher_storage_queue_role_assignment
  to   = azurerm_role_assignment.cortex_storage_queue_role_assignment
}

moved {
  from = azurerm_role_definition.app_registration_wo_role
  to   = azurerm_role_definition.app_registration_cortex_role
}

# ── Networking inner-module migrations ───────────────────────────────────────
# All networking resources moved into module.networking. These blocks migrate
# existing state from the old single_region addresses (incl. the historical
# renames) into the child module, and to the `[0]` suffix for resources that
# gained `count` for BYON. No-op once state already matches.

# Historical renames that now also cross into the module.
# These are expressed as chained moves so each destination has exactly one
# source: the oldest name moves to the intermediate (current) name, which in
# turn moves into module.networking below. Terraform resolves the chain.
moved {
  from = azurerm_network_security_group.outpost-network-security-group
  to   = azurerm_network_security_group.outpost
}
moved {
  from = azurerm_network_security_group.outpost
  to   = module.networking.azurerm_network_security_group.outpost
}
moved {
  from = azurerm_network_security_rule.nsg_deny_all_inbound_rule
  to   = azurerm_network_security_rule.deny_all_inbound_rule
}

# VNet / subnet / association / suffix — into the module, with `[0]`.
moved {
  from = azurerm_virtual_network.outpost_vnet
  to   = module.networking.azurerm_virtual_network.outpost_vnet[0]
}
moved {
  from = azurerm_subnet.outpost_subnet
  to   = module.networking.azurerm_subnet.outpost_subnet[0]
}
moved {
  from = azurerm_subnet_network_security_group_association.outpost_subnet_nsg_association
  to   = module.networking.azurerm_subnet_network_security_group_association.outpost_subnet_nsg_association[0]
}
moved {
  from = random_string.subnet_suffix
  to   = module.networking.random_string.subnet_suffix[0]
}

# Egress NSG rules.
moved {
  from = azurerm_network_security_rule.allow_storage_outbound_scanner
  to   = module.networking.azurerm_network_security_rule.allow_storage_outbound_scanner[0]
}
moved {
  from = azurerm_network_security_rule.allow_key_vault_outbound_scanner
  to   = module.networking.azurerm_network_security_rule.allow_key_vault_outbound_scanner[0]
}
moved {
  from = azurerm_network_security_rule.allow_sql_outbound_scanner
  to   = module.networking.azurerm_network_security_rule.allow_sql_outbound_scanner[0]
}
moved {
  from = azurerm_network_security_rule.allow_cosmosdb_outbound_scanner
  to   = module.networking.azurerm_network_security_rule.allow_cosmosdb_outbound_scanner[0]
}
moved {
  from = azurerm_network_security_rule.allow_azure_cloud_outbound_scanner
  to   = module.networking.azurerm_network_security_rule.allow_azure_cloud_outbound_scanner[0]
}
moved {
  from = azurerm_network_security_rule.allow_private_endpoint_scanner
  to   = module.networking.azurerm_network_security_rule.allow_private_endpoint_scanner[0]
}
moved {
  from = azurerm_network_security_rule.allow_storage_outbound_proxy
  to   = module.networking.azurerm_network_security_rule.allow_storage_outbound_proxy[0]
}
moved {
  from = azurerm_network_security_rule.allow_azure_cloud_outbound_proxy
  to   = module.networking.azurerm_network_security_rule.allow_azure_cloud_outbound_proxy[0]
}
moved {
  from = azurerm_network_security_rule.allow_outbound_to_proxy_scanner_vms
  to   = module.networking.azurerm_network_security_rule.allow_outbound_to_proxy_scanner_vms[0]
}
moved {
  from = azurerm_network_security_rule.deny_proxy_vm_outbound_to_subnet
  to   = module.networking.azurerm_network_security_rule.deny_proxy_vm_outbound_to_subnet[0]
}
moved {
  from = azurerm_network_security_rule.allow_proxy_vm_outbound
  to   = module.networking.azurerm_network_security_rule.allow_proxy_vm_outbound[0]
}
moved {
  from = azurerm_network_security_rule.deny_all_outbound_rule
  to   = module.networking.azurerm_network_security_rule.deny_all_outbound_rule[0]
}

# Cognitive-services egress rules. These ALREADY had `count` on dev
# (count = is_cognitive_services_enabled_region ? 1 : 0), so the existing state
# address is `[0]`. The ONLY change is the new module.networking prefix —
# therefore `from` must keep the `[0]` index to match the deployed state.
# (Writing `from` without `[0]` makes Terraform see the old `[0]` rule as
# "not in configuration" and destroy it — the bug this fixes.)
moved {
  from = azurerm_network_security_rule.allow_active_directory_outbound_scanner[0]
  to   = module.networking.azurerm_network_security_rule.allow_active_directory_outbound_scanner[0]
}
moved {
  from = azurerm_network_security_rule.allow_frontdoor_outbound_scanner[0]
  to   = module.networking.azurerm_network_security_rule.allow_frontdoor_outbound_scanner[0]
}
moved {
  from = azurerm_network_security_rule.allow_resource_manager_outbound_scanner[0]
  to   = module.networking.azurerm_network_security_rule.allow_resource_manager_outbound_scanner[0]
}
moved {
  from = azurerm_network_security_rule.allow_cognitive_services_management_outbound_scanner[0]
  to   = module.networking.azurerm_network_security_rule.allow_cognitive_services_management_outbound_scanner[0]
}
moved {
  from = azurerm_network_security_rule.allow_cognitive_services_frontend_outbound_scanner[0]
  to   = module.networking.azurerm_network_security_rule.allow_cognitive_services_frontend_outbound_scanner[0]
}

# Ingress NSG rules.
moved {
  from = azurerm_network_security_rule.allow_private_endpoint_inbound_scanner
  to   = module.networking.azurerm_network_security_rule.allow_private_endpoint_inbound_scanner[0]
}
moved {
  from = azurerm_network_security_rule.allow_proxy_inbound_from_scanner_vm
  to   = module.networking.azurerm_network_security_rule.allow_proxy_inbound_from_scanner_vm[0]
}
moved {
  from = azurerm_network_security_rule.deny_all_inbound_rule
  to   = module.networking.azurerm_network_security_rule.deny_all_inbound_rule[0]
}
