variable "location" {}
variable "platform_allowed_ips" {}
variable "subscription_name" {}
variable "sas_policy_expiration_period" {}
variable "tags_all" {}
variable "resource_group_name" {
  type = string
}
variable "create_public_storage_accounts" {}
variable "create_public_key_vaults" {}
variable "azure_tenant_id" {}
variable "dspm_idtntity_principal_id" {}
variable "registry_identity_principal_id" {}
variable "azure_us_government" {
  type = bool
}
variable "enable_azure_high_scale_private_endpoints" {
  type    = bool
  default = false
}
variable "high_scale_private_endpoints_subnet_policy" {
  type    = string
  default = "Enabled"
}
