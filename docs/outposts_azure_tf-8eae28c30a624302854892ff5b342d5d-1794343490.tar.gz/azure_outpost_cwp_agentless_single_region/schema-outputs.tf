output "network_security_group_id" {
  value = module.networking.network_security_group_id
}

output "resource_group_name" {
  value = var.resource_group_name
}

output "storage_account_name" {
  value = azurerm_storage_account.storage_account.name
}

output "storage_container_name" {
  value = azurerm_storage_container.bucket_communication.name
}

output "artifact_storage_container_name" {
  value = azurerm_storage_container.artifact_container.name
}

output "storage_queue_name" {
  value = azurerm_storage_queue.bucket_communication.name
}

# Resolve to the customer-supplied IDs in BYON, else the Cortex-created ones.
output "subnet_id" {
  value = module.networking.subnet_id
}

output "vnet_id" {
  value = module.networking.vnet_id
}

output "private_endpoint_asg_id" {
  value = azurerm_application_security_group.private_endpoint.id
}

output "proxy_asg_id" {
  value = azurerm_application_security_group.proxy.id
}

output "scanner_asg_id" {
  value = azurerm_application_security_group.scanner.id
}

output "key_vault_id" {
  value = azurerm_key_vault.outpost_key_vault.id
}

# BYON+proxy_auth — versionless ARM ID of the proxy-creds KV secret so the WO
# always reads the latest version. Empty when proxy_auth_enabled = false.
output "proxy_credentials_secret_id" {
  value = var.proxy_auth_enabled ? azurerm_key_vault_secret.proxy_credentials[0].resource_versionless_id : ""
}
