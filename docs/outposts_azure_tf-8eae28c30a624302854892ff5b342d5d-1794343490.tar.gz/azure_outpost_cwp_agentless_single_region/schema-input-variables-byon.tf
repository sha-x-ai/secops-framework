# ── BYON (Bring-Your-Own Network) variables — single-region scope ────────────
# Set by the root module from var.byon_config[<this region>] (or null when
# this region is Cortex-managed). When customer_virtual_network_id is null
# the module creates its own VNet+subnet (legacy behavior).

variable "customer_virtual_network_id" {
  description = "ARM resource ID of the customer-supplied VNet for this region. null = Cortex creates one."
  type        = string
  default     = null
}

variable "customer_subnet_id" {
  description = "ARM resource ID of the customer-supplied subnet for this region. null = Cortex creates one. Must be inside customer_virtual_network_id."
  type        = string
  default     = null
}

# ── Proxy auth — single-region scope ─────────────────────────────────────────
# When proxy_auth_enabled = true, the module stores the credentials in a
# per-region KV secret and grants the proxy UAMI Get on it.

variable "proxy_auth_enabled" {
  description = "When true, create a Key Vault secret holding proxy credentials (BYON+proxy_auth mode)."
  type        = bool
  default     = false
}

variable "proxy_username" {
  description = "Proxy auth username (sensitive). Stored in the per-region KV secret when proxy_auth_enabled = true."
  type        = string
  default     = ""
  sensitive   = true
}

variable "proxy_password" {
  description = "Proxy auth password (sensitive). Stored in the per-region KV secret when proxy_auth_enabled = true."
  type        = string
  default     = ""
  sensitive   = true
}

variable "proxy_identity_principal_id" {
  description = "Object ID of the proxy UAMI (Cortex-created or customer-supplied). Granted Get on the proxy_credentials KV secret when proxy_auth_enabled = true. Required (non-empty) when proxy_auth_enabled = true; the root module always passes the resolved UAMI principal_id."
  type        = string
  default     = ""
  validation {
    # Empty value here when proxy_auth_enabled = true would produce a
    # confusing Azure-side error on the proxy KV role assignment.
    condition     = !var.proxy_auth_enabled || var.proxy_identity_principal_id != ""
    error_message = "proxy_identity_principal_id must be non-empty when proxy_auth_enabled = true."
  }
}

variable "egress_mode" {
  description = <<-EOT
    Resolved outbound egress routing mode for this outpost ("egress",
    "custom_networking" or "egress_off"), passed down from the parent module.
    "egress_off" means no Cortex proxy VM in this region.
  EOT
  type        = string
  default     = "egress"

  validation {
    condition     = contains(["egress", "custom_networking", "egress_off"], var.egress_mode)
    error_message = "egress_mode must be one of \"egress\", \"custom_networking\" or \"egress_off\"."
  }
}
