# BYON+proxy_auth — per-region KV secret holding the proxy credentials, read
# by the proxy UAMI at boot (Get granted via the Key Vault Secrets User role).

resource "azurerm_key_vault_secret" "proxy_credentials" {
  # checkov:skip=CKV_AZURE_41:No expiration is set intentionally - these are long-lived BYON proxy credentials read by the proxy UAMI at boot. There is no rotation mechanism, so an expiration date would break proxy authentication when it lapses. The secret lives in a purge-protected Key Vault with network ACLs restricting access to platform IPs.
  count        = var.proxy_auth_enabled ? 1 : 0
  name         = "cortex-proxy-credentials"
  key_vault_id = azurerm_key_vault.outpost_key_vault.id
  content_type = "application/json"
  # Base64-wrapped JSON — the scan runner expects base64 and rejects raw JSON.
  value = base64encode(jsonencode({
    username = var.proxy_username
    password = var.proxy_password
  }))
}
