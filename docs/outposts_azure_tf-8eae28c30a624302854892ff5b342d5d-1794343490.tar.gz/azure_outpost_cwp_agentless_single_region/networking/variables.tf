# ── Networking inner-module inputs ───────────────────────────────────────────
# Owns the outpost VNet/subnet/NSG (Cortex-managed mode) or resolves the
# customer-supplied VNet/subnet (BYON mode). The parent single_region module
# keeps the ASGs and passes their IDs in here for the NSG rules.

variable "location" {
  description = "Azure location for this region."
  type        = string
}

variable "resource_group_name" {
  description = "Outpost resource group name."
  type        = string
}

variable "tags_all" {
  description = "Tags applied to all networking resources."
  type        = map(string)
  default     = {}
}

variable "azure_us_government" {
  description = "Whether this is an Azure US Government deployment."
  type        = bool
  default     = false
}

variable "enable_azure_high_scale_private_endpoints" {
  description = "Whether High-Scale Private Endpoints are enabled (public only; false on gov)."
  type        = bool
  default     = false
}

variable "high_scale_private_endpoints_subnet_policy" {
  description = "Private endpoint network policy for the outpost subnet when HSPE is enabled. Valid values: 'Enabled' (default) or 'RouteTableEnabled' (for route-table-based routing to the PE subnet)."
  type        = string
  default     = "Enabled"
}

# ── BYON ─────────────────────────────────────────────────────────────────────
variable "customer_virtual_network_id" {
  description = "ARM resource ID of the customer-supplied VNet for this region. null = Cortex creates one."
  type        = string
  default     = null
}

variable "customer_subnet_id" {
  description = "ARM resource ID of the customer-supplied subnet for this region. null = Cortex creates one. Must be inside customer_virtual_network_id."
  type        = string
  default     = null
}

# ── ASG IDs (owned by the parent module, referenced by the NSG rules here) ────
variable "scanner_asg_id" {
  description = "ID of the scanner Application Security Group."
  type        = string
}

variable "proxy_asg_id" {
  description = "ID of the proxy Application Security Group."
  type        = string
}

variable "private_endpoint_asg_id" {
  description = "ID of the private-endpoint Application Security Group."
  type        = string
}
