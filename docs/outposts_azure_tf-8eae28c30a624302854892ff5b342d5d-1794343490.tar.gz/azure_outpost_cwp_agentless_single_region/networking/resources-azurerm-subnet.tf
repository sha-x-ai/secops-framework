# Configuring the Outpost subnet where scanner VMs are running on.
# Skipped in BYON mode — the customer supplies their own subnet via
# var.customer_subnet_id (resolved through local.final_subnet_id).

resource "random_string" "subnet_suffix" {
  count   = local.is_byon ? 0 : 1
  length  = 16
  special = false
  upper   = false
}

resource "azurerm_subnet" "outpost_subnet" {
  count                             = local.is_byon ? 0 : 1
  resource_group_name               = var.resource_group_name
  virtual_network_name              = azurerm_virtual_network.outpost_vnet[0].name
  name                              = random_string.subnet_suffix[0].result
  default_outbound_access_enabled   = false
  service_endpoints                 = local.service_endpoints_list
  address_prefixes                  = ["${local.azurerm_virtual_network.location_cidr_map[var.location]}/20"]
  private_endpoint_network_policies = var.azure_us_government ? "Disabled" : (var.enable_azure_high_scale_private_endpoints ? var.high_scale_private_endpoints_subnet_policy : "NetworkSecurityGroupEnabled")

  lifecycle {
    ignore_changes = [name]
  }
}
