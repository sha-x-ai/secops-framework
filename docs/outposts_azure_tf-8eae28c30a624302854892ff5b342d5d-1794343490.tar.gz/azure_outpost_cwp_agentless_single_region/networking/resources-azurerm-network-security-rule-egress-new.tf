# Outbound rules:
# Scanner ASGs can egress to the regional Azure Storage Service Tags, to allow the bucket-communication process.
# Scanner ASGs can egress to regional and global Azure Service Tags, the proxy ASG and the private endpint ASG to enable asset discovery, risk detection and data classification of cloud resources.
# All other Outbound traffic is denied by default.
#
# Skipped in BYON (count = is_byon ? 0 : 1): the NSG is never attached to the
# customer's subnet, so the customer owns subnet-level control.
#
# `depends_on = [deny_all_outbound_rule]` serialises rule creation to dodge
# azurerm's "operation in progress on the security group" 429s — not for NSG
# evaluation order (that's `priority`).

resource "azurerm_network_security_rule" "allow_storage_outbound_scanner" {
  count                                 = local.is_byon ? 0 : 1
  name                                  = "AllowAzureStorageOutboundFromScannerVms"
  priority                              = 100
  direction                             = "Outbound"
  access                                = "Allow"
  protocol                              = "*"
  source_port_range                     = "*"
  destination_port_range                = "443"
  resource_group_name                   = var.resource_group_name
  network_security_group_name           = azurerm_network_security_group.outpost.name
  source_application_security_group_ids = [var.scanner_asg_id]
  destination_address_prefix            = local.azurerm_virtual_network.location_service_tags.storage[var.location]
  depends_on                            = [azurerm_network_security_rule.deny_all_outbound_rule]

  # This is to avoid a known bug - the Azure resource manager API returns security group IDs with capital letters, which forces recreation of the resources
  # https://github.com/hashicorp/terraform-provider-azurerm/issues/29841
  lifecycle {
    ignore_changes = [source_application_security_group_ids]
  }
}

resource "azurerm_network_security_rule" "allow_key_vault_outbound_scanner" {
  count                                 = local.is_byon ? 0 : 1
  name                                  = "AllowAzureKeyVaultOutboundFromScannerVms"
  priority                              = 110
  direction                             = "Outbound"
  access                                = "Allow"
  protocol                              = "*"
  source_port_range                     = "*"
  destination_port_range                = "443"
  resource_group_name                   = var.resource_group_name
  network_security_group_name           = azurerm_network_security_group.outpost.name
  source_application_security_group_ids = [var.scanner_asg_id]
  destination_address_prefix            = local.azurerm_virtual_network.location_service_tags.keyvault[var.location]
  depends_on                            = [azurerm_network_security_rule.deny_all_outbound_rule]
  lifecycle {
    ignore_changes = [source_application_security_group_ids]
  }
}

# DSPM Module
resource "azurerm_network_security_rule" "allow_sql_outbound_scanner" {
  count                                 = local.is_byon ? 0 : 1
  name                                  = "AllowAzureSqlOutboundFromScannerVms"
  priority                              = 120
  direction                             = "Outbound"
  access                                = "Allow"
  protocol                              = "*"
  source_port_range                     = "*"
  destination_port_ranges               = ["1433", "11000-11999"]
  resource_group_name                   = var.resource_group_name
  network_security_group_name           = azurerm_network_security_group.outpost.name
  source_application_security_group_ids = [var.scanner_asg_id]
  destination_address_prefix            = local.azurerm_virtual_network.location_service_tags.sql[var.location]
  depends_on                            = [azurerm_network_security_rule.deny_all_outbound_rule]
  lifecycle {
    ignore_changes = [source_application_security_group_ids]
  }
}

# DSPM Module
resource "azurerm_network_security_rule" "allow_cosmosdb_outbound_scanner" {
  count                                 = local.is_byon ? 0 : 1
  name                                  = "AllowAzureCosmosDbOutboundFromScannerVms"
  priority                              = 130
  direction                             = "Outbound"
  access                                = "Allow"
  protocol                              = "*"
  source_port_range                     = "*"
  destination_port_range                = "10255"
  resource_group_name                   = var.resource_group_name
  network_security_group_name           = azurerm_network_security_group.outpost.name
  source_application_security_group_ids = [var.scanner_asg_id]
  destination_address_prefix            = local.azurerm_virtual_network.location_service_tags.cosmosdb[var.location]
  depends_on                            = [azurerm_network_security_rule.deny_all_outbound_rule]
  lifecycle {
    ignore_changes = [source_application_security_group_ids]
  }
}

# DSPM Module
resource "azurerm_network_security_rule" "allow_active_directory_outbound_scanner" {
  count                                 = local.is_byon ? 0 : (local.is_cognitive_services_enabled_region ? 1 : 0)
  name                                  = "AllowAzureActiveDirectoryOutboundFromScannerVms"
  priority                              = 140
  direction                             = "Outbound"
  access                                = "Allow"
  protocol                              = "*"
  source_port_range                     = "*"
  destination_port_range                = "443"
  resource_group_name                   = var.resource_group_name
  network_security_group_name           = azurerm_network_security_group.outpost.name
  source_application_security_group_ids = [var.scanner_asg_id]
  destination_address_prefix            = "AzureActiveDirectory"
  depends_on                            = [azurerm_network_security_rule.deny_all_outbound_rule]
  lifecycle {
    ignore_changes = [source_application_security_group_ids]
  }
}

# DSPM Module
resource "azurerm_network_security_rule" "allow_frontdoor_outbound_scanner" {
  count                                 = local.is_byon ? 0 : (local.is_cognitive_services_enabled_region ? 1 : 0)
  name                                  = "AllowAzureFrontDoorOutboundFromScannerVms"
  priority                              = 150
  direction                             = "Outbound"
  access                                = "Allow"
  protocol                              = "*"
  source_port_range                     = "*"
  destination_port_range                = "443"
  resource_group_name                   = var.resource_group_name
  network_security_group_name           = azurerm_network_security_group.outpost.name
  source_application_security_group_ids = [var.scanner_asg_id]
  destination_address_prefix            = "AzureFrontDoor.Frontend"
  depends_on                            = [azurerm_network_security_rule.deny_all_outbound_rule]
  lifecycle {
    ignore_changes = [source_application_security_group_ids]
  }
}

resource "azurerm_network_security_rule" "allow_resource_manager_outbound_scanner" {
  count                                 = local.is_byon ? 0 : (local.is_cognitive_services_enabled_region ? 1 : 0)
  name                                  = "AllowAzureResourceManagerOutboundFromScannerVms"
  priority                              = 160
  direction                             = "Outbound"
  access                                = "Allow"
  protocol                              = "*"
  source_port_range                     = "*"
  destination_port_range                = "443"
  resource_group_name                   = var.resource_group_name
  network_security_group_name           = azurerm_network_security_group.outpost.name
  source_application_security_group_ids = [var.scanner_asg_id]
  destination_address_prefix            = "AzureResourceManager"
  depends_on                            = [azurerm_network_security_rule.deny_all_outbound_rule]
  lifecycle {
    ignore_changes = [source_application_security_group_ids]
  }
}

# DSPM Module
resource "azurerm_network_security_rule" "allow_cognitive_services_management_outbound_scanner" {
  count                                 = local.is_byon ? 0 : (local.is_cognitive_services_enabled_region ? 1 : 0)
  name                                  = "AllowAzureCognitiveServicesManagementOutboundFromScannerVms"
  priority                              = 170
  direction                             = "Outbound"
  access                                = "Allow"
  protocol                              = "*"
  source_port_range                     = "*"
  destination_port_range                = "443"
  resource_group_name                   = var.resource_group_name
  network_security_group_name           = azurerm_network_security_group.outpost.name
  source_application_security_group_ids = [var.scanner_asg_id]
  destination_address_prefix            = "CognitiveServicesManagement"
  depends_on                            = [azurerm_network_security_rule.deny_all_outbound_rule]
  lifecycle {
    ignore_changes = [source_application_security_group_ids]
  }
}

# DSPM Module
resource "azurerm_network_security_rule" "allow_cognitive_services_frontend_outbound_scanner" {
  count                                 = local.is_byon ? 0 : (local.is_cognitive_services_enabled_region ? 1 : 0)
  name                                  = "AllowAzureCognitiveServicesFrontendOutboundFromScannerVms"
  priority                              = 180
  direction                             = "Outbound"
  access                                = "Allow"
  protocol                              = "*"
  source_port_range                     = "*"
  destination_port_range                = "443"
  resource_group_name                   = var.resource_group_name
  network_security_group_name           = azurerm_network_security_group.outpost.name
  source_application_security_group_ids = [var.scanner_asg_id]
  destination_address_prefix            = "CognitiveServicesFrontend"
  depends_on                            = [azurerm_network_security_rule.deny_all_outbound_rule]
  lifecycle {
    ignore_changes = [source_application_security_group_ids]
  }
}

# DSPM, Registry, Serverless modules
resource "azurerm_network_security_rule" "allow_azure_cloud_outbound_scanner" {
  count                                 = local.is_byon ? 0 : 1
  name                                  = "AllowAzureCloudOutboundFromScannerVms"
  priority                              = 190
  direction                             = "Outbound"
  access                                = "Allow"
  protocol                              = "*"
  source_port_range                     = "*"
  destination_port_range                = "443"
  resource_group_name                   = var.resource_group_name
  network_security_group_name           = azurerm_network_security_group.outpost.name
  source_application_security_group_ids = [var.scanner_asg_id]
  destination_address_prefix            = "AzureCloud"
  depends_on                            = [azurerm_network_security_rule.deny_all_outbound_rule]
  lifecycle {
    ignore_changes = [source_application_security_group_ids]
  }
}

# DSPM, Registry modules
resource "azurerm_network_security_rule" "allow_private_endpoint_scanner" {
  count                                      = local.is_byon ? 0 : 1
  name                                       = "AllowSubnetPrivateEndpointFromScannerVms"
  priority                                   = 210
  direction                                  = "Outbound"
  access                                     = "Allow"
  protocol                                   = "Tcp"
  source_port_range                          = "*"
  destination_port_ranges                    = ["443", "1433"]
  source_application_security_group_ids      = [var.scanner_asg_id]
  destination_application_security_group_ids = [var.private_endpoint_asg_id]
  resource_group_name                        = var.resource_group_name
  network_security_group_name                = azurerm_network_security_group.outpost.name
  depends_on                                 = [azurerm_network_security_rule.deny_all_outbound_rule]
  lifecycle {
    ignore_changes = [source_application_security_group_ids, destination_application_security_group_ids]
  }
}

resource "azurerm_network_security_rule" "allow_storage_outbound_proxy" {
  count                                 = local.create_proxy_nsg_rules ? 1 : 0
  name                                  = "AllowAzureStorageOutboundFromProxyVms"
  priority                              = 315
  direction                             = "Outbound"
  access                                = "Allow"
  protocol                              = "*"
  source_port_range                     = "*"
  destination_port_range                = "443"
  resource_group_name                   = var.resource_group_name
  network_security_group_name           = azurerm_network_security_group.outpost.name
  source_application_security_group_ids = [var.proxy_asg_id]
  destination_address_prefix            = local.azurerm_virtual_network.location_service_tags.storage[var.location]
  depends_on                            = [azurerm_network_security_rule.deny_all_outbound_rule]
  lifecycle {
    ignore_changes = [name, source_application_security_group_ids]
  }
}

resource "azurerm_network_security_rule" "allow_azure_cloud_outbound_proxy" {
  count                                 = local.create_proxy_nsg_rules ? 1 : 0
  name                                  = "AllowAzureCloudOutboundFromProxyVms"
  priority                              = 490
  direction                             = "Outbound"
  access                                = "Allow"
  protocol                              = "*"
  source_port_range                     = "*"
  destination_port_range                = "443"
  resource_group_name                   = var.resource_group_name
  network_security_group_name           = azurerm_network_security_group.outpost.name
  source_application_security_group_ids = [var.proxy_asg_id]
  destination_address_prefix            = "AzureCloud"
  depends_on                            = [azurerm_network_security_rule.deny_all_outbound_rule]
  lifecycle {
    ignore_changes = [source_application_security_group_ids]
  }
}

resource "azurerm_network_security_rule" "allow_outbound_to_proxy_scanner_vms" {
  count                                      = local.create_proxy_nsg_rules ? 1 : 0
  name                                       = "AllowOutboundToProxyFromScannerVms"
  priority                                   = 950
  direction                                  = "Outbound"
  access                                     = "Allow"
  protocol                                   = "*"
  source_port_range                          = "*"
  destination_port_range                     = "10000"
  resource_group_name                        = var.resource_group_name
  network_security_group_name                = azurerm_network_security_group.outpost.name
  source_application_security_group_ids      = [var.scanner_asg_id]
  destination_application_security_group_ids = [var.proxy_asg_id]
  depends_on                                 = [azurerm_network_security_rule.deny_all_outbound_rule]
  lifecycle {
    ignore_changes = [source_application_security_group_ids, destination_application_security_group_ids]
  }
}

# Allow egress to OPA health check on the proxy ASG (port 10001).
resource "azurerm_network_security_rule" "allow_outbound_to_proxy_opa_healthcheck_scanner_vms" {
  count                                      = local.create_proxy_nsg_rules ? 1 : 0
  name                                       = "AllowOutboundToProxyOpaHealthCheckFromScannerVms"
  priority                                   = 951
  direction                                  = "Outbound"
  access                                     = "Allow"
  protocol                                   = "*"
  source_port_range                          = "*"
  destination_port_range                     = "10001"
  resource_group_name                        = var.resource_group_name
  network_security_group_name                = azurerm_network_security_group.outpost.name
  source_application_security_group_ids      = [var.scanner_asg_id]
  destination_application_security_group_ids = [var.proxy_asg_id]
  depends_on                                 = [azurerm_network_security_rule.deny_all_outbound_rule]
  lifecycle {
    ignore_changes = [source_application_security_group_ids, destination_application_security_group_ids]
  }
}

resource "azurerm_network_security_rule" "deny_proxy_vm_outbound_to_subnet" {
  count                                 = local.create_proxy_nsg_rules ? 1 : 0
  name                                  = "DenyProxyOutboundToSubnet"
  priority                              = 1000
  direction                             = "Outbound"
  access                                = "Deny"
  protocol                              = "Tcp"
  source_port_range                     = "*"
  destination_port_range                = "*"
  resource_group_name                   = var.resource_group_name
  network_security_group_name           = azurerm_network_security_group.outpost.name
  source_application_security_group_ids = [var.proxy_asg_id]
  destination_address_prefixes          = local.final_subnet_address_prefixes
  depends_on                            = [azurerm_network_security_rule.deny_all_outbound_rule]

  lifecycle {
    ignore_changes = [source_application_security_group_ids]
  }
}

resource "azurerm_network_security_rule" "allow_proxy_vm_outbound" {
  count             = local.create_proxy_nsg_rules ? 1 : 0
  name              = "AllowProxyOutboundToAll"
  priority          = 1100
  direction         = "Outbound"
  access            = "Allow"
  protocol          = "Tcp"
  source_port_range = "*"
  # Port 80 is required for Snowflake classification: https://docs.snowflake.com/en/user-guide/ocsp#ocsp-certification-checks-require-port-80
  # Port 27017 is required for MongoDB Atlas connectivity
  destination_port_ranges               = ["443", "80", "27017"]
  resource_group_name                   = var.resource_group_name
  network_security_group_name           = azurerm_network_security_group.outpost.name
  source_application_security_group_ids = [var.proxy_asg_id]
  destination_address_prefix            = "*"
  depends_on                            = [azurerm_network_security_rule.deny_all_outbound_rule]
  lifecycle {
    ignore_changes = [source_application_security_group_ids]
  }
}

resource "azurerm_network_security_rule" "deny_all_outbound_rule" {
  count                       = local.is_byon ? 0 : 1
  name                        = "DenyAllOutbound"
  priority                    = 4095
  direction                   = "Outbound"
  access                      = "Deny"
  protocol                    = "*"
  source_port_range           = "*"
  destination_port_range      = "*"
  source_address_prefix       = "*"
  destination_address_prefix  = "*"
  resource_group_name         = var.resource_group_name
  network_security_group_name = azurerm_network_security_group.outpost.name
}
