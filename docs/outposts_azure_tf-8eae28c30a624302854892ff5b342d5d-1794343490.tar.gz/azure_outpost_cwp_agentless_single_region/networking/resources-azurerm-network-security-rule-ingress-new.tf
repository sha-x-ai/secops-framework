# Inbound rules:
# The Private Endpoint ASG can recieve traffic from the Scanner ASG to to allow scanner VMs to:
#   > 1. Scan storage blob (HTTPS)
#     2. Scan Azure SQL (1433)
#     3. Scan container registries (HTTPS).
# The Proxy ASG can recieve traffic from the Scanner ASG to allow to allow scanner VMs to egress from the proxy.
# All other Ingress traffic is denied by default.
#
# Skipped in BYON (count = is_byon ? 0 : 1): the NSG is never attached to the
# customer's subnet, so the customer owns subnet-level controls.
#
# `depends_on = [deny_all_inbound_rule]` serialises rule creation to dodge
# azurerm's "operation in progress on the security group" 429s — not for NSG
# evaluation order (that's `priority`).

# DSPM, Registry modules
resource "azurerm_network_security_rule" "allow_private_endpoint_inbound_scanner" {
  count                                      = local.is_byon ? 0 : 1
  name                                       = "AllowPrivateEndpointInboundFromScannerVms"
  priority                                   = 100
  direction                                  = "Inbound"
  access                                     = "Allow"
  protocol                                   = "Tcp"
  source_port_range                          = "*"
  destination_port_ranges                    = ["443", "1433"]
  resource_group_name                        = var.resource_group_name
  network_security_group_name                = azurerm_network_security_group.outpost.name
  source_application_security_group_ids      = [var.scanner_asg_id]
  destination_application_security_group_ids = [var.private_endpoint_asg_id]
  depends_on                                 = [azurerm_network_security_rule.deny_all_inbound_rule]
  # This is to avoid a known bug - the Azure resource manager API returns security group IDs with capital letters, which forces recreation of the resources
  # https://github.com/hashicorp/terraform-provider-azurerm/issues/29841
  lifecycle {
    ignore_changes = [source_application_security_group_ids, destination_application_security_group_ids]
  }
}

resource "azurerm_network_security_rule" "allow_proxy_inbound_from_scanner_vm" {
  count                                      = local.create_proxy_nsg_rules ? 1 : 0
  name                                       = "AllowProxyInboundFromScannerVms"
  priority                                   = 110
  direction                                  = "Inbound"
  access                                     = "Allow"
  protocol                                   = "*"
  source_port_range                          = "*"
  destination_port_range                     = "10000"
  resource_group_name                        = var.resource_group_name
  network_security_group_name                = azurerm_network_security_group.outpost.name
  source_application_security_group_ids      = [var.scanner_asg_id]
  destination_application_security_group_ids = [var.proxy_asg_id]
  depends_on                                 = [azurerm_network_security_rule.deny_all_inbound_rule]
  lifecycle {
    ignore_changes = [source_application_security_group_ids, destination_application_security_group_ids]
  }
}

# Allow ingress to OPA health check on the proxy ASG (port 10001).
resource "azurerm_network_security_rule" "allow_proxy_inbound_opa_healthcheck_from_scanner_vm" {
  count                                      = local.create_proxy_nsg_rules ? 1 : 0
  name                                       = "AllowProxyInboundOpaHealthCheckFromScannerVms"
  priority                                   = 111
  direction                                  = "Inbound"
  access                                     = "Allow"
  protocol                                   = "*"
  source_port_range                          = "*"
  destination_port_range                     = "10001"
  resource_group_name                        = var.resource_group_name
  network_security_group_name                = azurerm_network_security_group.outpost.name
  source_application_security_group_ids      = [var.scanner_asg_id]
  destination_application_security_group_ids = [var.proxy_asg_id]
  depends_on                                 = [azurerm_network_security_rule.deny_all_inbound_rule]
  lifecycle {
    ignore_changes = [source_application_security_group_ids, destination_application_security_group_ids]
  }
}

resource "azurerm_network_security_rule" "deny_all_inbound_rule" {
  count                       = local.is_byon ? 0 : 1
  name                        = "DenyAllIngress"
  priority                    = 4095
  direction                   = "Inbound"
  access                      = "Deny"
  protocol                    = "*"
  source_port_range           = "*"
  destination_port_range      = "*"
  source_address_prefix       = "*"
  destination_address_prefix  = "*"
  resource_group_name         = var.resource_group_name
  network_security_group_name = azurerm_network_security_group.outpost.name
}
