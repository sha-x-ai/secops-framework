# Associates the scanner subnet with Cortex's NSG.
#
# Skipped in BYON: the customer owns their subnet's networking. The NSG is
# still created (for the notification JSON's network_security_group_id) but
# left unattached.

resource "azurerm_subnet_network_security_group_association" "outpost_subnet_nsg_association" {
  count                     = local.is_byon ? 0 : 1
  subnet_id                 = local.final_subnet_id
  network_security_group_id = azurerm_network_security_group.outpost.id
}
