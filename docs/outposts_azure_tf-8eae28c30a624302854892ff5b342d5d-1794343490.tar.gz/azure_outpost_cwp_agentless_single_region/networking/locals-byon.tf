# BYON locals + customer VNet/subnet data sources. All consumers read the
# `final_*` locals so the Cortex-managed-vs-BYON switch lives in one place.

locals {
  is_byon = var.customer_virtual_network_id != null

  # NSG rules that only exist to route scanner traffic through the Cortex proxy
  # VM. Skipped when there is no such VM: BYON (customer's own proxy) or
  # egress_mode = "egress_off" (no egress path at all).
  #
  # The deny_all_outbound / deny_all_inbound rules are deliberately NOT gated on
  # this — they are the baseline posture and matter most in Off.
  create_proxy_nsg_rules = !local.is_byon && var.egress_mode != "egress_off"

  # Parse ARM IDs by segment name (not position) so a new Azure path segment
  # can't silently shift the lookup. Keys are case-insensitive, hence lower().
  _vnet_id_segments         = local.is_byon ? split("/", var.customer_virtual_network_id) : []
  _vnet_id_segments_lower   = [for s in local._vnet_id_segments : lower(s)]
  _subnet_id_segments       = local.is_byon ? split("/", var.customer_subnet_id) : []
  _subnet_id_segments_lower = [for s in local._subnet_id_segments : lower(s)]

  # Guarded by is_byon: "" when not BYON, and every consumer is also gated.
  _vnet_rg     = local.is_byon ? local._vnet_id_segments[index(local._vnet_id_segments_lower, "resourcegroups") + 1] : ""
  _vnet_name   = local.is_byon ? local._vnet_id_segments[index(local._vnet_id_segments_lower, "virtualnetworks") + 1] : ""
  _subnet_rg   = local.is_byon ? local._subnet_id_segments[index(local._subnet_id_segments_lower, "resourcegroups") + 1] : ""
  _subnet_vnet = local.is_byon ? local._subnet_id_segments[index(local._subnet_id_segments_lower, "virtualnetworks") + 1] : ""
  _subnet_name = local.is_byon ? local._subnet_id_segments[index(local._subnet_id_segments_lower, "subnets") + 1] : ""
}

# Validates the customer VNet exists at plan time.
data "azurerm_virtual_network" "customer" {
  count               = local.is_byon ? 1 : 0
  name                = local._vnet_name
  resource_group_name = local._vnet_rg
}

# Source of address_prefixes + service-endpoint validation in BYON mode.
data "azurerm_subnet" "customer" {
  count                = local.is_byon ? 1 : 0
  name                 = local._subnet_name
  virtual_network_name = local._subnet_vnet
  resource_group_name  = local._subnet_rg
}

locals {
  # BYON resolves to the customer-supplied ID (known at plan time); otherwise
  # to the Cortex-created resource.
  final_vnet_id   = local.is_byon ? var.customer_virtual_network_id : azurerm_virtual_network.outpost_vnet[0].id
  final_subnet_id = local.is_byon ? var.customer_subnet_id : azurerm_subnet.outpost_subnet[0].id

  final_subnet_address_prefixes = local.is_byon ? data.azurerm_subnet.customer[0].address_prefixes : azurerm_subnet.outpost_subnet[0].address_prefixes
}

locals {
  # Minimum usable subnet prefix length. Azure reserves 5 addresses per subnet;
  # the outpost needs headroom for scanner / proxy / private-endpoint NICs. A /27
  # (32 addresses, 27 usable) is the conservative floor. Smaller prefixes (larger
  # numbers, e.g. /28, /29) are rejected.
  _byon_min_subnet_prefix = 27

  # Resolved via the [*] splat so a count-0 (non-BYON) subnet yields [] instead of an empty-tuple
  # [0] index. Terraform < 1.12 does not short-circuit &&, so an is_byon-guarded [0] is still
  # evaluated eagerly and fails every non-BYON plan with "Invalid index"; the module supports >= 1.9.4.
  _byon_subnet_address_prefixes = flatten(data.azurerm_subnet.customer[*].address_prefixes)

  # Prefix length (the number after "/") of the first address_prefix. A subnet can exist with no
  # address_prefixes, so fall back to the -1 sentinel, which keeps the "<= 27" precondition harmless
  # and lets the empty-prefixes problem surface through the human-readable validation paths.
  _byon_subnet_prefix_len = length(local._byon_subnet_address_prefixes) > 0 ? tonumber(element(split("/", local._byon_subnet_address_prefixes[0]), 1)) : -1
}

# BYON validation: catches a well-formed subnet ID that resolves to a
# different VNet than customer_virtual_network_id (typo passing the regex).
resource "terraform_data" "byon_subnet_validation" {
  count = local.is_byon ? 1 : 0

  lifecycle {
    precondition {
      condition     = lower(data.azurerm_subnet.customer[0].virtual_network_name) == lower(local._vnet_name)
      error_message = "BYON: customer_subnet_id (${var.customer_subnet_id}) belongs to VNet '${data.azurerm_subnet.customer[0].virtual_network_name}', but customer_virtual_network_id points to VNet '${local._vnet_name}'. Both must reference the same VNet."
    }

    # Fail at plan time on missing service endpoints; otherwise Azure rejects
    # the storage/KV create with an opaque NetworkAclsValidationFailure.
    precondition {
      condition = alltrue([
        for required in ["Microsoft.Storage", "Microsoft.KeyVault"] :
        contains(data.azurerm_subnet.customer[0].service_endpoints, required)
      ])
      error_message = "BYON: subnet '${var.customer_subnet_id}' missing required service endpoints (need Microsoft.Storage and Microsoft.KeyVault). Found: ${jsonencode(data.azurerm_subnet.customer[0].service_endpoints)}. Add the missing endpoints to the subnet — see customer-facing BYON network-prerequisites doc."
    }

    # Subnet must be large enough for the outpost's NICs. Too-small subnets pass
    # the create but fail silently at scan time when scanner pods can't get IPs.
    precondition {
      condition     = local._byon_subnet_prefix_len <= local._byon_min_subnet_prefix
      error_message = "BYON: subnet '${var.customer_subnet_id}' is a /${local._byon_subnet_prefix_len}, which is too small. The outpost needs at least a /${local._byon_min_subnet_prefix} (32 addresses). Use a larger subnet so scanner/proxy/private-endpoint NICs have room — see the customer-facing BYON network-prerequisites doc."
    }

    # The VNet (and therefore its subnet) must physically reside in this region.
    # A VNet from another region listed under the wrong byon_config key would
    # deploy the region's resources cross-region (and break IMDS / private-
    # endpoint routing). Subnets inherit location from their VNet, so the VNet's
    # location is the source of truth.
    precondition {
      condition     = lower(data.azurerm_virtual_network.customer[0].location) == lower(var.location)
      error_message = "BYON: customer_virtual_network_id resides in Azure region '${data.azurerm_virtual_network.customer[0].location}', but it is configured under byon_config key '${var.location}'. The map key must match the VNet's actual region."
    }
  }
}
