resource "azurerm_network_security_group" "outpost" {
  name                = "${var.resource_group_name}-outpost-${var.location}"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags_all

  timeouts {
    delete = "10m"
  }

  lifecycle {
    ignore_changes = [name]
  }

}