locals {
  azurerm_cognitive_services_enabled_regions = [
    "australiaeast",
    "brazilsouth",
    "canadacentral",
    "canadaeast",
    "centralindia",
    "centralus",
    "eastasia",
    "eastus",
    "eastus2",
    "francecentral",
    "germanywestcentral",
    "italynorth",
    "japaneast",
    "japanwest",
    "koreacentral",
    "northcentralus",
    "northeurope",
    "norwayeast",
    "polandcentral",
    "qatarcentral",
    "southafricanorth",
    "southcentralus",
    "southeastasia",
    "southindia",
    "spaincentral",
    "swedencentral",
    "switzerlandnorth",
    "uaenorth",
    "uksouth",
    "westcentralus",
    "westeurope",
    "westus",
    "westus2",
    "westus3"
  ]

  is_cognitive_services_enabled_region  = contains(local.azurerm_cognitive_services_enabled_regions, var.location)
  always_enabled_service_endpoints_list = ["Microsoft.Storage", "Microsoft.Sql", "Microsoft.KeyVault", "Microsoft.AzureActiveDirectory", "Microsoft.AzureCosmosDB"]
  service_endpoints_list                = concat(local.always_enabled_service_endpoints_list, local.is_cognitive_services_enabled_region ? ["Microsoft.CognitiveServices"] : [])

  azurerm_virtual_network = {
    location_cidr_map = {
      "australiacentral"   = "10.1.0.0"
      "australiaeast"      = "10.2.0.0"
      "australiasoutheast" = "10.3.0.0"
      "brazilsouth"        = "10.4.0.0"
      "canadacentral"      = "10.5.0.0"
      "canadaeast"         = "10.6.0.0"
      "centralindia"       = "10.7.0.0"
      "centralus"          = "10.8.0.0"
      "eastasia"           = "10.9.0.0"
      "eastus"             = "10.10.0.0"
      "eastus2"            = "10.11.0.0"
      "francecentral"      = "10.12.0.0"
      "germanywestcentral" = "10.13.0.0"
      "israelcentral"      = "10.14.0.0"
      "italynorth"         = "10.15.0.0"
      "japaneast"          = "10.16.0.0"
      "japanwest"          = "10.17.0.0"
      "koreacentral"       = "10.18.0.0"
      "koreasouth"         = "10.19.0.0"
      "mexicocentral"      = "10.20.0.0"
      "northcentralus"     = "10.21.0.0"
      "northeurope"        = "10.22.0.0"
      "norwayeast"         = "10.23.0.0"
      "polandcentral"      = "10.24.0.0"
      "qatarcentral"       = "10.25.0.0"
      "southafricanorth"   = "10.26.0.0"
      "southcentralus"     = "10.27.0.0"
      "southeastasia"      = "10.28.0.0"
      "southindia"         = "10.29.0.0"
      "spaincentral"       = "10.30.0.0"
      "swedencentral"      = "10.31.0.0"
      "switzerlandnorth"   = "10.32.0.0"
      "uaenorth"           = "10.33.0.0"
      "uksouth"            = "10.34.0.0"
      "ukwest"             = "10.35.0.0"
      "westcentralus"      = "10.36.0.0"
      "westeurope"         = "10.37.0.0"
      "westindia"          = "10.38.0.0"
      "westus"             = "10.39.0.0"
      "westus2"            = "10.40.0.0"
      "westus3"            = "10.41.0.0"
      "usgovarizona"       = "10.42.0.0"
      "usgovvirginia"      = "10.43.0.0"
      "usgovtexas"         = "10.44.0.0"
    }

    # using azurerm_network_service_tags data source is possible, but it takes long time to return, delaying the entire TF run.
    # It is easier to create a map of the predefined Service Tags strings per every enabled location.
    ## TODO: in the future, create a bash script to auto-generate this from the Azure public service tags JSON, for every enabled location.
    location_service_tags = {
      storage = {
        "australiacentral"   = "Storage.AustraliaCentral"
        "australiaeast"      = "Storage.AustraliaEast"
        "australiasoutheast" = "Storage.AustraliaSoutheast"
        "brazilsouth"        = "Storage.BrazilSouth"
        "canadacentral"      = "Storage.CanadaCentral"
        "canadaeast"         = "Storage.CanadaEast"
        "centralindia"       = "Storage.CentralIndia"
        "centralus"          = "Storage.CentralUS"
        "eastasia"           = "Storage.EastAsia"
        "eastus"             = "Storage.EastUS"
        "eastus2"            = "Storage.EastUS2"
        "francecentral"      = "Storage.FranceCentral"
        "germanywestcentral" = "Storage.GermanyWestCentral"
        "israelcentral"      = "Storage.IsraelCentral"
        "italynorth"         = "Storage.ItalyNorth"
        "japaneast"          = "Storage.JapanEast"
        "japanwest"          = "Storage.JapanWest"
        "koreacentral"       = "Storage.KoreaCentral"
        "koreasouth"         = "Storage.KoreaSouth"
        "mexicocentral"      = "Storage.MexicoCentral"
        "northcentralus"     = "Storage.NorthCentralUS"
        "northeurope"        = "Storage.NorthEurope"
        "norwayeast"         = "Storage.NorwayEast"
        "polandcentral"      = "Storage.PolandCentral"
        "qatarcentral"       = "Storage.QatarCentral"
        "southafricanorth"   = "Storage.SouthAfricaNorth"
        "southcentralus"     = "Storage.SouthCentralUS"
        "southeastasia"      = "Storage.SoutheastAsia"
        "southindia"         = "Storage.SouthIndia"
        "spaincentral"       = "Storage.SpainCentral"
        "swedencentral"      = "Storage.SwedenCentral"
        "switzerlandnorth"   = "Storage.SwitzerlandNorth"
        "uaenorth"           = "Storage.UAENorth"
        "uksouth"            = "Storage.UKSouth"
        "ukwest"             = "Storage.UKWest"
        "westcentralus"      = "Storage.WestCentralUS"
        "westeurope"         = "Storage.WestEurope"
        "westindia"          = "Storage.WestIndia"
        "westus"             = "Storage.WestUS"
        "westus2"            = "Storage.WestUS2"
        "westus3"            = "Storage.WestUS3"
        "usgovarizona"       = "Storage.USGovArizona"
        "usgovvirginia"      = "Storage.USGovVirginia"
        "usgovtexas"         = "Storage.USGovTexas"
      }
      sql = {
        "australiacentral"   = "Sql.AustraliaCentral"
        "australiaeast"      = "Sql.AustraliaEast"
        "australiasoutheast" = "Sql.AustraliaSoutheast"
        "brazilsouth"        = "Sql.BrazilSouth"
        "canadacentral"      = "Sql.CanadaCentral"
        "canadaeast"         = "Sql.CanadaEast"
        "centralindia"       = "Sql.CentralIndia"
        "centralus"          = "Sql.CentralUS"
        "eastasia"           = "Sql.EastAsia"
        "eastus"             = "Sql.EastUS"
        "eastus2"            = "Sql.EastUS2"
        "francecentral"      = "Sql.FranceCentral"
        "germanywestcentral" = "Sql.GermanyWestCentral"
        "israelcentral"      = "Sql.IsraelCentral"
        "italynorth"         = "Sql.ItalyNorth"
        "japaneast"          = "Sql.JapanEast"
        "japanwest"          = "Sql.JapanWest"
        "koreacentral"       = "Sql.KoreaCentral"
        "koreasouth"         = "Sql.KoreaSouth"
        "mexicocentral"      = "Sql.MexicoCentral"
        "northcentralus"     = "Sql.NorthCentralUS"
        "northeurope"        = "Sql.NorthEurope"
        "norwayeast"         = "Sql.NorwayEast"
        "polandcentral"      = "Sql.PolandCentral"
        "qatarcentral"       = "Sql.QatarCentral"
        "southafricanorth"   = "Sql.SouthAfricaNorth"
        "southcentralus"     = "Sql.SouthCentralUS"
        "southeastasia"      = "Sql.SoutheastAsia"
        "southindia"         = "Sql.SouthIndia"
        "spaincentral"       = "Sql.SpainCentral"
        "swedencentral"      = "Sql.SwedenCentral"
        "switzerlandnorth"   = "Sql.SwitzerlandNorth"
        "uaenorth"           = "Sql.UAENorth"
        "uksouth"            = "Sql.UKSouth"
        "ukwest"             = "Sql.UKWest"
        "westcentralus"      = "Sql.WestCentralUS"
        "westeurope"         = "Sql.WestEurope"
        "westindia"          = "Sql.WestIndia"
        "westus"             = "Sql.WestUS"
        "westus2"            = "Sql.WestUS2"
        "westus3"            = "Sql.WestUS3"
        "usgovarizona"       = "Sql.USGovArizona"
        "usgovvirginia"      = "Sql.USGovVirginia"
        "usgovtexas"         = "Sql.USGovTexas"
      }
      keyvault = {
        "australiacentral"   = "AzureKeyVault.AustraliaCentral"
        "australiaeast"      = "AzureKeyVault.AustraliaEast"
        "australiasoutheast" = "AzureKeyVault.AustraliaSoutheast"
        "brazilsouth"        = "AzureKeyVault.BrazilSouth"
        "canadacentral"      = "AzureKeyVault.CanadaCentral"
        "canadaeast"         = "AzureKeyVault.CanadaEast"
        "centralindia"       = "AzureKeyVault.CentralIndia"
        "centralus"          = "AzureKeyVault.CentralUS"
        "eastasia"           = "AzureKeyVault.EastAsia"
        "eastus"             = "AzureKeyVault.EastUS"
        "eastus2"            = "AzureKeyVault.EastUS2"
        "francecentral"      = "AzureKeyVault.FranceCentral"
        "germanywestcentral" = "AzureKeyVault.GermanyWestCentral"
        "israelcentral"      = "AzureKeyVault.IsraelCentral"
        "italynorth"         = "AzureKeyVault.ItalyNorth"
        "japaneast"          = "AzureKeyVault.JapanEast"
        "japanwest"          = "AzureKeyVault.JapanWest"
        "koreacentral"       = "AzureKeyVault.KoreaCentral"
        "koreasouth"         = "AzureKeyVault.KoreaSouth"
        "mexicocentral"      = "AzureKeyVault.MexicoCentral"
        "northcentralus"     = "AzureKeyVault.NorthCentralUS"
        "northeurope"        = "AzureKeyVault.NorthEurope"
        "norwayeast"         = "AzureKeyVault.NorwayEast"
        "polandcentral"      = "AzureKeyVault.PolandCentral"
        "qatarcentral"       = "AzureKeyVault.QatarCentral"
        "southafricanorth"   = "AzureKeyVault.SouthAfricaNorth"
        "southcentralus"     = "AzureKeyVault.SouthCentralUS"
        "southeastasia"      = "AzureKeyVault.SoutheastAsia"
        "southindia"         = "AzureKeyVault.SouthIndia"
        "spaincentral"       = "AzureKeyVault.SpainCentral"
        "swedencentral"      = "AzureKeyVault.SwedenCentral"
        "switzerlandnorth"   = "AzureKeyVault.SwitzerlandNorth"
        "uaenorth"           = "AzureKeyVault.UAENorth"
        "uksouth"            = "AzureKeyVault.UKSouth"
        "ukwest"             = "AzureKeyVault.UKWest"
        "westcentralus"      = "AzureKeyVault.WestCentralUS"
        "westeurope"         = "AzureKeyVault.WestEurope"
        "westindia"          = "AzureKeyVault.WestIndia"
        "westus"             = "AzureKeyVault.WestUS"
        "westus2"            = "AzureKeyVault.WestUS2"
        "westus3"            = "AzureKeyVault.WestUS3"
        "usgovarizona"       = "AzureKeyVault.USGovArizona"
        "usgovvirginia"      = "AzureKeyVault.USGovVirginia"
        "usgovtexas"         = "AzureKeyVault.USGovTexas"
      }
      cosmosdb = {
        "australiacentral"   = "AzureCosmosDB.AustraliaCentral"
        "australiaeast"      = "AzureCosmosDB.AustraliaEast"
        "australiasoutheast" = "AzureCosmosDB.AustraliaSoutheast"
        "brazilsouth"        = "AzureCosmosDB.BrazilSouth"
        "canadacentral"      = "AzureCosmosDB.CanadaCentral"
        "canadaeast"         = "AzureCosmosDB.CanadaEast"
        "centralindia"       = "AzureCosmosDB.CentralIndia"
        "centralus"          = "AzureCosmosDB.CentralUS"
        "eastasia"           = "AzureCosmosDB.EastAsia"
        "eastus"             = "AzureCosmosDB.EastUS"
        "eastus2"            = "AzureCosmosDB.EastUS2"
        "francecentral"      = "AzureCosmosDB.FranceCentral"
        "germanywestcentral" = "AzureCosmosDB.GermanyWestCentral"
        "israelcentral"      = "AzureCosmosDB.IsraelCentral"
        "italynorth"         = "AzureCosmosDB.ItalyNorth"
        "japaneast"          = "AzureCosmosDB.JapanEast"
        "japanwest"          = "AzureCosmosDB.JapanWest"
        "koreacentral"       = "AzureCosmosDB.KoreaCentral"
        "koreasouth"         = "AzureCosmosDB.KoreaSouth"
        "mexicocentral"      = "AzureCosmosDB.MexicoCentral"
        "northcentralus"     = "AzureCosmosDB.NorthCentralUS"
        "northeurope"        = "AzureCosmosDB.NorthEurope"
        "norwayeast"         = "AzureCosmosDB.NorwayEast"
        "polandcentral"      = "AzureCosmosDB.PolandCentral"
        "qatarcentral"       = "AzureCosmosDB.QatarCentral"
        "southafricanorth"   = "AzureCosmosDB.SouthAfricaNorth"
        "southcentralus"     = "AzureCosmosDB.SouthCentralUS"
        "southeastasia"      = "AzureCosmosDB.SoutheastAsia"
        "southindia"         = "AzureCosmosDB.SouthIndia"
        "spaincentral"       = "AzureCosmosDB.SpainCentral"
        "swedencentral"      = "AzureCosmosDB.SwedenCentral"
        "switzerlandnorth"   = "AzureCosmosDB.SwitzerlandNorth"
        "uaenorth"           = "AzureCosmosDB.UAENorth"
        "uksouth"            = "AzureCosmosDB.UKSouth"
        "ukwest"             = "AzureCosmosDB.UKWest"
        "westcentralus"      = "AzureCosmosDB.WestCentralUS"
        "westeurope"         = "AzureCosmosDB.WestEurope"
        "westindia"          = "AzureCosmosDB.WestIndia"
        "westus"             = "AzureCosmosDB.WestUS"
        "westus2"            = "AzureCosmosDB.WestUS2"
        "westus3"            = "AzureCosmosDB.WestUS3"
        "usgovarizona"       = "AzureCosmosDB.USGovArizona"
        "usgovvirginia"      = "AzureCosmosDB.USGovVirginia"
        "usgovtexas"         = "AzureCosmosDB.USGovTexas"
      }
    }
  }
}