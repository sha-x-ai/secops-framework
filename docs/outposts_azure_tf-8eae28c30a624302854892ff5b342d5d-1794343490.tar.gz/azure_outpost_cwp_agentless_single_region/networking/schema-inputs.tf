
variable "egress_mode" {
  description = <<-EOT
    Resolved outbound egress routing mode for this outpost ("egress",
    "custom_networking" or "egress_off"), passed down from the parent module.
    "egress_off" means no Cortex proxy VM, so the NSG rules that route scanner
    traffic to it are not created. The deny-all baseline rules are unaffected.
  EOT
  type        = string
  default     = "egress"

  validation {
    condition     = contains(["egress", "custom_networking", "egress_off"], var.egress_mode)
    error_message = "egress_mode must be one of \"egress\", \"custom_networking\" or \"egress_off\"."
  }
}
