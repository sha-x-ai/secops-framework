# The Outpost VNET is the virtual network where the scanner VMs will run on.
# Skipped in BYON mode — the customer supplies their own VNet via
# var.customer_virtual_network_id (resolved through local.final_vnet_id).

resource "azurerm_virtual_network" "outpost_vnet" {
  count               = local.is_byon ? 0 : 1
  name                = "${var.resource_group_name}-vnet-${var.location}"
  address_space       = ["${local.azurerm_virtual_network.location_cidr_map[var.location]}/16"]
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags_all

  private_endpoint_vnet_policies = (!var.azure_us_government && var.enable_azure_high_scale_private_endpoints) ? "Basic" : "Disabled"

  # Previously, the vnet name included the subscription name. The subscription name can contain illegal characters.
  # To fix this, the vnet name now includes a random string instead of the subscription name.
  # To avoid force re-creation of the vnet, we configure lifecyle ignore changes for the vnet's name.
  lifecycle {
    ignore_changes = [name]
  }
}
