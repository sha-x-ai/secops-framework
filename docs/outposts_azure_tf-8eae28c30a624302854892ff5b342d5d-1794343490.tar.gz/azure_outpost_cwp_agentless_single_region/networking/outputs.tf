# ── Networking inner-module outputs ──────────────────────────────────────────
# Resolve to the customer-supplied IDs in BYON, else the Cortex-created ones.

output "vnet_id" {
  value = local.final_vnet_id
}

output "subnet_id" {
  value = local.final_subnet_id
}

output "network_security_group_id" {
  value = azurerm_network_security_group.outpost.id
}
