# This storage queue allows the cortex platform to be notified when scanner VMs are submitting results/logs to the bucket-communication Storage Accounts.

resource "azurerm_storage_queue" "bucket_communication" {
  name               = "${azurerm_storage_account.storage_account.name}-bc-sq-${var.location}"
  storage_account_id = azurerm_storage_account.storage_account.id
}