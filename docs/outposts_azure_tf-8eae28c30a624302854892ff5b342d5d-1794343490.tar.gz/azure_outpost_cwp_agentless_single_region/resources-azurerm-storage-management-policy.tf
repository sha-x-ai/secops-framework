# Configuring the Storage Account retention policy.
#   > Bucket-communication objects will be deleted after 7 days
#     Artifact objects will be deleted after 2 days

resource "azurerm_storage_management_policy" "storage_management_policy" {
  storage_account_id = azurerm_storage_account.storage_account.id
  rule {
    name    = "retention"
    enabled = true
    filters {
      prefix_match = ["${azurerm_storage_container.bucket_communication.name}/"]
      blob_types   = ["blockBlob"]
    }
    actions {
      base_blob {
        delete_after_days_since_creation_greater_than = 7
      }
    }
  }
  rule {
    name    = "artifact retention"
    enabled = true
    filters {
      prefix_match = ["${azurerm_storage_container.bucket_communication.name}/artifact/"]
      blob_types   = ["blockBlob"]
    }
    actions {
      base_blob {
        delete_after_days_since_creation_greater_than = 2
      }
    }
  }
}
