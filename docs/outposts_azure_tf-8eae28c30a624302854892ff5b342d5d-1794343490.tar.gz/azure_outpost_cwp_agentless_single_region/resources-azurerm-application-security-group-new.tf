# TODO: These Application Security Groups will be unified in next versions.
# The scanner VMs are created in the Application Security Group, which allows Network Security Group rules to take affect On scanner VMs.

resource "azurerm_application_security_group" "private_endpoint" {
  name                = "${var.resource_group_name}-private-endpoint-${var.location}"
  location            = var.location
  resource_group_name = var.resource_group_name

  tags = var.tags_all

  lifecycle {
    ignore_changes = [name]
  }
}

# This Application Security Group is the unified ASG for all scanner types.
resource "azurerm_application_security_group" "scanner" {
  name                = "${var.resource_group_name}-scanner-${var.location}"
  location            = var.location
  resource_group_name = var.resource_group_name

  tags = var.tags_all

  lifecycle {
    ignore_changes = [name]
  }
}

resource "azurerm_application_security_group" "proxy" {
  name                = "${var.resource_group_name}-proxy-${var.location}"
  location            = var.location
  resource_group_name = var.resource_group_name

  tags = var.tags_all

  lifecycle {
    ignore_changes = [name]
  }
}