# The EventGrid topic will allow notifications of Cortex platform once Scanner VMs add blobs to the Storage Accounts for the bucket-communications process.

resource "random_string" "eventgrid_topic_random_name" {
  length  = 20
  lower   = true
  numeric = true
  upper   = false
  special = false
}

resource "azurerm_eventgrid_system_topic" "eventgrid_topic" {
  name                = random_string.eventgrid_topic_random_name.result
  resource_group_name = var.resource_group_name
  location            = var.location
  source_resource_id  = azurerm_storage_account.storage_account.id
  topic_type          = "Microsoft.Storage.StorageAccounts"
  tags                = var.tags_all
}