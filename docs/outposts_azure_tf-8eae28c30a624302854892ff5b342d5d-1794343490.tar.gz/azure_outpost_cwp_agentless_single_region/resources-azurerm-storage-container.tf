# We configure two storage containers in the Storage Account:
#   > 1. bucket-communication storage container - allows uploading scan results to cortex platform.
#        Cortex Platform cannot delete objects from this conatiner, and view blobs in the conteinr
#        to inspect the data which is sent to cortex platform.
#   > 2. DSPM artifacts storage container - this conatiner allows DSPM Module to hold temporary data between scan phases.

resource "azurerm_storage_container" "bucket_communication" {
  storage_account_id    = azurerm_storage_account.storage_account.id
  name                  = substr("${azurerm_storage_account.storage_account.name}-bc-sc-${var.location}", 0, 63)
  container_access_type = "private"
}

resource "azurerm_storage_container" "artifact_container" {
  storage_account_id    = azurerm_storage_account.storage_account.id
  name                  = substr("${azurerm_storage_account.storage_account.name}-artifact-${var.location}", 0, 63)
  container_access_type = "private"
}