# This is the module call for every enabled Azure location (Region)

module "location" {
  for_each                       = toset(local.enabled_locations)
  location                       = each.key
  source                         = "./azure_outpost_cwp_agentless_single_region"
  subscription_name              = local.subscription_name
  platform_allowed_ips           = local.platform_allowed_ips
  create_public_storage_accounts = local.create_public_storage_accounts
  create_public_key_vaults       = local.create_public_key_vaults
  sas_policy_expiration_period   = var.storage_sas_policy_expiration
  tags_all                       = local.tags_all
  resource_group_name            = azurerm_resource_group.azure_outpost_cwp_agentless.name
  azure_tenant_id                = data.azurerm_client_config.current.tenant_id
  # local.uami.<name>.principal_id transparently resolves to either the
  # Cortex-created UAMI's principal_id or the customer's UAMI principal_id
  # (looked up via data source) — see locals.tf.
  dspm_idtntity_principal_id     = local.uami.dspm.principal_id
  registry_identity_principal_id = local.uami.registry.principal_id
  azure_us_government            = var.azure_us_government

  enable_azure_high_scale_private_endpoints = var.enable_azure_high_scale_private_endpoints

  # BYON: null when Cortex-managed, so the single-region module creates its own.
  customer_virtual_network_id = try(var.byon_config[each.key].virtual_network_id, null)
  customer_subnet_id          = try(var.byon_config[each.key].subnet_id, null)

  egress_mode = local.egress_mode

  # Proxy auth — only active when proxy_config.auth_enabled = true.
  proxy_auth_enabled = var.proxy_config.auth_enabled
  proxy_username     = var.proxy_username
  proxy_password     = var.proxy_password
  # Empty string under egress_off — no proxy VM.
  proxy_identity_principal_id = local._create_proxy_uami ? local.uami.proxy.principal_id : ""

  # The child module writes the cortex-proxy-credentials secret into an
  # RBAC-authorized Key Vault, which requires the TF runner to hold a data-plane
  # secrets role first. Order that grant before the secret write.
  depends_on = [
    azurerm_role_assignment.terraform_runner_key_vault_secrets_officer_role_assignment,
  ]
}
