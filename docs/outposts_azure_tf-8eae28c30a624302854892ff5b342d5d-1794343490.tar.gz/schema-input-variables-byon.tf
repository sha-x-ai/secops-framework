# ── BYON (Bring-Your-Own Network) Variables ──────────────────────────────────
# Customer supplies their own VNet + subnet (per region) and optionally a proxy;
# Cortex skips creating networking + the egress proxy but still creates
# everything else. Independent of BYOA / BYO-UAMIs.

variable "byon_config" {
  description = <<-EOT
    Per-region BYON configuration. Each map key is an Azure location, and the
    value contains the customer's existing VNet + subnet ARM resource IDs for
    that region. Locations not listed here will not be deployed in BYON mode
    (in BYON mode, only locations in this map are enabled).

    Example:
      byon_config = {
        "eastus" = {
          virtual_network_id = "/subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Network/virtualNetworks/<vnet>"
          subnet_id          = "/subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Network/virtualNetworks/<vnet>/subnets/<subnet>"
        }
      }
  EOT
  type = map(object({
    virtual_network_id = string
    subnet_id          = string
  }))
  default = {}

  # Per-key validation: ARM IDs must look right and the subnet must be inside the VNet.
  # ARM IDs are case-insensitive — normalise with lower() so the regexes can
  # stay readable lowercase patterns.
  validation {
    condition = alltrue([
      for loc, cfg in var.byon_config :
      can(regex("^/subscriptions/[a-f0-9-]{36}/resourcegroups/[^/]+/providers/microsoft\\.network/virtualnetworks/[^/]+$", lower(cfg.virtual_network_id)))
    ])
    error_message = "Each byon_config[*].virtual_network_id must be a full Azure VNet ARM resource ID of the form '/subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Network/virtualNetworks/<vnet>'."
  }
  validation {
    condition = alltrue([
      for loc, cfg in var.byon_config :
      can(regex("^/subscriptions/[a-f0-9-]{36}/resourcegroups/[^/]+/providers/microsoft\\.network/virtualnetworks/[^/]+/subnets/[^/]+$", lower(cfg.subnet_id)))
    ])
    error_message = "Each byon_config[*].subnet_id must be a full Azure Subnet ARM resource ID of the form '/subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Network/virtualNetworks/<vnet>/subnets/<subnet>'."
  }
  validation {
    # Subnet must belong to the named VNet — catches the most common mis-paste.
    condition = alltrue([
      for loc, cfg in var.byon_config :
      startswith(lower(cfg.subnet_id), "${lower(cfg.virtual_network_id)}/subnets/")
    ])
    error_message = "Each byon_config[*].subnet_id must belong to the same VNet as byon_config[*].virtual_network_id (subnet ID must start with '<virtual_network_id>/subnets/')."
  }
}

# ── Outbound Proxy Configuration ─────────────────────────────────────────────
# Only meaningful in BYON mode (cross-validated below). Credentials are kept as
# separate sensitive vars so they can be passed via -var and stay out of tfvars.

variable "proxy_config" {
  description = <<-EOT
    Outbound proxy configuration. Only meaningful when byon_config is
    non-empty (BYON mode); cross-validated below. Schema requires
    proxy_config in global_resources whenever custom_networking is in
    features, so the module always emits it in BYON mode (as either
    {enabled=true,...} or {enabled=false}).

    Example (no proxy / direct internet):
      proxy_config = { enabled = false }

    Example (proxy with auth, no TLS inspection):
      proxy_config = {
        enabled      = true
        host         = "proxy.corp.example.com"
        port         = 3128
        auth_enabled = true
      }

    Example (proxy with TLS inspection):
      proxy_config = {
        enabled         = true
        host            = "proxy.corp.example.com"
        port            = 3128
        tls_enabled     = true
        ca_cert_content = "LS0tLS1CRUdJTi..."
      }
  EOT
  type = object({
    enabled         = bool
    host            = optional(string, "")
    port            = optional(number, 3128)
    auth_enabled    = optional(bool, false)
    tls_enabled     = optional(bool, false)
    ca_cert_content = optional(string, "")
  })
  default = { enabled = false }
  validation {
    condition     = var.proxy_config.port >= 1 && var.proxy_config.port <= 65535
    error_message = "proxy_config.port must be between 1 and 65535."
  }
  # Reject non-base64 at plan time (the WO schema enforces the same pattern)
  # so the customer gets a precise error instead of a post-apply failure.
  validation {
    condition = (
      var.proxy_config.ca_cert_content == "" ||
      can(regex("^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$", var.proxy_config.ca_cert_content))
    )
    error_message = "proxy_config.ca_cert_content must be base64-encoded PEM with no headers and no newlines. Generate with: cat ca.pem | base64 | tr -d '\\n'"
  }
  # Beyond base64 shape (above), the decoded bytes must actually be a PEM
  # certificate. Catches the common "base64-encoded the wrong file" mistake at
  # plan time instead of a silent TLS-inspection failure at scan runtime.
  validation {
    condition = (
      var.proxy_config.ca_cert_content == "" ||
      can(regex("-----BEGIN CERTIFICATE-----", base64decode(var.proxy_config.ca_cert_content)))
    )
    error_message = "proxy_config.ca_cert_content base64-decodes but does not contain a PEM certificate (expected '-----BEGIN CERTIFICATE-----'). Re-encode the correct CA .pem file with: cat ca.pem | base64 | tr -d '\\n'"
  }
  # NOTE: proxy_config.host may now carry a URL scheme (http:// or https://). The
  # previous guard that rejected a scheme/path/:port has been removed because the
  # Workload Orchestrator now accepts a full URL in `host` and performs its own
  # URL assembly. The non-empty-when-enabled rule still lives on
  # terraform_data.byon_validation.
}

variable "proxy_username" {
  description = "Proxy auth username. Required when proxy_config.auth_enabled = true. Provide via: terraform apply -var=\"proxy_username=...\""
  type        = string
  default     = ""
  sensitive   = true
  # No whitespace/control chars — they corrupt the KV secret JSON. Non-empty
  # is enforced by terraform_data.byon_validation when auth_enabled.
  validation {
    condition     = var.proxy_username == "" || can(regex("^[[:print:]]+$", var.proxy_username)) && !can(regex("\\s", var.proxy_username))
    error_message = "proxy_username must contain only printable, non-whitespace characters (no spaces, tabs, newlines, or control chars)."
  }
}

variable "proxy_password" {
  description = "Proxy auth password. Required when proxy_config.auth_enabled = true. Provide via: terraform apply -var=\"proxy_password=...\""
  type        = string
  default     = ""
  sensitive   = true
  # Same shape rules as proxy_username.
  validation {
    condition     = var.proxy_password == "" || can(regex("^[[:print:]]+$", var.proxy_password)) && !can(regex("\\s", var.proxy_password))
    error_message = "proxy_password must contain only printable, non-whitespace characters (no spaces, tabs, newlines, or control chars)."
  }
}

# ── Outpost Egress Routing Mode ──────────────────────────────────────────────

variable "egress_mode" {
  description = <<-EOT
    Outbound egress routing mode for the scanner VMs in this outpost. The value
    is emitted verbatim as the egress feature token in the outpost registration
    notification, so it matches what the Cortex platform receives.

      "egress"            - Cortex-managed egress proxy VM. Current behaviour
                            for non-BYON outposts.
      "custom_networking" - customer-managed proxy reached over your own
                            network. Requires byon_config; set proxy_config to
                            describe the proxy.
      "egress_off"        - no outbound internet at all: no Cortex proxy VM, no
                            customer proxy, no egress path. Scans reach Azure
                            APIs and managed registries (ACR) over private
                            endpoints only. Capabilities that need the public
                            internet (external container registries such as
                            Docker Hub / Artifactory / quay.io) will NOT work.

    Leave unset to keep the mode implied by byon_config ("custom_networking"
    when byon_config is non-empty, "egress" otherwise), which is the behaviour
    that predates this variable.

    Switching an existing outpost to "egress_off" destroys its egress proxy
    infrastructure on the next apply.
  EOT
  type        = string
  default     = null

  validation {
    # null is allowed (inferred from byon_config); an empty string is not.
    condition     = var.egress_mode == null || (var.egress_mode != "" && contains(["egress", "custom_networking", "egress_off"], var.egress_mode))
    error_message = "egress_mode must be one of \"egress\", \"custom_networking\" or \"egress_off\", or left unset to infer it from byon_config."
  }
}

# ── Cross-variable validations ───────────────────────────────────────────────
# Variable `validation` blocks can only see their own variable, so multi-var
# checks live on this terraform_data resource via lifecycle.preconditions.
resource "terraform_data" "byon_validation" {
  lifecycle {
    # proxy_config.enabled requires BYON mode (custom_networking and egress are mutually exclusive).
    precondition {
      condition     = !var.proxy_config.enabled || length(var.byon_config) > 0
      error_message = "proxy_config.enabled can only be true when byon_config is non-empty (BYON mode). The Cortex-managed egress proxy already handles outbound for non-BYON regions."
    }
    # proxy_config.enabled requires a host.
    precondition {
      condition     = !var.proxy_config.enabled || var.proxy_config.host != ""
      error_message = "proxy_config.host must be non-empty when proxy_config.enabled = true."
    }
    # CA cert is only meaningful with TLS inspection enabled.
    precondition {
      condition     = var.proxy_config.ca_cert_content == "" || var.proxy_config.enabled
      error_message = "proxy_config.ca_cert_content can only be set when proxy_config.enabled = true."
    }
    # TLS inspection requires the CA cert.
    precondition {
      condition     = !var.proxy_config.tls_enabled || var.proxy_config.ca_cert_content != ""
      error_message = "proxy_config.ca_cert_content must be non-empty when proxy_config.tls_enabled = true."
    }
    # TLS inspection requires the proxy to be enabled.
    precondition {
      condition     = !var.proxy_config.tls_enabled || var.proxy_config.enabled
      error_message = "proxy_config.tls_enabled can only be true when proxy_config.enabled = true."
    }
    # Proxy auth requires both creds.
    precondition {
      condition     = !var.proxy_config.auth_enabled || (var.proxy_username != "" && var.proxy_password != "")
      error_message = "When proxy_config.auth_enabled = true, both proxy_username and proxy_password must be provided. Pass them via -var flags so they don't end up in tfvars files."
    }
    # Proxy auth requires BYON mode (the Key Vault secret lives in the per-region outpost KV).
    precondition {
      condition     = !var.proxy_config.auth_enabled || length(var.byon_config) > 0
      error_message = "proxy_config.auth_enabled can only be true when byon_config is non-empty (BYON mode)."
    }
    # Proxy auth requires the proxy itself to be enabled.
    precondition {
      condition     = !var.proxy_config.auth_enabled || var.proxy_config.enabled
      error_message = "proxy_config.auth_enabled can only be true when proxy_config.enabled = true."
    }
    # BYON region keys must be valid for the deployment partition (usgov* for US-Gov,
    # commercial regions otherwise): local._all_valid_partition_locations.
    precondition {
      condition     = alltrue([for loc in keys(var.byon_config) : contains(local._all_valid_partition_locations, loc)])
      error_message = "Each region key in byon_config must be a supported Azure location for this partition. See local._all_valid_partition_locations in locals.tf."
    }
    # Custom egress means "your network, your proxy" — it needs BYON.
    precondition {
      condition     = var.egress_mode != "custom_networking" || length(var.byon_config) > 0
      error_message = "egress_mode = \"custom_networking\" requires byon_config to be non-empty: a customer-managed proxy is only reachable from a customer-managed network."
    }
    # The Cortex-managed egress proxy VM lives in the Cortex-managed VNet.
    precondition {
      condition     = var.egress_mode != "egress" || length(var.byon_config) == 0
      error_message = "egress_mode = \"egress\" cannot be combined with byon_config: the Cortex-managed egress proxy is only deployed into Cortex-managed networking. Use \"custom_networking\" (your own proxy) for BYON outposts."
    }
    # Off means no proxy of any kind.
    precondition {
      condition     = var.egress_mode != "egress_off" || !var.proxy_config.enabled
      error_message = "egress_mode = \"egress_off\" cannot be combined with proxy_config.enabled = true: Off means the scanners get no egress path at all. Use \"custom_networking\" to route through your proxy."
    }
    # Off provisions no egress path, so no customer network is collected.
    precondition {
      condition     = var.egress_mode != "egress_off" || length(var.byon_config) == 0
      error_message = "egress_mode = \"egress_off\" cannot be combined with byon_config: Off means no outbound path at all, so no customer network is used. Leave byon_config empty, or use \"custom_networking\" to route through your own network."
    }
  }
}
