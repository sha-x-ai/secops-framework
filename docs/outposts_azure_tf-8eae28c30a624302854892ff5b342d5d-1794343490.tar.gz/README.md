# README.md

This terraform module creates a customer-managed Azure outpost for Cortex Agentless.

## Configuring your variables
Every input variable is documented in [`terraform-README.md`](terraform-README.md) (a readable name / description / type / default table). The raw definitions live in [`schema-input-variables.tf`](schema-input-variables.tf) (and [`schema-input-variables-byon.tf`](schema-input-variables-byon.tf) for Bring-Your-Own-Network). The generated `template_params.tfvars` is pre-filled with values supplied by Palo Alto Networks — do not change those unless instructed; adjust only the variables you were told to configure.

**Region-scoping variable names differ per cloud** — this is the most common onboarding mistake. On Azure use `location_allowlist`. A name that does not exist in this module is silently ignored by Terraform (warning only), so the outpost falls back to all locations. Note that GCP and OCI both use `region_allowlist`, so that name is silently *accepted* on the wrong cloud — double-check you are editing the variable for the cloud you are deploying.

| Cloud | Region-scoping variable |
|-------|-------------------------|
| AWS   | `enabled_regions`       |
| Azure | `location_allowlist`    |
| GCP   | `region_allowlist`      |
| OCI   | `region_allowlist`      |

## Egress routing mode
`egress_mode` selects how the scanner VMs reach the internet. The value is emitted verbatim as the egress feature token in the outpost registration notification, so it matches what the Cortex platform receives. Leave it unset unless Palo Alto Networks told you otherwise — unset reproduces the behaviour that predates the variable (`custom_networking` when `byon_config` is non-empty, `egress` otherwise).

| `egress_mode` | Outbound path | Requires |
|---------------|---------------|----------|
| `egress` | Cortex-managed egress proxy VM in the Cortex-managed VNet | `byon_config` must be empty |
| `custom_networking`  | Your own proxy, reached over your own network | `byon_config` non-empty; describe the proxy in `proxy_config` |
| `egress_off`     | None — the scanners get no outbound internet path | `byon_config` must be empty; `proxy_config.enabled` must be `false` |

In `egress_off` mode the scanners reach Azure APIs and ACR over private endpoints only. **Capabilities that need the public internet stop working** — most notably scanning external container registries (Docker Hub, Artifactory, quay.io). Everything served over private endpoints continues to work.

`egress_off` also stops this module creating the NSG rules that carry proxy traffic. The subnet's deny-all inbound and outbound rules are unaffected. Switching an existing outpost to `egress_off` therefore **destroys** those rules on the next apply; switching back re-creates them.

The proxy VM's user-assigned managed identity and its application security group are still created in `egress_off` mode. They are inert without the NSG rules, and they are kept for now because removing them would change the Bring-Your-Own-UAMI onboarding contract (`uami_mode = "customer_managed"` requires `customer_uami_proxy_id`). They will be removed in a follow-up.

## Prerequisites
The following are required to be able to run this Terraform module:
1. [Azure CLI](https://learn.microsoft.com/en-us/cli/azure/install-azure-cli) installed locally
2. An active Azure subscription, it is recommended to use a dedicated subscription for this deployment, also for cleanup and isolation purposes.
3. The service principal or user running this Terraform module should have the following roles assigned:
	* "Contributor" or "Owner" on the designated outpost subscription scope
	* Active Directory "Cloud Application Administrator" or "Application Administrator" privileged roles
4. A static egress IP assigned to the machine running this Terraform. This is used to configure the Azure Storage IP whitelist (Recommended). Without this, future runs of this Terraform may fail on Azure storage configurations.
5. This terraform module requires Terraform 1.9.4 and above. If you are running a different version of terraform, use [tfversion](https://github.com/tfversion/tfversion) to use the correct version.
6. It is recommended to use a [terraform backend](https://developer.hashicorp.com/terraform/language/backend) to store the terraform state, or at least back up the `terraform.tfstate` file.</br>
   Failing to configure a terraform backend or backing up the `terraform..tfstate` file will result in the inability to upgrade or destroy the infrastructure in the future.

### High-Scale Private Endpoints (HSPE)
Setting `enable_azure_high_scale_private_endpoints = true` applies the HSPE network policies to
the outpost VNet and its private-endpoint subnet. This is supported on public Azure only — the
toggle is rejected by validation on Azure US Government.

**Prerequisite:** the `Microsoft.Network` AFEC feature `EnableMaxPrivateEndpointsVia64kPath` must
already be registered on the subscription. This module does **not** register it — register it
yourself before enabling the toggle:

```
az feature register --namespace Microsoft.Network --name EnableMaxPrivateEndpointsVia64kPath
```

The feature is **subscription-scoped**, not per-region and not per-outpost, so this is a one-time
step per subscription. `az feature register` returns as soon as the request is accepted — it does
**not** wait for the state to become `Registered`, so poll until it does:

```
az feature show --namespace Microsoft.Network --name EnableMaxPrivateEndpointsVia64kPath --query properties.state --output tsv
```

Once it reports `Registered`, propagate it to the resource provider:

```
az provider register --namespace Microsoft.Network
```

If the feature is not registered, Azure silently ignores the HSPE policies: the apply succeeds and
the outpost looks healthy, but HSPE is not in effect.

#### BYON outposts
The HSPE policies are set on the VNet and subnet that Cortex creates. In BYON mode the customer
supplies both, so Cortex has nothing to apply them to. If every enabled region is BYON, the
toggle is inert.

To use HSPE with your own VNet, register the feature on the subscription yourself and set
`privateEndpointVNetPolicies = "Basic"` on the VNet and `privateEndpointNetworkPolicies = "Enabled"`
on the subnet.

## Terraform Apply procedure
1. Run `az login` to fetch the desired service principal or user context.
2. If prompted, select the `subscription_id` of the designated subscription, or run `az account set --subscription <subscription_id>`
3. Run `terraform init`.
4. Run `terraform apply --var-file=template_params.tfvars`.
5. When prompted for `var.storaage_account_ip_whitelist`, leave empty to enable access from any public IP to the storage accounts. </br>
   If you wish to limit access to selected IPs only, enter a comma-seperated list of public IP addresses, including your local machine's egress IP (to enable the completion of the Terraform run).
   Example: `8.8.8.8, 8.8.4.4`
5. When prompted, enter subscription ID.
6. Review the Terraform plan, and enter "yes" to execute it.

## Terraform Destroy procedure
To run terraform destroy, follow this procedure if you have the .tfstate file saved locally, or configured terraform remote state.
The public IP of the machine running the destroy operation should have been configured while running the "Apply" stage.
If any of these prerequesits failed, or the destroy operation is not succesful, follow ## Cleaning up manually
1. Run `az login` to fetch the desired service principal or user context.
2. If prompted, select the `subscription_id` of the designated subscription, or run `az account set --subscription <subscription_id>`
3. Run `terraform init`.
4. Run `terraform destroy --var-file=template_params.tfvars`.
5. When prompted for `var.storaage_account_ip_whitelist`, leave the input empty (press enter)
5. When prompted, enter subscription ID.
6. Review the Terraform destroy, and enter "yes" to execute it.
 
* in case you followed the recommendation and created a dedicated subscription for the Outpost, make sure to delete all resources associated with the subscription (the steps above should cover all of them). 

## Cleaning up manually
If the Terraform destroy procedure failed to run, follow these steps in the Azure portal to clean up:
1. Find and delete the resource group for the created outpost. Its name is an 8-character long random string.
2. Find and delete the App Registration `cortex-scan-platform-<id>`.
3. Find and delete the Enterprise Application `cortex-scan-platform-<id>`.
4. Find and delete the role definitions `cortex-scan-platform-<id>-wo-role` and `cortex-scan-platform-<id>-private-endpoint-role`
5. Find and delete the user-assigned identities `saas-*`, `dspm-*`, `registry-*` and `serverless-*`

## Migrating an existing outpost from `cortex_managed` to `customer_managed`

Switching `app_registration_mode` from `cortex_managed` to `customer_managed` will cause Terraform to **destroy** the existing Cortex-created App Registration, Service Principal, FICs, API access, redirect URIs, and role assignments — including the `outpost_o365_app_registration` used for DSPM SharePoint/RMS scanning.

If you want to preserve any of these resources (typically the O365 AppReg, to keep DSPM-O365 scanning working), run `terraform state rm` for them before `terraform apply`. This releases the resources from Terraform's state without deleting them in Azure. Example:
```bash
terraform state rm \
  azuread_application_registration.outpost_o365_app_registration \
  azuread_service_principal.outpost_o365_sp \
  azuread_application_api_access.outpost_o365_msgraph_api \
  azuread_application_api_access.outpost_o365_sharepoint_api \
  azuread_application_api_access.outpost_o365_rms_api \
  azuread_application_redirect_uris.outpost_registration_redirect_uri_o365_app \
  azuread_application_federated_identity_credential.federated_cts_gke_serviceaccount_o365_app \
  azuread_application_federated_identity_credential.federated_dspm_managed_identity_o365_app
```

## Troubleshooting (Bring Your Own App — `app_registration_mode = "customer_managed"`)

Symptoms a customer is likely to hit when the BYO App Registration / Service Principal / UAMIs were created via the Azure Portal instead of the helper script. Some are caught at **plan time** by `data` postconditions / `check` blocks (see the `When` column); the rest are runtime-only and require log inspection.

| Symptom / error message | When | Fix |
|---|---|---|
| `... customer_sp_object_id ... is the SP of a different AppReg ...` | plan | Wrong SP Object ID. Get the right one: `az ad sp show --id <CUSTOMER_APP_CLIENT_ID> --query id -o tsv` and update `customer_sp_object_id` in tfvars |
| `Warning: The Terraform runner ... is NOT listed as an owner of the BYO App Registration ...` | plan | `az ad app owner add --id <APP_ID> --owner-object-id <TF_RUNNER_OBJ_ID>` — without it, apply fails with the generic *"Insufficient privileges to complete the operation"* on the first FIC |
| `... Customer SP ... is disabled in Entra ...` | plan | `az ad sp update --id <SP_OBJ_ID> --set accountEnabled=true` (or toggle in Portal → Enterprise Applications → \<SP\> → Properties) |
| `... Customer UAMI ... lives in subscription <X> but the outpost is being deployed to <Y> ...` | plan | Recreate the UAMI in the outpost subscription and update `customer_uami_*_id` in tfvars. Cross-subscription UAMIs are not supported (IMDS only returns tokens for local identities) |
| `... Customer UAMI ... lives in tenant <X> but the outpost subscription is in tenant <Y> ...` | plan | Same as above but tenant-level — recreate the UAMI in the correct tenant |
| `... All 5 customer UAMI IDs must be distinct ...` | plan | Copy-paste error — the error message lists all 5 IDs; replace the duplicates and rerun |
| `Error: creating Federated Identity Credential ... Insufficient privileges to complete the operation` | apply | TF runner is missing AppReg-owner. Run `az ad app owner list --id <APP_ID>` to verify; then `az ad app owner add --id <APP_ID> --owner-object-id <TF_RUNNER>`. (Should be pre-empted by the plan-time `check`.) |
| `Another object with the same value for property federatedIdentityCredentials/<name> already exists` | apply | Stale FIC from a previous attempt or manual Portal entry. Delete it: `az ad app federated-credential list --id <APP_ID> -o table`; `az ad app federated-credential delete --id <APP_ID> --federated-credential-id <NAME>`; rerun |
| `400 BadRequest: Subject does not exist in directory.` (apply) | apply | UAMI was created seconds ago and hasn't replicated to Entra yet. Wait 30–60 s and rerun. Verify with `az ad sp show --id <UAMI_PRINCIPAL_ID>` |
| `AADSTS50057: The user account is disabled.` (scanner pod logs) | runtime | The SP was disabled after onboarding. `az ad sp update --id <SP_OBJ_ID> --set accountEnabled=true` |
| `AADSTS70021: No matching federated identity record found` (scanner pod logs) | runtime | Missing / wrong-subject FIC. List both sides: `az ad app federated-credential list --id <APP_ID>` and `az identity federated-credential list --name <UAMI_NAME> -g <UAMI_RG>`. Rerun `terraform apply` — TF owns these FICs |
| `AADSTS650056` / `AADSTS50020` at the Cortex consent URL | runtime | Admin consent was never granted on the monitored tenant. Retry the consent flow. A single-tenant AppReg only works when it monitors its own home tenant |
| `terraform destroy` deleted my customer-created UAMIs! | post-destroy | The UAMIs were placed inside the outpost's resource group. They need to live in a customer-owned RG. Recreate them outside the outpost RG and re-onboard |
| `terraform destroy` fails to delete the `cortex-proxy-credentials` Key Vault secret (`Forbidden` / missing permission) | destroy | Only relevant when `proxy_config.auth_enabled = true`. The TF runner writes this secret on apply and must remove it on destroy. The `Key Vault Secrets Officer` role assignment on the runner grants the data-plane `Delete`; re-apply with an up-to-date module so the runner holds the role, then rerun destroy |

## Key Vault secret permissions

The outpost Key Vault uses **RBAC authorization** (`rbac_authorization_enabled = true`),
so access is granted through Azure role assignments (at the outpost resource-group
scope, inherited down to the Key Vault) rather than Key Vault access policies. Each
identity is granted the minimum set of secret permissions it needs:

| Identity | Role | Secret data-plane permissions | Why |
|---|---|---|---|
| Outpost App Registration SP (cortex platform principal) | custom `app_registration_cortex_role` | `Get`, `Set`, `Delete`, `Purge`, `List` (readMetadata) | Full lifecycle management of outpost secrets |
| Registry scanner VM UAMI | custom `key_vault_secrets_ro_role` | `Get`, `List` | Read secrets needed to run the registry scan |
| DSPM VM UAMI | custom `key_vault_secrets_ro_role` | `Get`, `List` | Read secrets needed by DSPM |
| Proxy VM UAMI (`proxy_config.auth_enabled`) | custom `key_vault_secrets_ro_role` | `Get`, `List` | Read the `cortex-proxy-credentials` secret at boot |
| Terraform runner (`proxy_config.auth_enabled`) | built-in `Key Vault Secrets Officer` | `Get`, `Set`, `Delete`, `Purge` | Write and manage the `cortex-proxy-credentials` secret (subscription Owner/Contributor is control-plane only and cannot access secret data on an RBAC vault) |

# Terraform Documentation
[Terraform docs](terraform-README.md)

# Development
The terraform documentation was automatically generated by [terraform-docs](https://github.com/terraform-docs/terraform-docs/). </br>
To regenerate the documentation:
1. validate `azurerm-provider.tf` file is in the terraform directory
2. run the following command:</br>
	`terraform-docs markdown table --output-file terraform-README.md .`