# Lookups for customer-supplied UAMIs (uami_mode = "customer_managed").
# Resolves principal_id / client_id at plan time for use via local.uami.
# Name and RG are parsed from the ARM ID; variable validation enforces the shape.
#
# Keyed by role ("agentless", "dspm", "registry", "serverless", "proxy") via
# local._customer_managed_uami_ids so consumers can index as
# data.azurerm_user_assigned_identity.customer_managed["<role>"].
data "azurerm_user_assigned_identity" "customer_managed" {
  for_each            = local.is_customer_managed_uami_mode ? local._customer_managed_uami_ids : {}
  name                = element(split("/", each.value), length(split("/", each.value)) - 1)
  resource_group_name = element(split("/", each.value), 4)

  lifecycle {
    # D-UAMI-0: BYO UAMIs requires BYO App Reg. The App-Reg-side FICs we add only make sense
    # if the customer owns the App Reg too — without it the trust chain doesn't close. Lives
    # here (rather than on the resource group) because the constraint is purely about the
    # uami_mode / app_registration_mode pairing. Hard-fail at plan time, not at apply time.
    precondition {
      condition     = !local.is_customer_managed_uami_mode || local.is_byoa_enabled
      error_message = <<-EOM
        You enabled Bring-Your-Own (BYO) UAMIs but not BYO App Registration.

        Current configuration:
          BYO UAMIs is ON             (uami_mode = "${var.uami_mode}")
          BYO App Registration is OFF (app_registration_mode = "${var.app_registration_mode}")

        BYO UAMIs cannot be used on their own. Choose one of the following:

          1. Also bring your own App Registration (recommended if you intend to manage
             these identities yourself):
               - set app_registration_mode = "customer_managed"
               - provide customer_app_client_id  (the App Registration's Application/client ID)
               - provide customer_sp_object_id   (the App Registration's Service Principal object ID)

          2. Let Cortex create the UAMIs for you:
               - unset uami_mode (or set uami_mode = "cortex_managed")

        Why: BYO UAMIs work by attaching Federated Identity Credentials (FICs) onto your
        App Registration. That trust chain only closes when you also own the App
        Registration, so the two settings must be enabled together.
      EOM
    }

    # D-UAMI-1: UAMI must live in the same subscription we're deploying to. Cross-subscription
    # UAMIs aren't supported — the scanner pods run in the outpost subscription and IMDS only
    # returns tokens for identities attached to the local subscription. Plan-time hard-fail with
    # an actionable error beats a runtime "resource not found" or silent role-assignment-target
    # mismatch.
    postcondition {
      condition     = element(split("/", self.id), 2) == data.azurerm_subscription.outpost.subscription_id
      error_message = "Customer UAMI '${self.name}' lives in subscription ${element(split("/", self.id), 2)} but the outpost is being deployed to ${data.azurerm_subscription.outpost.subscription_id}. Cross-subscription UAMIs are not supported — recreate the UAMI in the outpost subscription and update the corresponding customer_uami_*_id variable."
    }

    # D-UAMI-2: UAMI tenant must match the subscription's tenant. UAMIs are tenant-bound; a
    # cross-tenant UAMI guarantees a broken IMDS → AAD token exchange downstream.
    postcondition {
      condition     = self.tenant_id == data.azurerm_subscription.outpost.tenant_id
      error_message = "Customer UAMI '${self.name}' lives in tenant ${self.tenant_id} but the outpost subscription is in tenant ${data.azurerm_subscription.outpost.tenant_id}. Cross-tenant UAMIs are not supported — recreate the UAMI in the same tenant as the outpost subscription."
    }
  }
}

# The 5 customer UAMI IDs must all be distinct. A copy-paste duplicate (same UAMI used
# for both `dspm` and `registry`, for example) causes double role-assignments and scanner cross-
# talk that's painful to diagnose at runtime. Plan-time check with a clear message.
check "byo_uamis_are_distinct" {
  assert {
    condition     = !local.is_customer_managed_uami_mode || length(distinct(values(local._customer_managed_uami_ids))) == length(local._customer_managed_uami_ids)
    error_message = <<-EOM
      All 5 customer UAMI IDs must be distinct (one UAMI per role). Got:
        agentless  = ${var.customer_uami_agentless_id}
        dspm       = ${var.customer_uami_dspm_id}
        registry   = ${var.customer_uami_registry_id}
        serverless = ${var.customer_uami_serverless_id}
        proxy      = ${var.customer_uami_proxy_id}
      Re-run the BYO UAMIs setup script to regenerate 5 distinct identities.
    EOM
  }
}

# Silently-ignored BYO UAMIs: if the customer pastes customer_uami_*_id values
# but leaves uami_mode at the default "cortex_managed", Terraform creates its own
# UAMIs and ignores the supplied IDs entirely — the customer believes their
# identities are in use when they are not. Surface this as a non-fatal check so
# the misconfiguration is visible at plan time.
check "byo_uamis_supplied_require_customer_managed_mode" {
  assert {
    condition = (
      local.is_customer_managed_uami_mode ||
      length(compact(values(local._customer_managed_uami_ids))) == 0
    )
    error_message = <<-EOM
      One or more customer_uami_*_id values were supplied, but uami_mode is
      "${var.uami_mode}" (not "customer_managed"), so these values are IGNORED and
      Cortex will create its own UAMIs instead.

      Supplied (non-empty) values:
        agentless  = ${var.customer_uami_agentless_id}
        dspm       = ${var.customer_uami_dspm_id}
        registry   = ${var.customer_uami_registry_id}
        serverless = ${var.customer_uami_serverless_id}
        proxy      = ${var.customer_uami_proxy_id}

      To use your own UAMIs set uami_mode = "customer_managed" (and provide all 5).
      To let Cortex manage them, remove the customer_uami_*_id values to silence
      this message.
    EOM
  }
}
