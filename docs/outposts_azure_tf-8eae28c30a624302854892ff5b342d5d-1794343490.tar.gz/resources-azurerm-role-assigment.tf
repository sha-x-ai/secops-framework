# The workload-orchestrator and private endpoint custom roles are assigned to the outpost app registration (service principal) which is the cortex platform's principal in the outpost.
# The Storage Queue Data Message Processor role is assigned to the same app registration. Conditions are set to limit storage access read from the bucket communication process storage queues
# The Storage Blob Data Contributor role is assigned with the app registration and all the user-assigned identities which are being used by Scanner VMs.
# Conditions are set to limit storage access to specific buckets with specific actions:
#     1. The App Registration can read and write in the communications storage container
#     2. All the user-assigned identities can and write in the communications storage container
#     3. The DSPM user-assigned identity can also read and write to the artifact storage container
# These permissions enable the bucket-communication process, where the scanner VMs don't interact directly with the Cortex Platform.
#   > Scan results are being uploaded to the buckets, and pulled by the Cortex Platform separately.

# Role Assigment Conditions Conditions are only available for Storage actions: https://learn.microsoft.com/en-us/azure/role-based-access-control/conditions-format#actions
# Therefore, our custom roles cannot use conditions since those only include compute and networking actions.
# When editing a condition, use the Azure Portal Web UI to formulate the correct condition since the condition syntax is counter-intuitive

# The outpost SP is created by the `azuread` provider while role assignments are scoped into the
# subscription via `azurerm`. If those resolve to different tenants the assignment fails at apply
# time with `400 PrincipalNotFound` — hard-fail at plan time instead. Hosted on a no-op
# terraform_data resource (no real infra) so the precondition runs in every mode (cortex_managed
# and customer_managed) without affecting the deploy flow.
resource "terraform_data" "tenant_validation" {
  lifecycle {
    precondition {
      condition     = data.azuread_client_config.current.tenant_id == data.azurerm_subscription.outpost.tenant_id
      error_message = <<-EOM
        The outpost Service Principal is created in tenant ${data.azuread_client_config.current.tenant_id}
        (`azuread` provider), but subscription ${data.azurerm_subscription.outpost.subscription_id} is in
        tenant ${data.azurerm_subscription.outpost.tenant_id} (`azurerm` provider). They must match.

        Fix: re-run `az login --tenant ${data.azurerm_subscription.outpost.tenant_id}` (or pin `tenant_id`
        on the azuread provider), or target a subscription in tenant ${data.azuread_client_config.current.tenant_id}.
      EOM
    }
  }
}

resource "azurerm_role_assignment" "cortex_role_assignment" {
  depends_on = [terraform_data.tenant_validation]

  scope              = azurerm_resource_group.azure_outpost_cwp_agentless.id
  principal_id       = local.outpost_principal_id
  role_definition_id = local.workload_orchestrator_role_id
}

resource "azurerm_role_assignment" "cortex_private_endpoint_role_assignment" {
  depends_on = [terraform_data.tenant_validation]

  scope              = azurerm_resource_group.azure_outpost_cwp_agentless.id
  principal_id       = local.outpost_principal_id
  role_definition_id = local.private_endpoint_role_id
}

# BYON: the scanner NIC is created in the customer's VNet, outside the outpost
# RG, so grant the WO role on each BYON VNet — otherwise the join hits 403
# LinkedAuthorizationFailed. Scoped to the VNet (least-priv); no-op when
# byon_config is empty.
resource "azurerm_role_assignment" "byon_vnet_workload_orchestrator_role_assignment" {
  depends_on = [terraform_data.tenant_validation]

  for_each = var.byon_config

  scope              = each.value.virtual_network_id
  principal_id       = local.outpost_principal_id
  role_definition_id = local.workload_orchestrator_role_id
}

resource "azurerm_role_assignment" "cortex_storage_queue_role_assignment" {
  depends_on = [terraform_data.tenant_validation]

  scope                = azurerm_resource_group.azure_outpost_cwp_agentless.id
  principal_id         = local.outpost_principal_id
  role_definition_name = "Storage Queue Data Message Processor"
  condition_version    = "2.0"
  condition            = <<-EOT
  (
   (
    !(ActionMatches{'Microsoft.Storage/storageAccounts/queueServices/queues/messages/read'})
    AND
    !(ActionMatches{'Microsoft.Storage/storageAccounts/queueServices/queues/messages/process/action'})
   )
   OR 
   (
    @Resource[Microsoft.Storage/storageAccounts/queueServices/queues:name] StringLike '*bc-sq*'
   )
  )
  EOT
}

resource "azurerm_role_assignment" "storage_blob_role_assignment" {
  depends_on = [terraform_data.tenant_validation]

  scope                = azurerm_resource_group.azure_outpost_cwp_agentless.id
  principal_id         = local.outpost_principal_id
  role_definition_name = "Storage Blob Data Contributor"
  condition_version    = "2.0"
  condition            = <<-EOT
(
 (
  !(ActionMatches{'Microsoft.Storage/storageAccounts/blobServices/containers/blobs/read'})
  AND
  !(ActionMatches{'Microsoft.Storage/storageAccounts/blobServices/containers/blobs/write'})
 )
 OR 
 (
  @Resource[Microsoft.Storage/storageAccounts/blobServices/containers:name] StringLike '*bc-sc*'
 )
)
  EOT
}

# Per-UAMI Storage Blob role assignments. Use local.uami.<name>.principal_id so
# the customer_managed (BYO UAMIs) flow transparently substitutes the data-source
# principal_id without any change to these blocks.
resource "azurerm_role_assignment" "managed_identity_storage_blob_role_assignment" {
  depends_on = [terraform_data.tenant_validation]

  principal_id         = local.uami.agentless.principal_id
  scope                = azurerm_resource_group.azure_outpost_cwp_agentless.id
  role_definition_name = "Storage Blob Data Contributor"
  condition_version    = "2.0"
  condition            = <<-EOT
(
 (
  !(ActionMatches{'Microsoft.Storage/storageAccounts/blobServices/containers/blobs/read'})
  AND
  !(ActionMatches{'Microsoft.Storage/storageAccounts/blobServices/containers/blobs/write'})
 )
 OR 
 (
  @Resource[Microsoft.Storage/storageAccounts/blobServices/containers:name] StringLike '*bc-sc*'
 )
)
  EOT
}

resource "azurerm_role_assignment" "registry_managed_identity_storage_blob_role_assignment" {
  depends_on = [terraform_data.tenant_validation]

  principal_id         = local.uami.registry.principal_id
  scope                = azurerm_resource_group.azure_outpost_cwp_agentless.id
  role_definition_name = "Storage Blob Data Contributor"
  condition_version    = "2.0"
  condition            = <<-EOT
(
 (
  !(ActionMatches{'Microsoft.Storage/storageAccounts/blobServices/containers/blobs/read'})
  AND
  !(ActionMatches{'Microsoft.Storage/storageAccounts/blobServices/containers/blobs/write'})
 )
 OR 
 (
  @Resource[Microsoft.Storage/storageAccounts/blobServices/containers:name] StringLike '*bc-sc*'
 )
)
  EOT
}

resource "azurerm_role_assignment" "dspm_managed_identity_storage_blob_role_assignment" {
  depends_on = [terraform_data.tenant_validation]

  principal_id         = local.uami.dspm.principal_id
  scope                = azurerm_resource_group.azure_outpost_cwp_agentless.id
  role_definition_name = "Storage Blob Data Contributor"
  condition_version    = "2.0"
  condition            = <<-EOT
(
 (
  !(ActionMatches{'Microsoft.Storage/storageAccounts/blobServices/containers/blobs/read'})
  AND
  !(ActionMatches{'Microsoft.Storage/storageAccounts/blobServices/containers/blobs/write'})
 )
 OR 
 (
  @Resource[Microsoft.Storage/storageAccounts/blobServices/containers:name] StringLike '*bc-sc*'
  OR
  @Resource[Microsoft.Storage/storageAccounts/blobServices/containers:name] StringLike '*artifact*'
 )
)
  EOT
}

resource "azurerm_role_assignment" "serverless_managed_identity_storage_blob_role_assignment" {
  depends_on = [terraform_data.tenant_validation]

  principal_id         = local.uami.serverless.principal_id
  scope                = azurerm_resource_group.azure_outpost_cwp_agentless.id
  role_definition_name = "Storage Blob Data Contributor"
  condition_version    = "2.0"
  condition            = <<-EOT
(
 (
  !(ActionMatches{'Microsoft.Storage/storageAccounts/blobServices/containers/blobs/read'})
  AND
  !(ActionMatches{'Microsoft.Storage/storageAccounts/blobServices/containers/blobs/write'})
 )
 OR
 (
  @Resource[Microsoft.Storage/storageAccounts/blobServices/containers:name] StringLike '*bc-sc*'
 )
)
  EOT
}

resource "azurerm_role_assignment" "proxy_managed_identity_storage_blob_proxy_role_assignment" {
  # No proxy VM under egress_off.
  count      = local._create_proxy_uami ? 1 : 0
  depends_on = [terraform_data.tenant_validation]

  principal_id         = local.uami.proxy.principal_id
  scope                = azurerm_resource_group.azure_outpost_cwp_agentless.id
  role_definition_name = "Storage Blob Data Contributor"
  condition_version    = "2.0"
  condition            = <<-EOT
(
 (
  !(ActionMatches{'Microsoft.Storage/storageAccounts/blobServices/containers/blobs/read'} AND NOT SubOperationMatches{'Blob.List'})
 )
 OR
 (
  @Resource[Microsoft.Storage/storageAccounts/blobServices/containers:name] StringLike '*bc-sc*'
  AND
  (
   @Resource[Microsoft.Storage/storageAccounts/blobServices/containers/blobs:path] StringLike 'output/logs/*'
  )
 )
)
AND
(
 (
  !(ActionMatches{'Microsoft.Storage/storageAccounts/blobServices/containers/blobs/write'})
 )
 OR
 (
  (
   @Resource[Microsoft.Storage/storageAccounts/blobServices/containers:name] StringLike '*bc-sc*'
   AND
   @Resource[Microsoft.Storage/storageAccounts/blobServices/containers/blobs:path] StringLike 'output/logs/*'
  )
 )
)
  EOT
}

resource "azurerm_role_assignment" "registry_managed_identity_key_vault_secrets_ro_role_assignment" {
  principal_id       = local.uami.registry.principal_id
  scope              = azurerm_resource_group.azure_outpost_cwp_agentless.id
  role_definition_id = local.key_vault_secrets_ro_role_id
}


resource "azurerm_role_assignment" "dspm_managed_identity_key_vault_secrets_ro_role_assignment" {
  principal_id       = local.uami.dspm.principal_id
  scope              = azurerm_resource_group.azure_outpost_cwp_agentless.id
  role_definition_id = local.key_vault_secrets_ro_role_id
}

resource "azurerm_role_assignment" "proxy_managed_identity_key_vault_secrets_ro_role_assignment" {
  count              = var.proxy_config.auth_enabled ? 1 : 0
  principal_id       = local.uami.proxy.principal_id
  scope              = azurerm_resource_group.azure_outpost_cwp_agentless.id
  role_definition_id = local.key_vault_secrets_ro_role_id
}

# BYON + proxy_auth: the TF runner writes/manages the cortex-proxy-credentials
# secret on the outpost Key Vault. The vault uses RBAC authorization, so
# subscription-level Owner/Contributor is NOT sufficient to read or write a
# secret — that is a data-plane action requiring a data-plane role. Grant the
# runner "Key Vault Secrets Officer" (Get/Set/Delete/Purge on secrets) at the
# outpost resource-group scope, which RBAC inherits down to the Key Vault.
resource "azurerm_role_assignment" "terraform_runner_key_vault_secrets_officer_role_assignment" {
  count                = var.proxy_config.auth_enabled ? 1 : 0
  principal_id         = data.azurerm_client_config.current.object_id
  scope                = azurerm_resource_group.azure_outpost_cwp_agentless.id
  role_definition_name = "Key Vault Secrets Officer"
}