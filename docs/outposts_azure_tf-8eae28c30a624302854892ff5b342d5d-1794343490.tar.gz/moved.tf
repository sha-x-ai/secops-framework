# One-time state migration for resources whose addresses changed when
# app_registration_mode was introduced. Two patterns:
#   - foo → foo[0]   : count was added (resource is now mode-gated).
#   - foo[0] → foo   : count was removed; reverse migration.
# Both are no-ops for tenants whose state address already matches the destination.

# ── App Registrations ─────────────────────────────────────────────────────────
moved {
  from = azuread_application_registration.outpost_app_registration
  to   = azuread_application_registration.outpost_app_registration[0]
}

moved {
  from = azuread_application_registration.outpost_o365_app_registration
  to   = azuread_application_registration.outpost_o365_app_registration[0]
}

# ── Service Principals ────────────────────────────────────────────────────────
moved {
  from = azuread_service_principal.outpost_sp
  to   = azuread_service_principal.outpost_sp[0]
}

moved {
  from = azuread_service_principal.outpost_o365_sp
  to   = azuread_service_principal.outpost_o365_sp[0]
}

# ── Federated Identity Credentials (cortex-app) ───────────────────────────────
# Migration lives further down — see "Per-UAMI / CTS-GKE FICs on the cortex App Reg".

# ── Federated Identity Credentials (O365-app) ─────────────────────────────────
moved {
  from = azuread_application_federated_identity_credential.federated_cts_gke_serviceaccount_o365_app
  to   = azuread_application_federated_identity_credential.federated_cts_gke_serviceaccount_o365_app[0]
}

moved {
  from = azuread_application_federated_identity_credential.federated_dspm_managed_identity_o365_app
  to   = azuread_application_federated_identity_credential.federated_dspm_managed_identity_o365_app[0]
}

# ── API Access ────────────────────────────────────────────────────────────────
moved {
  from = azuread_application_api_access.outpost_msgraph_api
  to   = azuread_application_api_access.outpost_msgraph_api[0]
}

moved {
  from = azuread_application_api_access.outpost_o365_msgraph_api
  to   = azuread_application_api_access.outpost_o365_msgraph_api[0]
}

moved {
  from = azuread_application_api_access.outpost_o365_sharepoint_api
  to   = azuread_application_api_access.outpost_o365_sharepoint_api[0]
}

moved {
  from = azuread_application_api_access.outpost_o365_rms_api
  to   = azuread_application_api_access.outpost_o365_rms_api[0]
}

# ── Redirect URIs ─────────────────────────────────────────────────────────────
moved {
  from = azuread_application_redirect_uris.outpost_registration_redirect_uri
  to   = azuread_application_redirect_uris.outpost_registration_redirect_uri[0]
}

moved {
  from = azuread_application_redirect_uris.outpost_registration_redirect_uri_o365_app
  to   = azuread_application_redirect_uris.outpost_registration_redirect_uri_o365_app[0]
}

# ── Role Assignments ──────────────────────────────────────────────────────────
moved {
  from = azurerm_role_assignment.cortex_role_assignment[0]
  to   = azurerm_role_assignment.cortex_role_assignment
}

moved {
  from = azurerm_role_assignment.cortex_private_endpoint_role_assignment[0]
  to   = azurerm_role_assignment.cortex_private_endpoint_role_assignment
}

moved {
  from = azurerm_role_assignment.cortex_storage_queue_role_assignment[0]
  to   = azurerm_role_assignment.cortex_storage_queue_role_assignment
}

moved {
  from = azurerm_role_assignment.storage_blob_role_assignment[0]
  to   = azurerm_role_assignment.storage_blob_role_assignment
}

# ── UAMI / FIC count gating (uami_mode = customer_managed) ────────────────────
# Migrate `foo` → `foo[0]` for resources newly gated with `count`. Safe to
# remove once all active outposts have applied a release containing this once.

# ── Scanner UAMIs ────────────────────────────────────────────────────────────
moved {
  from = azurerm_user_assigned_identity.agentless
  to   = azurerm_user_assigned_identity.agentless[0]
}

moved {
  from = azurerm_user_assigned_identity.dspm
  to   = azurerm_user_assigned_identity.dspm[0]
}

moved {
  from = azurerm_user_assigned_identity.registry
  to   = azurerm_user_assigned_identity.registry[0]
}

moved {
  from = azurerm_user_assigned_identity.serverless
  to   = azurerm_user_assigned_identity.serverless[0]
}

moved {
  from = azurerm_user_assigned_identity.proxy
  to   = azurerm_user_assigned_identity.proxy[0]
}

# ── UAMI random_string suffixes ──────────────────────────────────────────────
moved {
  from = random_string._agentless_identity_random_name
  to   = random_string._agentless_identity_random_name[0]
}

moved {
  from = random_string._dspm_identity_random_name
  to   = random_string._dspm_identity_random_name[0]
}

moved {
  from = random_string._registry_identity_random_name
  to   = random_string._registry_identity_random_name[0]
}

moved {
  from = random_string._serverless_identity_random_name
  to   = random_string._serverless_identity_random_name[0]
}

# ── Per-UAMI / CTS-GKE FICs on the cortex App Reg ────────────────────────────
# (No `moved` blocks here — these 4 FICs are unconditionally created in both
# cortex_managed and customer_managed UAMI modes; their addresses never changed
# from the pre-M2-byo-uamis form.)
