# If no role ID is configured in the variable, this creates two custom roles
# The workload orchestrator role is the base role which allows the cortex platform to work with disks, virtual machines, network interfaces, public IP addreses (for egress proxy purposes) and more.
# The private endpoint role allows the cortex platform to create private endpoint connections to remote storage accounts, container registries and more, to be able to scan those resources without public access.
#
# KNOWN LIMITATION: Role definition names use local.app_registration_name which defaults to
# "cortex-scan-platform-<subscription>". If multiple outposts (cortex_managed + customer_managed)
# are deployed on the same subscription without providing custom var.workload_orchestrator_role_id
# and var.private_endpoints_role_id, the role definition names will collide. Workaround: provide
# pre-created role IDs via the input variables for the second outpost.

resource "azurerm_role_definition" "app_registration_cortex_role" {
  count       = var.workload_orchestrator_role_id == "" ? 1 : 0
  name        = "${local.resource_group_name}-cortex-role"
  scope       = azurerm_resource_group.azure_outpost_cwp_agentless.id
  description = "Outpost App Registration workload orchestrator role"

  # BYON: this role is assigned on customer VNets (see
  # byon_vnet_workload_orchestrator_role_assignment), so each must be in
  # assignableScopes or Azure rejects the assignment
  # (RoleAssignmentScopeNotAssignableToRoleDefinition). Empty byon_config -> RG only.
  assignable_scopes = concat(
    [azurerm_resource_group.azure_outpost_cwp_agentless.id],
    [for cfg in var.byon_config : cfg.virtual_network_id],
  )

  permissions {
    actions = [
      "Microsoft.Compute/disks/read",
      "Microsoft.Compute/disks/write",
      "Microsoft.Compute/disks/delete",
      "Microsoft.Compute/disks/beginGetAccess/action",
      "Microsoft.Compute/virtualMachines/read",
      "Microsoft.Compute/virtualMachines/write",
      "Microsoft.Compute/virtualMachines/delete",
      "Microsoft.Compute/snapshots/read",
      "Microsoft.Compute/snapshots/write",
      "Microsoft.Compute/snapshots/delete",
      "Microsoft.Compute/snapshots/beginGetAccess/action",
      "Microsoft.ManagedIdentity/userAssignedIdentities/assign/action",
      "Microsoft.Network/applicationSecurityGroups/joinIpConfiguration/action",
      "Microsoft.Network/networkInterfaces/read",
      "Microsoft.Network/networkInterfaces/write",
      "Microsoft.Network/networkInterfaces/delete",
      "Microsoft.Network/networkInterfaces/join/action",
      "Microsoft.Network/networkSecurityGroups/join/action",
      "Microsoft.Network/publicIPAddresses/read",
      "Microsoft.Network/publicIPAddresses/write",
      "Microsoft.Network/publicIPAddresses/delete",
      "Microsoft.Network/publicIPAddresses/join/action",
      "Microsoft.Network/virtualNetworks/subnets/join/action",
      "Microsoft.Network/virtualNetworks/subnets/joinViaServiceEndpoint/Action",
      "Microsoft.Compute/skus/read",
      "Microsoft.Compute/locations/usages/read",
      "Microsoft.ResourceGraph/resources/read"
    ]
    data_actions = [
      "Microsoft.KeyVault/vaults/secrets/getSecret/action",    # Get
      "Microsoft.KeyVault/vaults/secrets/readMetadata/action", # List
      "Microsoft.KeyVault/vaults/secrets/setSecret/action",    # Set
      "Microsoft.KeyVault/vaults/secrets/delete",              # Delete
      "Microsoft.KeyVault/vaults/secrets/purge/action"         # Purge
    ]
  }
  lifecycle {
    ignore_changes = [name]
  }

}

resource "azurerm_role_definition" "private_endpoint_role" {
  count       = var.private_endpoints_role_id == "" ? 1 : 0
  name        = "${local.resource_group_name}-private-endpoint-role"
  scope       = azurerm_resource_group.azure_outpost_cwp_agentless.id
  description = "Outpost private endpoints role"

  permissions {
    actions = [
      "Microsoft.Network/operations/read",
      "Microsoft.Network/privateEndpoints/read",
      "Microsoft.Network/privateEndpoints/write",
      "Microsoft.Network/privateEndpoints/delete"
    ]
  }
  lifecycle {
    ignore_changes = [name]
  }
}

resource "azurerm_role_definition" "key_vault_secrets_ro_role" {
  count       = var.key_vault_secrets_ro_role_id == "" ? 1 : 0
  name        = "${local.resource_group_name}-kv-secrets-ro-role"
  description = "Key Vault secrets read-only role for the registry, dspm and proxy VM identities (Get, List)"
  scope       = azurerm_resource_group.azure_outpost_cwp_agentless.id
  permissions {
    data_actions = [
      "Microsoft.KeyVault/vaults/secrets/getSecret/action",   # Get
      "Microsoft.KeyVault/vaults/secrets/readMetadata/action" # List
    ]
  }
}