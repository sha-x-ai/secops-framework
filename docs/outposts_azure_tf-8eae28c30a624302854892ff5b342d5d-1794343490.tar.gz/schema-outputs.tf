output "json_output" {
  value       = data.jsonschema_validator.schema_validation.validated
  description = "a schema-validated JSON file which contains details of all resources that were created by this module, to be used by the onboarding process."
}

output "outpost_sp_object_id" {
  value = local.outpost_principal_id
}

output "template_version" {
  value = local.template_version
}

