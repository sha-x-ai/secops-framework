terraform {
  required_version = ">= 1.9.4, < 2"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "4.79.0"
    }
    azuread = {
      source  = "hashicorp/azuread"
      version = "3.7.0"
    }
    random = {
      source  = "hashicorp/random"
      version = "3.7.2"
    }
    jsonschema = {
      source  = "bpedman/jsonschema"
      version = "= 0.2.1"
    }
    terracurl = {
      source  = "devops-rob/terracurl"
      version = "= 2.1.0"
    }
    local = {
      source  = "hashicorp/local"
      version = "2.6.1"
    }
  }
}