# Previously, the resource group name included the subscription name. The subscription name can contain illegal characters.
# To fix this, the resource group name now includes a random string instead of the subscription name. 
# To avoid force re-creation of the resource group and the nested resources, we configure lifecyle ignore changes for the resource group's name.

resource "random_string" "resource_group_random_name" {
  length  = 8
  lower   = true
  numeric = true
  upper   = false
  special = false
}

resource "azurerm_resource_group" "azure_outpost_cwp_agentless" {
  name     = local.resource_group_name
  location = local.resource_group_region
  tags     = local.tags_all

  lifecycle {
    ignore_changes = [name]
  }
}

