variable "platform_allowed_ips" {
  description = "The default system allow list of public IPs to configure on Storage Accounts and Key Vault. Should contain the Cortext egress IPs"
  type        = list(any)
  validation {
    condition = length(var.platform_allowed_ips) > 0 && alltrue([
      for ip in var.platform_allowed_ips :
      can(regex("^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$", trimspace(ip)))
    ])
    error_message = "platform_allowed_ips must not be empty and must contain only valid IP addresses. Example: [\"8.8.8.8\", \"8.8.4.4\"]"
  }
}

variable "cts_unique_id" {
  description = "The CTS Service Account unique ID. To be supplied by PANW"
  type        = string
}

variable "cts_sa_email" {
  description = "The CTS Service Account email address. To be supplied by PANW"
  type        = string
}

variable "dspm_o365_sa_unique_id" {
  description = "The DSPM o365 Service Account unique ID. To be supplied by PANW"
  type        = string
}

variable "dspm_o365_sa_email" {
  description = "The DSPM o365 Service Account email address. To be supplied by PANW"
  type        = string
}

variable "upload_output_url" {
  description = "The URL to which the outpost registration should be sent"
  type        = string
}

variable "app_registration_name" {
  type        = string
  default     = ""
  description = "The desired App Regisrtaion name. Leave empty to set dynamically with the subscription name"
}

variable "dspm_o365_app_registration_name" {
  type        = string
  default     = ""
  description = "The desired DSPM o365 App Regisrtaion name. Leave empty to set dynamically with the subscription name"
}

variable "app_registration_redirect_uris" {
  type        = list(any)
  description = "app registration redirect uri list, to be provided by PANW"
}

variable "location_allowlist" {
  description = "Which Azure locations to allow. If specified, only the locations in this list will be enabled. If not specified, all supported locations will be enabled by default. NOTE: this variable is Azure-only. AWS uses 'enabled_regions', GCP uses 'region_allowlist'; those names are silently ignored here, leaving all locations enabled."
  type        = list(string)
  default     = []
  validation {
    error_message = "A non valid location was specified, please enter supported Azure locations only"
    # The setsubtract function returns a new set containing the elements from the first set that are not present in the second set.
    ## By making sure length of the function equals 0, we make sure there are no locations that are present on var.location_allowlist
    ## but are not valid for this partition (local._all_valid_partition_locations).
    condition = length(setsubtract(var.location_allowlist, local._all_valid_partition_locations)) == 0
  }
}

variable "location_denylist" {
  description = "Which Azure locations to forbid. If specified, none of the locations in this list will be enabled."
  type        = list(string)
  default     = []
}

# https://learn.microsoft.com/en-us/azure/storage/common/sas-expiration-policy?tabs=azure-portal
variable "storage_sas_policy_expiration" {
  description = "the storage SAS expiration policy"
  type        = string
  # default is two days
  default = "00.01:00:00"
}


variable "outpost_registration_authorization_header_value" {
  description = "The value to be attached to the Authorization header for the outpost registration call, so that it can be authenticated"
  type        = string
  default     = ""
}

variable "outpost_registration_url_is_pubsub_topic" {
  description = "If set to true, then the outpost registration notification payload will be wrapped in an envelope to publish to Pub/Sub"
  type        = bool
  default     = false
}

variable "outpost_schema_json" {
  description = "path to JSON schema, used for outpost registration notification"
  default     = "./iacoutput.json"
}

variable "custom_resources_tags" {
  type        = map(string)
  default     = {}
  description = "extra tags to include on all resources"
}

variable "template_id" {
  description = "template id, used for uploaded artifacts"
}

variable "resource_group_region" {
  type        = string
  description = "target resource group region"
  default     = "westus"
}

variable "url_is_gcs_signed_url" {
  default     = true
  description = "Control variable for outpost notification request"
  type        = bool
}

# This varaible is implementing user input and will be ignored if var.force_private_storage_accounts or var.force_private_key_vaults is set to true
variable "input_ip_whitelist" {
  type        = string
  description = "A user-input string that contains comma-separated IP addresses or CIDR ranges to allow on the storage accounts and key vaults firewall. CAUTION! Leaving this empty will configure public storage accounts and key vaults which is highly discouraged. Include your machine's public IP to allow Terraform configuration. Example input: 8.8.8.8, 10.0.0.0/24"
  validation {
    condition = anytrue([var.input_ip_whitelist == "",
      alltrue([
        for s in split(",", var.input_ip_whitelist) :
        can(regex("^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(/(3[0-2]|[12]?[0-9]))?$", trimspace(s)))
      ])
    ])
    error_message = "Error validating IP address/CIDR whitelist. Example input: \"8.8.8.8, 10.0.0.0/24\""
  }
}

variable "force_private_storage_accounts" {
  type        = bool
  description = "whether to force the creation of private storage accounts."
  default     = false
}

variable "force_private_key_vaults" {
  type        = bool
  description = "whether to force the creation of private key vaults."
  default     = false
}

variable "workload_orchestrator_role_id" {
  type        = string
  description = "The workload orchestrator role ID. To be used when the custom roles are configured on the management group level, to prevent the creation of identical custom roles when provisioning multiple outposts in the same directory. Leave empty for custom role creation"
  default     = ""
}

variable "private_endpoints_role_id" {
  type        = string
  description = "The private endpoint role ID. To be used when the custom roles are configured on the management group level, to prevent the creation of identical custom roles when provisioning multiple outposts in the same directory. Leave empty for custom role creation"
  default     = ""
}

variable "key_vault_secrets_ro_role_id" {
  type        = string
  description = "The key_vault_secrets_ro_role endpoint role ID. To be used when the custom roles are configured on the management group level, to prevent the creation of identical custom roles when provisioning multiple outposts in the same directory. Leave empty for custom role creation"
  default     = ""
}

variable "resource_group_name_prefix" {
  default     = ""
  description = "Prefix to add to the resource group name, leave empty to use default name."
}

variable "register_outpost" {
  type        = bool
  default     = true
  description = "whether to register the outpost by sending the outpost notification output"
}

variable "notification_output_to_local_file" {
  type        = bool
  default     = false
  description = "whether to output the outpost notification data to a local file, (used mostly for debugging.)"
}

variable "azure_us_government" {
  type        = bool
  default     = false
  description = "Deploy on Azure US Government Cloud"
}

variable "enable_azure_high_scale_private_endpoints" {
  type        = bool
  default     = false
  description = "Enable High-Scale Private Endpoints (HSPE) network policies on the outpost VNet and private-endpoint subnet. Requires the Microsoft.Network feature EnableMaxPrivateEndpointsVia64kPath to already be registered on the subscription — this module does not register it. Not supported on Azure US Government."

  validation {
    condition     = !(var.enable_azure_high_scale_private_endpoints && var.azure_us_government)
    error_message = "enable_azure_high_scale_private_endpoints is not supported on Azure US Government."
  }
}

variable "high_scale_private_endpoints_subnet_policy" {
  type        = string
  default     = "Enabled"
  description = "Private endpoint network policy for the outpost subnet when HSPE is enabled. Valid values: 'Enabled' (default) or 'RouteTableEnabled' (for route-table-based routing to the PE subnet)."

  validation {
    condition     = contains(["Enabled", "RouteTableEnabled"], var.high_scale_private_endpoints_subnet_policy)
    error_message = "high_scale_private_endpoints_subnet_policy must be either 'Enabled' or 'RouteTableEnabled'."
  }
}

variable "azure_us_government_resource_group_region" {
  type        = string
  description = "target resource group region for US Government deployment"
  default     = "usgovvirginia"
}

variable "azure_us_government_locations" {
  type        = list(string)
  description = "target locations (regions) for US Government deployment"
  default     = ["usgovvirginia", "usgovarizona", "usgovtexas"]
}

variable "app_registration_mode" {
  type        = string
  default     = "cortex_managed"
  description = <<-EOT
    Controls App Registration creation:
    - "cortex_managed": Cortex creates App Reg + SP (default, cross-tenant)
    - "customer_managed": Customer pre-creates App Reg + SP; Cortex adds FICs to BYO app (cross-tenant)
  EOT
  validation {
    condition     = contains(["cortex_managed", "customer_managed"], var.app_registration_mode)
    error_message = "app_registration_mode value '${var.app_registration_mode}' is invalid. Accepted values are 'cortex_managed' (Cortex creates and manages the App Registration + Service Principal) or 'customer_managed' (you provide an existing App Registration via customer_app_client_id / customer_sp_object_id)."
  }
}

# BYO only: customer provides 2 IDs from the BYO setup script output
# (shipped with the Cortex BYOA docs) or from the Azure Portal:
#   - customer_app_client_id : the AppReg's Application (client) ID (appId)
#   - customer_sp_object_id  : the Service Principal's Object ID
# The AppReg's object_id is auto-derived at plan time via data.azuread_application.customer_app.
# TF runner must be an owner of the customer's App Reg (to add FICs).
variable "customer_app_client_id" {
  type        = string
  default     = ""
  description = "Client ID (appId) of customer's pre-created App Registration. Required when app_registration_mode = 'customer_managed'. Generate via the BYO setup script shipped with the Cortex BYOA docs."
  validation {
    condition     = var.app_registration_mode != "customer_managed" || var.customer_app_client_id != ""
    error_message = "customer_app_client_id is required when app_registration_mode is 'customer_managed'. Generate it via the BYO setup script shipped with the Cortex BYOA docs, or get it from the Azure Portal: Azure AD → App registrations → <your AppReg> → 'Application (client) ID'."
  }
  validation {
    condition     = var.app_registration_mode != "customer_managed" || can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.customer_app_client_id))
    error_message = "The provided customer_app_client_id '${var.customer_app_client_id}' is not a valid Azure GUID (expected e.g. '12345678-1234-1234-1234-123456789abc')."
  }
}

variable "customer_sp_object_id" {
  type        = string
  default     = ""
  description = "Object ID of customer's BYO Service Principal. Required when app_registration_mode = 'customer_managed'. Generate via the BYO setup script shipped with the Cortex BYOA docs, or get via: az ad sp show --id <customer_app_client_id> --query id -o tsv"
  validation {
    condition     = var.app_registration_mode != "customer_managed" || var.customer_sp_object_id != ""
    error_message = "customer_sp_object_id is required when app_registration_mode is 'customer_managed'. Generate it via the BYO setup script shipped with the Cortex BYOA docs, or get it via: az ad sp show --id <customer_app_client_id> --query id -o tsv"
  }
  validation {
    condition     = var.app_registration_mode != "customer_managed" || can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.customer_sp_object_id))
    error_message = "The provided customer_sp_object_id '${var.customer_sp_object_id}' is not a valid Azure GUID (expected e.g. '12345678-1234-1234-1234-123456789abc')."
  }
}

# ── BYO UAMIs ────────────────────────────────────────────────────────────────
# Requires app_registration_mode = "customer_managed" (enforced by precondition
# on the resource group).
variable "uami_mode" {
  type        = string
  default     = "cortex_managed"
  description = <<-EOT
    Controls scanner UAMI creation:
    - "cortex_managed":   Cortex TF creates 5 UAMIs + 4 AppReg FICs (default).
    - "customer_managed": Customer pre-creates 5 UAMIs (via the BYO setup script shipped with the Cortex BYOA docs, run with --add-uamis);
                          Cortex TF still creates the 4 AppReg FICs + 5 UAMI self-FICs
                          and handles role assignments (incl. RBAC-based KV secret access).
    Requires app_registration_mode = "customer_managed".
  EOT
  validation {
    condition     = contains(["cortex_managed", "customer_managed"], var.uami_mode)
    error_message = "uami_mode value '${var.uami_mode}' is invalid. Accepted values are 'cortex_managed' (Cortex creates and manages the 5 scanner UAMIs) or 'customer_managed' (you provide 5 existing UAMI ARM IDs via the customer_uami_*_id variables)."
  }
}

# Customer-supplied ARM resource IDs for the 5 scanner UAMIs. Required when
# uami_mode = "customer_managed". Generate via the BYO setup script shipped with the Cortex BYOA docs (run with --add-uamis).
# The validation regex below mirrors `scanner_user_assigned_identity_id` in
# agentless_notification_schema/iacoutput.json — keep them in lockstep.
#
# CONTRACT — DO NOT RENAME: the names `customer_uami_<role>_id` are emitted
# verbatim by setup-byo-app-registration.sh --add-uamis and pasted by
# customers into template_params.tfvars. Renaming them (e.g. to
# customer_managed_uami_*_id) breaks that script→tfvars contract — TF would
# silently ignore the values as "undeclared variables" and the plan would
# proceed in cortex_managed UAMI mode regardless of uami_mode. The internal
# locals (local._customer_managed_uami_ids, local.is_customer_managed_uami_mode)
# stay descriptive — only the user-facing var names are constrained.
variable "customer_uami_agentless_id" {
  type        = string
  default     = ""
  description = "ARM resource ID of customer-created 'agentless' UAMI. Required when uami_mode = 'customer_managed'."
  validation {
    condition     = var.uami_mode != "customer_managed" || var.customer_uami_agentless_id != ""
    error_message = "customer_uami_agentless_id is required when uami_mode is 'customer_managed'. If using the Cortex BYO script, ensure you appended the '--add-uamis' flag."
  }
  validation {
    condition     = var.uami_mode != "customer_managed" || can(regex("^/subscriptions/[a-f0-9-]{36}/[rR][eE][sS][oO][uU][rR][cC][eE][gG][rR][oO][uU][pP][sS]/[a-zA-Z0-9][a-zA-Z0-9-_]{1,89}/providers/Microsoft\\.ManagedIdentity/userAssignedIdentities/[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}$", var.customer_uami_agentless_id))
    error_message = "Invalid Azure Resource ID format for customer_uami_agentless_id '${var.customer_uami_agentless_id}'. Expected format: '/subscriptions/<SubID>/resourceGroups/<RG>/providers/Microsoft.ManagedIdentity/userAssignedIdentities/<Name>'."
  }
}

variable "customer_uami_dspm_id" {
  type        = string
  default     = ""
  description = "ARM resource ID of customer-created 'dspm' UAMI. Required when uami_mode = 'customer_managed'."
  validation {
    condition     = var.uami_mode != "customer_managed" || var.customer_uami_dspm_id != ""
    error_message = "customer_uami_dspm_id is required when uami_mode is 'customer_managed'. If using the Cortex BYO script, ensure you appended the '--add-uamis' flag."
  }
  validation {
    condition     = var.uami_mode != "customer_managed" || can(regex("^/subscriptions/[a-f0-9-]{36}/[rR][eE][sS][oO][uU][rR][cC][eE][gG][rR][oO][uU][pP][sS]/[a-zA-Z0-9][a-zA-Z0-9-_]{1,89}/providers/Microsoft\\.ManagedIdentity/userAssignedIdentities/[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}$", var.customer_uami_dspm_id))
    error_message = "Invalid Azure Resource ID format for customer_uami_dspm_id '${var.customer_uami_dspm_id}'. Expected format: '/subscriptions/<SubID>/resourceGroups/<RG>/providers/Microsoft.ManagedIdentity/userAssignedIdentities/<Name>'."
  }
}

variable "customer_uami_registry_id" {
  type        = string
  default     = ""
  description = "ARM resource ID of customer-created 'registry' UAMI. Required when uami_mode = 'customer_managed'."
  validation {
    condition     = var.uami_mode != "customer_managed" || var.customer_uami_registry_id != ""
    error_message = "customer_uami_registry_id is required when uami_mode is 'customer_managed'. If using the Cortex BYO script, ensure you appended the '--add-uamis' flag."
  }
  validation {
    condition     = var.uami_mode != "customer_managed" || can(regex("^/subscriptions/[a-f0-9-]{36}/[rR][eE][sS][oO][uU][rR][cC][eE][gG][rR][oO][uU][pP][sS]/[a-zA-Z0-9][a-zA-Z0-9-_]{1,89}/providers/Microsoft\\.ManagedIdentity/userAssignedIdentities/[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}$", var.customer_uami_registry_id))
    error_message = "Invalid Azure Resource ID format for customer_uami_registry_id '${var.customer_uami_registry_id}'. Expected format: '/subscriptions/<SubID>/resourceGroups/<RG>/providers/Microsoft.ManagedIdentity/userAssignedIdentities/<Name>'."
  }
}

variable "customer_uami_serverless_id" {
  type        = string
  default     = ""
  description = "ARM resource ID of customer-created 'serverless' UAMI. Required when uami_mode = 'customer_managed'."
  validation {
    condition     = var.uami_mode != "customer_managed" || var.customer_uami_serverless_id != ""
    error_message = "customer_uami_serverless_id is required when uami_mode is 'customer_managed'. If using the Cortex BYO script, ensure you appended the '--add-uamis' flag."
  }
  validation {
    condition     = var.uami_mode != "customer_managed" || can(regex("^/subscriptions/[a-f0-9-]{36}/[rR][eE][sS][oO][uU][rR][cC][eE][gG][rR][oO][uU][pP][sS]/[a-zA-Z0-9][a-zA-Z0-9-_]{1,89}/providers/Microsoft\\.ManagedIdentity/userAssignedIdentities/[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}$", var.customer_uami_serverless_id))
    error_message = "Invalid Azure Resource ID format for customer_uami_serverless_id '${var.customer_uami_serverless_id}'. Expected format: '/subscriptions/<SubID>/resourceGroups/<RG>/providers/Microsoft.ManagedIdentity/userAssignedIdentities/<Name>'."
  }
}

variable "customer_uami_proxy_id" {
  type        = string
  default     = ""
  description = "ARM resource ID of customer-created 'proxy' UAMI. Required when uami_mode = 'customer_managed'."
  validation {
    condition     = var.uami_mode != "customer_managed" || var.customer_uami_proxy_id != ""
    error_message = "customer_uami_proxy_id is required when uami_mode is 'customer_managed'. If using the Cortex BYO script, ensure you appended the '--add-uamis' flag."
  }
  validation {
    condition     = var.uami_mode != "customer_managed" || can(regex("^/subscriptions/[a-f0-9-]{36}/[rR][eE][sS][oO][uU][rR][cC][eE][gG][rR][oO][uU][pP][sS]/[a-zA-Z0-9][a-zA-Z0-9-_]{1,89}/providers/Microsoft\\.ManagedIdentity/userAssignedIdentities/[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}$", var.customer_uami_proxy_id))
    error_message = "Invalid Azure Resource ID format for customer_uami_proxy_id '${var.customer_uami_proxy_id}'. Expected format: '/subscriptions/<SubID>/resourceGroups/<RG>/providers/Microsoft.ManagedIdentity/userAssignedIdentities/<Name>'."
  }
}

# Opt-out for the 5 UAMI self-FICs that Cortex creates on the customer's UAMIs in
# uami_mode = "customer_managed". When the customer has already pre-created the
# self-FICs on their UAMIs (e.g. via their own automation), set this to false so
# Cortex doesn't try to create duplicates (which would fail with "already exists").
# When false the BYO setup script's `--add-uamis` 'Managed Identity Contributor'
# grant on the UAMI RG is also unnecessary.
# Only honored in uami_mode = "customer_managed"; ignored otherwise.
variable "create_customer_uami_self_fics" {
  type        = bool
  default     = true
  description = "When uami_mode = 'customer_managed', whether Cortex should create self-federated-identity-credentials on each customer-supplied UAMI. Set to false if the customer pre-created the self-FICs themselves."
}
