# Scanner UAMIs (used by scanner VMs for storage R/W on the outpost).
# When uami_mode = "customer_managed", creation is skipped — see
# data-azurerm-customer-uamis.tf for the lookup path. All consumers go
# through local.uami.<role>.*.

resource "random_string" "_agentless_identity_random_name" {
  count   = local.is_customer_managed_uami_mode ? 0 : 1
  length  = 19
  lower   = true
  numeric = true
  upper   = false
  special = false
}

resource "random_string" "_dspm_identity_random_name" {
  count   = local.is_customer_managed_uami_mode ? 0 : 1
  length  = 19
  lower   = true
  numeric = true
  upper   = false
  special = false
}

resource "random_string" "_registry_identity_random_name" {
  count   = local.is_customer_managed_uami_mode ? 0 : 1
  length  = 15
  lower   = true
  numeric = true
  upper   = false
  special = false
}

resource "random_string" "_serverless_identity_random_name" {
  count   = local.is_customer_managed_uami_mode ? 0 : 1
  length  = 15
  lower   = true
  numeric = true
  upper   = false
  special = false
}


resource "azurerm_user_assigned_identity" "agentless" {
  count               = local.is_customer_managed_uami_mode ? 0 : 1
  location            = local.resource_group_region
  name                = substr("saas-${random_string._agentless_identity_random_name[0].result}", 0, 23)
  resource_group_name = azurerm_resource_group.azure_outpost_cwp_agentless.name
  tags                = local.tags_all
}

resource "azurerm_user_assigned_identity" "dspm" {
  count               = local.is_customer_managed_uami_mode ? 0 : 1
  location            = local.resource_group_region
  name                = substr("dspm-${random_string._dspm_identity_random_name[0].result}", 0, 23)
  resource_group_name = azurerm_resource_group.azure_outpost_cwp_agentless.name
  tags                = local.tags_all
}

resource "azurerm_user_assigned_identity" "registry" {
  count               = local.is_customer_managed_uami_mode ? 0 : 1
  location            = local.resource_group_region
  name                = substr("registry-${random_string._registry_identity_random_name[0].result}", 0, 23)
  resource_group_name = azurerm_resource_group.azure_outpost_cwp_agentless.name
  tags                = local.tags_all
}

resource "azurerm_user_assigned_identity" "serverless" {
  count               = local.is_customer_managed_uami_mode ? 0 : 1
  location            = local.resource_group_region
  name                = substr("serverless-${random_string._serverless_identity_random_name[0].result}", 0, 23)
  resource_group_name = azurerm_resource_group.azure_outpost_cwp_agentless.name
  tags                = local.tags_all
}

resource "azurerm_user_assigned_identity" "proxy" {
  # No proxy VM under egress_off.
  count               = local._create_proxy_uami ? 1 : 0
  location            = local.resource_group_region
  name                = substr("proxy-${random_string._serverless_identity_random_name[0].result}", 0, 23)
  resource_group_name = azurerm_resource_group.azure_outpost_cwp_agentless.name
  tags                = local.tags_all
}
