# Federated Identity Credentials on the outpost App Registration.
#
# Two categories of FICs are created here:
#   1. Cortex GCP ServiceAccount -> the outpost AppReg (Cortex Platform -> outpost auth).
#   2. Scanner VMs' User-Assigned Managed Identities (UAMIs) -> the outpost AppReg
#      (lets the UAMIs exchange IMDS tokens for AAD tokens against the monitored tenant).
#
# These FICs are ALWAYS created when the AppReg is present, in BOTH uami_mode values:
#   - cortex_managed:   subjects = principal_ids of the 5 Cortex-created UAMIs.
#   - customer_managed: subjects = principal_ids of the 5 customer-created UAMIs (looked up
#                        via data.azurerm_user_assigned_identity.customer_managed). Customer must
#                        also run the BYO setup script (shipped with the Cortex BYOA docs)
#                        with --tf-runner-object-id ... so the TF runner is an owner of the
#                        AppReg and can attach FICs.
#
# UAMI self-FICs (the *other* half of the IMDS token-exchange trust) are also defined
# in this file (`azurerm_federated_identity_credential.uami_self_fic` below) — only in
# customer_managed mode, because in cortex_managed mode the UAMIs are created directly
# by TF and don't need a self-FIC for cross-tenant exchange.

resource "azuread_application_federated_identity_credential" "federated_cts_gke_serviceaccount" {
  # checkov:skip=CKV_AZURE_249:GCP federated identity credentials, not GitHub Actions OIDC - false positive
  application_id = local.outpost_app_object_id
  display_name   = "cortex-gcp-serviceaccount"
  description    = "trust ${var.cts_sa_email}"
  audiences      = ["api://AzureADTokenExchange"]
  issuer         = "https://accounts.google.com"
  subject        = var.cts_unique_id
}

resource "azuread_application_federated_identity_credential" "federated_dspm_managed_identity" {
  # checkov:skip=CKV_AZURE_249:Azure managed identity federated credentials, not GitHub Actions OIDC - false positive
  application_id = local.outpost_app_object_id
  display_name   = "dspm-user-assigned-managed-identity"
  description    = "trust ${local.uami.dspm.name}"
  audiences      = ["api://AzureADTokenExchange"]
  issuer         = "https://login.microsoftonline.com/${data.azurerm_subscription.outpost.tenant_id}/v2.0"
  subject        = local.uami.dspm.principal_id
}

resource "azuread_application_federated_identity_credential" "federated_registry_managed_identity" {
  # checkov:skip=CKV_AZURE_249:Azure managed identity federated credentials, not GitHub Actions OIDC - false positive
  application_id = local.outpost_app_object_id
  display_name   = "registry-user-assigned-managed-identity"
  description    = "trust ${local.uami.registry.name}"
  audiences      = ["api://AzureADTokenExchange"]
  issuer         = "https://login.microsoftonline.com/${data.azurerm_subscription.outpost.tenant_id}/v2.0"
  subject        = local.uami.registry.principal_id
}

resource "azuread_application_federated_identity_credential" "federated_serverless_managed_identity" {
  # checkov:skip=CKV_AZURE_249:Azure managed identity federated credentials, not GitHub Actions OIDC - false positive
  application_id = local.outpost_app_object_id
  display_name   = "serverless-user-assigned-managed-identity"
  description    = "trust ${local.uami.serverless.name}"
  audiences      = ["api://AzureADTokenExchange"]
  issuer         = "https://login.microsoftonline.com/${data.azurerm_subscription.outpost.tenant_id}/v2.0"
  subject        = local.uami.serverless.principal_id
}

# o365 AppReg FICs — only exist when Cortex creates the o365 AppReg (manage_app_registration = true),
# which only happens in app_registration_mode = "cortex_managed" (and therefore uami_mode = "cortex_managed").
resource "azuread_application_federated_identity_credential" "federated_cts_gke_serviceaccount_o365_app" {
  # checkov:skip=CKV_AZURE_249:These are GCP federated identity credentials, not GitHub Actions OIDC - false positive
  count          = local.manage_app_registration ? 1 : 0
  application_id = azuread_application_registration.outpost_o365_app_registration[0].id
  display_name   = "dspm-azure-serviceaccount"
  description    = "trust ${var.dspm_o365_sa_email}"
  audiences      = ["api://AzureADTokenExchange"]
  issuer         = "https://accounts.google.com"
  subject        = var.dspm_o365_sa_unique_id
}

resource "azuread_application_federated_identity_credential" "federated_dspm_managed_identity_o365_app" {
  # checkov:skip=CKV_AZURE_249:These are Azure managed identity federated credentials, not GitHub Actions OIDC - false positive
  count          = local.manage_app_registration ? 1 : 0
  application_id = azuread_application_registration.outpost_o365_app_registration[0].id
  display_name   = "dspm-user-assigned-managed-identity"
  description    = "trust ${local.uami.dspm.name}"
  audiences      = ["api://AzureADTokenExchange"]
  issuer         = "https://login.microsoftonline.com/${data.azurerm_subscription.outpost.tenant_id}/v2.0"
  subject        = local.uami.dspm.principal_id
}

# UAMI self-FICs for customer-managed UAMI mode.
#
# When uami_mode = "customer_managed", each customer-supplied scanner UAMI needs a
# self-FIC so it can exchange its IMDS-issued token for an AAD token. The FIC subject
# is the UAMI's own principal_id — Azure's documented IMDS token-exchange convention.
#
# Skipped entirely when:
#   - uami_mode = "cortex_managed" (Cortex creates the UAMIs in the same tenant, no
#     self-FIC needed), OR
#   - var.create_customer_uami_self_fics = false (the customer pre-created the self-FICs
#     themselves; trying to recreate them here would fail with "already exists").
#
# Permissions: requires 'Managed Identity Contributor' on the customer's UAMI RG. The
# BYO setup script's `--add-uamis` flag grants this to the TF runner during UAMI
# creation — needed only when create_customer_uami_self_fics = true.
resource "azurerm_federated_identity_credential" "uami_self_fic" {
  # checkov:skip=CKV_AZURE_249:Azure managed identity self-federated credentials, not GitHub Actions OIDC - false positive
  for_each = (local.is_customer_managed_uami_mode && var.create_customer_uami_self_fics) ? toset(["agentless", "dspm", "registry", "serverless", "proxy"]) : toset([])

  name                = "${each.key}-self-fic"
  resource_group_name = data.azurerm_user_assigned_identity.customer_managed[each.key].resource_group_name
  parent_id           = data.azurerm_user_assigned_identity.customer_managed[each.key].id
  audience            = ["api://AzureADTokenExchange"]
  issuer              = "https://login.microsoftonline.com/${data.azurerm_subscription.outpost.tenant_id}/v2.0"
  subject             = local.uami[each.key].principal_id
}
