# The Outpost App Registration is configured with Graph Application.Read.All API Permissions to enable the "Microsoft Graph Application" integration in Cortex
#   > which allows asset discovery and risk management of Microsoft Graph Applications

# The DSPM Office 365 App Registraion is configured with Graph, SharePoint and RMS API Permissions 
#   > to enable asset discovery, risk assessment and data classification
#     of Graph Users, Groups, Applications, Files, SharePoint Sites and Rights Management Services encrypted files

# All the API Permissions configured below will only be enabled and activated once the onboarding completes, during the Admin Consent phase.

# These resources will request (and not grant) API Permissions. This allows requesting admin consent on the monitored tenant during onboarding for the monitored tenant.
# All resources are gated on manage_app_registration — only created when Cortex owns the AppReg.

resource "azuread_application_api_access" "outpost_msgraph_api" {
  count          = local.manage_app_registration ? 1 : 0
  application_id = azuread_application_registration.outpost_app_registration[0].id
  # Well-known Microsoft Graph ID
  api_client_id = local.well_known_ms_graph_ids.client_ids["Microsoft.Graph"]

  role_ids = [
    local.well_known_ms_graph_ids.role_ids["Graph.Application.Read.All"]
  ]
}

resource "azuread_application_api_access" "outpost_o365_msgraph_api" {
  count          = local.manage_app_registration ? 1 : 0
  application_id = azuread_application_registration.outpost_o365_app_registration[0].id
  # Well-known Microsoft Graph ID
  api_client_id = local.well_known_ms_graph_ids.client_ids["Microsoft.Graph"]

  role_ids = [
    local.well_known_ms_graph_ids.role_ids["Graph.User.Read.All"],
    local.well_known_ms_graph_ids.role_ids["Graph.Group.Read.All"],
    local.well_known_ms_graph_ids.role_ids["Graph.Directory.Read.All"],
    local.well_known_ms_graph_ids.role_ids["Graph.Sites.Read.All"],
    local.well_known_ms_graph_ids.role_ids["Graph.Application.Read.All"],
    local.well_known_ms_graph_ids.role_ids["Graph.Files.Read.All"],
    local.well_known_ms_graph_ids.role_ids["Graph.InformationProtectionPolicy.Read.All"],
    local.well_known_ms_graph_ids.role_ids["Graph.SharePointTenantSettings.Read.All"]
  ]
}

resource "azuread_application_api_access" "outpost_o365_sharepoint_api" {
  count          = local.manage_app_registration ? 1 : 0
  application_id = azuread_application_registration.outpost_o365_app_registration[0].id
  api_client_id  = local.well_known_ms_graph_ids.client_ids["Microsoft.SharePoint"]
  role_ids = [
    local.well_known_ms_graph_ids.role_ids["SharePoint.Sites.Manage.All"],
    local.well_known_ms_graph_ids.role_ids["SharePoint.Sites.Read.All"]
  ]
}

resource "azuread_application_api_access" "outpost_o365_rms_api" {
  count          = local.manage_app_registration ? 1 : 0
  application_id = azuread_application_registration.outpost_o365_app_registration[0].id
  # Well-known Microsoft Rights Management Service ID
  api_client_id = local.well_known_ms_graph_ids.client_ids["Microsoft.RMS"]
  role_ids = [
    local.well_known_ms_graph_ids.role_ids["RMS.Content.SuperUser"]
  ]
}
