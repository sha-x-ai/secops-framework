# Creating the service principals for the App Registrations, which allows granting permissions for the App Registration.
# Conditional on local.manage_app_registration — not created when app_registration_mode = "customer_managed"
# (in BYO mode the customer pre-creates the SP and provides its object ID via var.customer_sp_object_id).

# Note: to create this resource, Microsoft Graph Application.ReadWrite.All permission is required.
resource "azuread_service_principal" "outpost_sp" {
  count        = local.manage_app_registration ? 1 : 0
  client_id    = azuread_application_registration.outpost_app_registration[0].client_id
  use_existing = true

  # Note that azuread_service_principal tags are not azure resource manager resource tags.
  #  tags for this resource are "A set of tags to apply to the service principal for configuring specific behaviours of the service principal, to be used by practitioners"
  #  This is why this resource is not tagged.
}

resource "azuread_service_principal" "outpost_o365_sp" {
  count        = local.manage_app_registration ? 1 : 0
  client_id    = azuread_application_registration.outpost_o365_app_registration[0].client_id
  use_existing = true
}
