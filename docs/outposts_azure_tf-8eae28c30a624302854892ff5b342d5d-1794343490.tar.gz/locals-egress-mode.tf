# Outpost egress routing mode.
#
# The mode is communicated to the Cortex platform as exactly one feature token
# in the outpost registration notification. The workload orchestrator resolves
# the token back to a mode at scan launch and fails closed if it sees more than
# one, so this must stay a single-winner selection. The input value and the
# emitted feature token are intentionally the same string so the tfvars input
# reads identically to what the platform receives.

locals {
  # egress_mode is authoritative when set. When it is null (every tfvars written
  # before this variable existed) fall back to the historical binary behaviour:
  # BYON implied a customer-managed proxy, everything else implied the
  # Cortex-managed egress proxy. Defaulting the variable to "egress" instead
  # would silently move existing BYON outposts onto the Cortex proxy.
  #   "egress"            - Cortex-managed egress proxy VM
  #   "custom_networking" - customer-managed proxy over their own network
  #   "egress_off"        - no outbound internet at all
  egress_mode = coalesce(var.egress_mode, local.is_byon_enabled ? "custom_networking" : "egress")

  egress_feature = local.egress_mode
}
