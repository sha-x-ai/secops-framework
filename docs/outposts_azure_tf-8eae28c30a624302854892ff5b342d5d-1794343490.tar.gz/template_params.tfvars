custom_resources_tags = {
	"managed_by" = "paloaltonetworks"
}
app_registration_redirect_uris = ["https://agent-gateway-public-api-prod-us.traps.paloaltonetworks.com/logs/ouath2/redirect"]
azure_us_government = false
upload_output_url = "https://xdr-us-1002151708645-cloud-onboarding-templates.storage.googleapis.com/notification/outposts/azure/tf-8eae28c30a624302854892ff5b342d5d-1794343488-output.json?Expires=1794948289&GoogleAccessId=api-pod%40xdr-us-1002151708645.iam.gserviceaccount.com&Signature=PsmPEJxhlm%2FUlNNIBw1PLRXj%2BjnwuGBxM4hrpVA3fIim9FpzYsZz0gIX%2FD6PyeIuHg855jg4bNqqWbkDCUm7vOU2Gb1lV%2BHT%2BzA0Tm6DkImO73FBtOIj1Lw7IPhFIiipkH6ftRRFeFFr9dgzTcch3Ctgek%2FoRb08Ni5xSkULOMRA8XOCVVpUklPsu1pUDgNIGv9dQdrT7iwmDwnlpJJB7B6laSuFSi7v3shHWEm4vWA8AZ2MBIt%2FL1zSQTtOGO%2BCVppxYG87lLOwrZKbqqu5TY0I51ngPIUTahVpYju6Y%2BtodSVAVi%2B6M4T5Pz8%2FrG3keK6dUOWvUiQZHnguuNynvg%3D%3D"
platform_allowed_ips = ["34.69.63.16", "34.132.108.184"]
cts_unique_id = "104541886421553829672"
cts_sa_email = "cts-pod@xdr-us-1002151708645.iam.gserviceaccount.com"
template_id = "8eae28c30a624302854892ff5b342d5d"
dspm_o365_sa_email = "dspm-application@xdr-us-1002151708645.iam.gserviceaccount.com"
dspm_o365_sa_unique_id = "111539507347885975988"
proxy_config = {
	"enabled" = false
}
cloud_partition = "COMMERCIAL"
egress_mode = "custom_networking"
app_registration_mode = "cortex_managed"
customer_app_client_id = ""
customer_sp_object_id = ""
uami_mode = "cortex_managed"
customer_uami_agentless_id = ""
customer_uami_dspm_id = ""
customer_uami_registry_id = ""
customer_uami_serverless_id = ""
customer_uami_proxy_id = ""
byon_config = {
	"eastus" = {
		"subnet_id" = "/subscriptions/218f0c22-5366-444b-8897-2497ceb096ab/resourceGroups/anfirdaus-cqwjv0nhxadp-torque/providers/Microsoft.Network/virtualNetworks/linux-ztna-vnet/subnets/ztna2-vnet"
		"virtual_network_id" = "/subscriptions/218f0c22-5366-444b-8897-2497ceb096ab/resourceGroups/anfirdaus-cqwjv0nhxadp-torque/providers/Microsoft.Network/virtualNetworks/linux-ztna-vnet"
	}
}
location_allowlist = ["eastus"]
